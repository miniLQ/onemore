from PyQt6.QtCore import Qt, QThread, pyqtSignal, QTimer, QDate
from PyQt6.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QTableWidget, QTableWidgetItem, QHeaderView, QTextEdit, QFileDialog, QTabWidget, QMenu, QAbstractItemView, QScrollArea as PyQtScrollArea
from PyQt6.QtGui import QFont, QAction, QCursor
import sys
import os
import re
import collections
import subprocess
from datetime import datetime, timedelta

from qfluentwidgets import (
    BodyLabel, CaptionLabel, PushButton, PrimaryPushButton, TitleLabel,
    SimpleCardWidget, HeaderCardWidget, GroupHeaderCardWidget, ScrollArea,
    InfoBarIcon, MessageBox, CheckBox, StateToolTip, Flyout, ImageLabel,
    TableWidget, TextEdit, LineEdit, PillPushButton, setFont
)

from app.common.config import ROOTPATH
from app.common.logging import logger
from app.common.utils import linuxPath2winPath

CURRENT_PLUGIN_DIR = os.path.dirname(__file__)
resource_path = 'app/resource'


class AppInfoCard(SimpleCardWidget):
    """ DSP音频时间对齐工具信息卡片 """

    def __init__(self, parent=None):
        super().__init__(parent)
        self.parent = parent

        # 添加logo图像 - 使用插件目录下的logo.png
        self.iconLabel = ImageLabel("{}".format(os.path.join(CURRENT_PLUGIN_DIR, "logo.png")), self)
        self.iconLabel.setBorderRadius(8, 8, 8, 8)
        self.iconLabel.scaledToWidth(120)
        
        self.nameLabel = TitleLabel('QXDM_Dumptime_Tool', self)
        self.companyLabel = CaptionLabel('@Designed by Charter', self)
        self.descriptionLabel = BodyLabel(
            '本工具用于对齐DSP音频dump时间与Android系统时间，通过token映射建立时间对应关系，支持音频问题点与Android日志时间点的相互转换。', self)
        self.descriptionLabel.setWordWrap(True)

        # 添加两个tag按钮
        self.tagButton = PillPushButton('QXDM', self)
        self.tagButton.setCheckable(False)
        setFont(self.tagButton, 12)
        self.tagButton.setFixedSize(85, 32)

        self.tagButton2 = PillPushButton('dumptime', self)
        self.tagButton2.setCheckable(False)
        setFont(self.tagButton2, 12)
        self.tagButton2.setFixedSize(85, 32)

        self.hBoxLayout = QHBoxLayout(self)
        self.vBoxLayout = QVBoxLayout()
        self.topLayout = QHBoxLayout()
        self.statisticsLayout = QHBoxLayout()
        self.buttonLayout = QHBoxLayout()

        self.initLayout()
        self.setBorderRadius(8)

    def initLayout(self):
        self.hBoxLayout.setSpacing(30)
        self.hBoxLayout.setContentsMargins(34, 24, 24, 24)
        self.hBoxLayout.addWidget(self.iconLabel)
        self.hBoxLayout.addLayout(self.vBoxLayout)

        self.vBoxLayout.setContentsMargins(0, 0, 0, 0)
        self.vBoxLayout.setSpacing(0)

        # name label - 修复：使用addLayout而不是addWidget
        self.vBoxLayout.addLayout(self.topLayout)  # 修改这里
        self.topLayout.setContentsMargins(0, 0, 0, 0)
        self.topLayout.addWidget(self.nameLabel)

        # company label
        self.vBoxLayout.addSpacing(3)
        self.vBoxLayout.addWidget(self.companyLabel)

        # description label
        self.vBoxLayout.addSpacing(20)
        self.vBoxLayout.addWidget(self.descriptionLabel)

        # button
        self.vBoxLayout.addSpacing(12)
        self.buttonLayout.setContentsMargins(0, 0, 0, 0)
        self.vBoxLayout.addLayout(self.buttonLayout)  # 这里也是布局，所以用addLayout
        self.buttonLayout.addWidget(self.tagButton, 0, Qt.AlignmentFlag.AlignLeft)
        self.buttonLayout.addWidget(self.tagButton2, 1, Qt.AlignmentFlag.AlignLeft)

class DescriptionCard(HeaderCardWidget):
    """ DSP工具描述卡片 """

    def __init__(self, parent=None):
        super().__init__(parent)
        self.descriptionLabel = BodyLabel(
            'QXDM_Dumptime_Tool用于解决DSP音频dump文件与Android系统日志的时间同步问题。\n\n'
            '主要功能：\n'
            '1. Token映射建立 - 通过sending pkt/rcvd cmd日志建立Android与DSP时间对应关系\n'
            '2. 音频文件分析 - 解析音频dump文件和labels文件，获取时间切片信息\n'
            '3. 时间点转换 - 支持音频进度↔Android时间的双向转换\n\n'
            '使用步骤：\n'
            '1. 选择DSP Dump目录（包含.wav和.labels文件）\n'
            '2. 选择Android Log文件（包含sending pkt日志）\n'
            '3. 选择DSP Log文件（包含rcvd cmd日志）\n'
            '4. 加载并分析数据\n'
            '5. 使用时间转换功能', self)

        self.descriptionLabel.setWordWrap(True)
        self.viewLayout.addWidget(self.descriptionLabel)
        self.setTitle('功能描述')
        self.setBorderRadius(8)


class Worker(QThread):
    """ DSP数据分析工作线程 """
    
    analysis_complete = pyqtSignal(bool, str)  # success, message
    progress_update = pyqtSignal(str)
    token_data_ready = pyqtSignal(list)
    audio_data_ready = pyqtSignal(list)
    
    def __init__(self, dsp_dir, android_logs, dsp_logs):
        super().__init__()
        self.dsp_dir = dsp_dir
        self.android_logs = android_logs
        self.dsp_logs = dsp_logs
        
        self.audio_files = []
        self.android_entries = []
        self.dsp_entries = []
        self.token_map = {}
        
    def log(self, message):
        """记录进度"""
        self.progress_update.emit(message)
        logger.info(f"[DSP Worker] {message}")
    
    def time_str_to_ms(self, time_str):
        """将时间字符串转换为毫秒"""
        try:
            parts = time_str.split(':')
            ms = 0
            
            if len(parts) == 3:  # HH:MM:SS.sss
                ms += int(parts[0]) * 3600000
                ms += int(parts[1]) * 60000
                sec_parts = parts[2].split('.')
                ms += int(sec_parts[0]) * 1000
                if len(sec_parts) > 1:
                    ms_part = sec_parts[1].ljust(3, '0')[:3]
                    ms += int(ms_part)
            elif len(parts) == 2:  # MM:SS.sss
                ms += int(parts[0]) * 60000
                sec_parts = parts[1].split('.')
                ms += int(sec_parts[0]) * 1000
                if len(sec_parts) > 1:
                    ms_part = sec_parts[1].ljust(3, '0')[:3]
                    ms += int(ms_part)
                    
            return ms
        except:
            return 0
    
    def ms_to_time_str(self, ms):
        """毫秒转时间字符串"""
        hours = ms // 3600000
        ms %= 3600000
        minutes = ms // 60000
        ms %= 60000
        seconds = ms // 1000
        milliseconds = ms % 1000
        
        return f"{hours:02d}:{minutes:02d}:{seconds:02d}.{milliseconds:03d}"
    
    def ms_to_audio_progress_str(self, ms):
        """毫秒转音频进度格式"""
        minutes = ms // 60000
        ms %= 60000
        seconds = ms // 1000
        milliseconds = ms % 1000
        
        return f"{minutes}:{seconds:02d}.{milliseconds:03d}"
    
    def load_audio_files(self):
        """加载音频文件"""
        self.log("开始加载音频文件...")
        
        if not os.path.exists(self.dsp_dir):
            return
        
        for root, dirs, files in os.walk(self.dsp_dir):
            for file in files:
                if file.lower().endswith('.wav'):
                    wav_path = os.path.join(root, file)
                    
                    # 查找对应的labels文件
                    label_path = None
                    base_name = os.path.splitext(wav_path)[0]
                    for ext in ['.labels', '.labels.txt']:
                        if os.path.exists(base_name + ext):
                            label_path = base_name + ext
                            break
                    
                    if label_path:
                        audio_info = self.parse_label_file(label_path, wav_path)
                        if audio_info:
                            self.audio_files.append(audio_info)
                    else:
                        self.audio_files.append({
                            'wav_file': wav_path,
                            'label_file': '无标签文件',
                            'start_time_ms': 0,
                            'end_time_ms': 0,
                            'slices': [],
                            'duration_ms': 0
                        })
        
        self.log(f"加载了 {len(self.audio_files)} 个音频文件")
    
    def parse_label_file(self, label_path, wav_path):
        """解析labels文件"""
        try:
            with open(label_path, 'r', encoding='utf-8') as f:
                lines = f.readlines()
            
            time_points = []
            for line in lines:
                line = line.strip()
                if line and 'timestamp:' in line:
                    match = re.search(r'timestamp:(\d{2}:\d{2}:\d{2}\.\d{3})', line)
                    if match:
                        time_str = match.group(1)
                        ms = self.time_str_to_ms(time_str)
                        time_points.append(ms)
            
            if time_points:
                return {
                    'wav_file': wav_path,
                    'label_file': label_path,
                    'start_time_ms': time_points[0] if time_points else 0,
                    'end_time_ms': time_points[-1] if time_points else 0,
                    'slices': time_points,
                    'duration_ms': time_points[-1] - time_points[0] if len(time_points) >= 2 else 0
                }
        except Exception as e:
            self.log(f"解析label文件错误: {label_path}, {e}")
        
        return None
    
    def load_android_logs(self):
        """加载Android日志"""
        self.log("开始加载Android日志...")
        
        for file_path in self.android_logs:
            try:
                with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                    for line_num, line in enumerate(f, 1):
                        match = re.search(r'(\d{2}-\d{2} \d{2}:\d{2}:\d{2}\.\d{3}).*sending pkt with token (0x[0-9a-fA-F]+)', line)
                        if match:
                            time_str = match.group(1)
                            token = match.group(2).lower()
                            
                            try:
                                dt = datetime.strptime(time_str, "%m-%d %H:%M:%S.%f")
                            except ValueError:
                                try:
                                    dt = datetime.strptime(time_str, "%Y-%m-%d %H:%M:%S.%f")
                                except ValueError:
                                    continue
                            
                            self.android_entries.append({
                                'file': file_path,
                                'line_num': line_num,
                                'time': dt,
                                'time_str': time_str,
                                'token': token,
                                'full_line': line.strip()
                            })
            except Exception as e:
                self.log(f"读取Android日志错误: {file_path}, {e}")
        
        self.log(f"加载了 {len(self.android_entries)} 条Android日志")
    
    def load_dsp_logs(self):
        """加载DSP日志"""
        self.log("开始加载DSP日志...")
        
        for file_path in self.dsp_logs:
            try:
                with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                    for line_num, line in enumerate(f, 1):
                        match = re.search(r'(\d{2}:\d{2}:\d{2}\.\d{3}).*token:\[(0x[0-9a-fA-F]+)\]', line)
                        if match:
                            time_str = match.group(1)
                            token = match.group(2).lower()
                            
                            try:
                                dt = datetime.strptime(f"1970-01-01 {time_str}", "%Y-%m-%d %H:%M:%S.%f")
                            except ValueError:
                                continue
                            
                            self.dsp_entries.append({
                                'file': file_path,
                                'line_num': line_num,
                                'time': dt,
                                'time_str': time_str,
                                'token': token,
                                'full_line': line.strip()
                            })
            except Exception as e:
                self.log(f"读取DSP日志错误: {file_path}, {e}")
        
        self.log(f"加载了 {len(self.dsp_entries)} 条DSP日志")
    
    def analyze_token_mapping(self):
        """分析token映射"""
        self.log("开始分析token映射...")
        
        android_by_token = collections.defaultdict(list)
        dsp_by_token = collections.defaultdict(list)
        
        for entry in self.android_entries:
            android_by_token[entry['token']].append(entry)
        
        for entry in self.dsp_entries:
            dsp_by_token[entry['token']].append(entry)
        
        # 建立映射关系
        token_data = []
        for token in set(android_by_token.keys()) & set(dsp_by_token.keys()):
            if android_by_token[token] and dsp_by_token[token]:
                android_entry = min(android_by_token[token], key=lambda x: x['time'])
                dsp_entry = min(dsp_by_token[token], key=lambda x: x['time'])
                
                time_diff = (dsp_entry['time'] - android_entry['time']).total_seconds() * 1000
                
                self.token_map[token] = {
                    'android': android_entry,
                    'dsp': dsp_entry,
                    'time_diff_ms': time_diff
                }
                
                token_data.append([
                    token,
                    android_entry['time_str'],
                    dsp_entry['time_str'],
                    f"{time_diff:.2f}",
                    os.path.basename(android_entry['file']),
                    os.path.basename(dsp_entry['file'])
                ])
        
        # 发送token数据
        self.token_data_ready.emit(token_data)
        self.log(f"建立了 {len(self.token_map)} 个token映射")
    
    def prepare_audio_data(self):
        """准备音频数据"""
        self.log("准备音频数据...")
        
        audio_data = []
        for audio_info in self.audio_files:
            wav_filename = os.path.basename(audio_info['wav_file'])
            label_filename = os.path.basename(audio_info['label_file'])
            
            if audio_info['start_time_ms'] > 0:
                start_time_str = self.ms_to_time_str(audio_info['start_time_ms'])
                end_time_str = self.ms_to_time_str(audio_info['end_time_ms'])
                duration_str = self.ms_to_time_str(audio_info['duration_ms'])
                slice_count = len(audio_info['slices'])
            else:
                start_time_str = "N/A"
                end_time_str = "N/A"
                duration_str = "N/A"
                slice_count = 0
            
            audio_data.append([
                wav_filename,
                label_filename,
                start_time_str,
                end_time_str,
                duration_str,
                str(slice_count),
                audio_info['wav_file'],  # 完整路径，用于右键菜单
                audio_info['label_file']  # 完整路径，用于右键菜单
            ])
        
        # 发送音频数据
        self.audio_data_ready.emit(audio_data)
    
    def run(self):
        """执行分析"""
        try:
            self.load_audio_files()
            self.load_android_logs()
            self.load_dsp_logs()
            self.analyze_token_mapping()
            self.prepare_audio_data()
            
            # 准备摘要信息
            summary = f"=== 数据分析完成 ===\n\n"
            summary += f"音频文件数量: {len(self.audio_files)}\n"
            summary += f"Android日志条目: {len(self.android_entries)}\n"
            summary += f"DSP日志条目: {len(self.dsp_entries)}\n"
            summary += f"成功匹配的Token数量: {len(self.token_map)}\n"
            
            if self.token_map:
                avg_diff = sum(item['time_diff_ms'] for item in self.token_map.values()) / len(self.token_map)
                summary += f"Android到DSP平均时间差: {avg_diff:.2f} ms\n"
            
            self.analysis_complete.emit(True, summary)
            
        except Exception as e:
            self.analysis_complete.emit(False, f"分析失败: {str(e)}")


class SettingsCard(GroupHeaderCardWidget):
    """DSP分析设置卡片"""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setTitle("DSP音频时间对齐设置")
        self.setBorderRadius(8)
        
        # 数据存储
        self.dsp_dir = ""
        self.android_logs = []
        self.dsp_logs = []
        self.worker = None
        self.stateTooltip = None
        self.main_window = None  # 用于存储主窗口引用
        
        # 初始化UI
        self.init_ui()
        
    def init_ui(self):
        """初始化用户界面"""
        # DSP目录选择
        self.dspDirButton = PushButton("选择DSP Dump目录")
        self.dspDirButton.setFixedWidth(150)
        self.dspDirLabel = BodyLabel("未选择", self)
        self.dspDirLabel.setWordWrap(True)
        
        # Android日志选择
        self.androidLogButton = PushButton("添加Android Log")
        self.androidLogButton.setFixedWidth(150)
        self.androidLogLabel = BodyLabel("未选择", self)
        self.androidLogLabel.setWordWrap(True)
        
        # DSP日志选择
        self.dspLogButton = PushButton("添加DSP Log")
        self.dspLogButton.setFixedWidth(150)
        self.dspLogLabel = BodyLabel("未选择", self)
        self.dspLogLabel.setWordWrap(True)
        
        # 为每个组创建一个容器widget，包含按钮和标签
        # DSP目录组
        dsp_dir_widget = QWidget()
        dsp_dir_layout = QHBoxLayout(dsp_dir_widget)
        dsp_dir_layout.setContentsMargins(0, 0, 0, 0)
        dsp_dir_layout.addWidget(self.dspDirButton)
        dsp_dir_layout.addWidget(self.dspDirLabel, 1)
        
        # Android日志组
        android_log_widget = QWidget()
        android_log_layout = QHBoxLayout(android_log_widget)
        android_log_layout.setContentsMargins(0, 0, 0, 0)
        android_log_layout.addWidget(self.androidLogButton)
        android_log_layout.addWidget(self.androidLogLabel, 1)
        
        # DSP日志组
        dsp_log_widget = QWidget()
        dsp_log_layout = QHBoxLayout(dsp_log_widget)
        dsp_log_layout.setContentsMargins(0, 0, 0, 0)
        dsp_log_layout.addWidget(self.dspLogButton)
        dsp_log_layout.addWidget(self.dspLogLabel, 1)
        
        # 添加组件到界面 - 现在每个组只传递一个widget
        self.addGroup("{}/images/Rocket.svg".format(resource_path), 
                     "DSP Dump目录", "选择包含.wav和.labels文件的目录", 
                     dsp_dir_widget)
        
        self.addGroup("{}/images/Basketball.png".format(resource_path), 
                     "Android Log文件", "选择包含sending pkt日志的文件", 
                     android_log_widget)
        
        self.addGroup("{}/images/Python.svg".format(resource_path), 
                     "DSP Log文件", "选择包含rcvd cmd日志的文件", 
                     dsp_log_widget)
        
        # 分析按钮
        self.analyzeButton = PrimaryPushButton("加载并分析数据")
        self.analyzeButton.setFixedWidth(150)
        
        button_layout = QHBoxLayout()
        button_layout.addStretch(1)
        button_layout.addWidget(self.analyzeButton)
        button_layout.addStretch(1)
        
        self.vBoxLayout.addLayout(button_layout)
        self.vBoxLayout.addSpacing(20)
        
        # 连接信号
        self.dspDirButton.clicked.connect(self.onDspDirButtonClicked)
        self.androidLogButton.clicked.connect(self.onAndroidLogButtonClicked)
        self.dspLogButton.clicked.connect(self.onDspLogButtonClicked)
        self.analyzeButton.clicked.connect(self.onAnalyzeButtonClicked)
    
    def set_main_window(self, main_window):
        """设置主窗口引用"""
        self.main_window = main_window
    
    def onDspDirButtonClicked(self):
        """选择DSP目录"""
        directory = QFileDialog.getExistingDirectory(self, "选择DSP Dump目录")
        directory = linuxPath2winPath(directory)
        
        if directory:
            self.dsp_dir = directory
            self.dspDirLabel.setText(os.path.basename(directory))
            logger.info(f"选择DSP目录: {directory}")
    
    def onAndroidLogButtonClicked(self):
        """选择Android日志"""
        files, _ = QFileDialog.getOpenFileNames(
            self, "选择Android Log文件", "", 
            "Log files (*.log *.txt);;All files (*.*)"
        )
        
        if files:
            for file in files:
                file = linuxPath2winPath(file)
                if file not in self.android_logs:
                    self.android_logs.append(file)
            
            self.androidLogLabel.setText(f"已选择 {len(self.android_logs)} 个文件")
            logger.info(f"添加Android日志: {files}")
    
    def onDspLogButtonClicked(self):
        """选择DSP日志"""
        files, _ = QFileDialog.getOpenFileNames(
            self, "选择DSP Log文件", "", 
            "Log files (*.log *.txt);;All files (*.*)"
        )
        
        if files:
            for file in files:
                file = linuxPath2winPath(file)
                if file not in self.dsp_logs:
                    self.dsp_logs.append(file)
            
            self.dspLogLabel.setText(f"已选择 {len(self.dsp_logs)} 个文件")
            logger.info(f"添加DSP日志: {files}")
    
    def showErrorFlyout(self, title, content):
        """显示错误提示"""
        Flyout.create(
            icon=InfoBarIcon.ERROR,
            title=title,
            content=content,
            target=self.analyzeButton,
            parent=self.window()
        )
    
    def onAnalyzeButtonClicked(self):
        """开始分析"""
        # 验证输入
        if not self.dsp_dir:
            self.showErrorFlyout("目录选择错误", "请选择DSP Dump目录")
            return
        
        if not self.android_logs:
            self.showErrorFlyout("文件选择错误", "请至少选择一个Android Log文件")
            return
        
        if not self.dsp_logs:
            self.showErrorFlyout("文件选择错误", "请至少选择一个DSP Log文件")
            return
        
        # 清理可能存在的旧状态提示
        if self.stateTooltip:
            try:
                self.stateTooltip.close()
            except:
                pass
            self.stateTooltip = None
        
        # 显示状态提示
        try:
            self.stateTooltip = StateToolTip('正在分析数据', '请耐心等待...', self)
            self.stateTooltip.show()
        except Exception as e:
            logger.error(f"创建状态提示失败: {e}")
            self.stateTooltip = None
        
        # 禁用按钮
        self.analyzeButton.setDisabled(True)
        
        # 创建并启动工作线程
        try:
            self.worker = Worker(
                self.dsp_dir,
                self.android_logs,
                self.dsp_logs
            )
            
            self.worker.analysis_complete.connect(self.onAnalysisComplete)
            self.worker.progress_update.connect(self.onProgressUpdate)
            
            # 检查并连接信号到主窗口
            if self.main_window and hasattr(self.main_window, 'updateTokenTable'):
                self.worker.token_data_ready.connect(self.main_window.updateTokenTable)
                self.worker.audio_data_ready.connect(self.main_window.updateAudioTable)
                # 连接数据传递信号
                self.worker.analysis_complete.connect(lambda success, msg: self.onWorkerComplete(success, msg, self.worker))
            else:
                # 如果主窗口不可用，尝试使用父组件
                parent = self.parent()
                while parent and not hasattr(parent, 'updateTokenTable'):
                    parent = parent.parent()
                
                if parent and hasattr(parent, 'updateTokenTable'):
                    self.worker.token_data_ready.connect(parent.updateTokenTable)
                    self.worker.audio_data_ready.connect(parent.updateAudioTable)
                    # 连接数据传递信号
                    self.worker.analysis_complete.connect(lambda success, msg: self.onWorkerComplete(success, msg, self.worker))
                else:
                    logger.error("无法找到updateTokenTable方法")
            
            self.worker.start()
            
        except Exception as e:
            logger.error(f"启动工作线程失败: {e}")
            self.analyzeButton.setEnabled(True)
            if self.stateTooltip:
                self.stateTooltip.close()
                self.stateTooltip = None
            
            MessageBox("错误", f"启动分析失败:\n{str(e)}", self.window()).exec()
    
    def onWorkerComplete(self, success, message, worker):
        """处理worker完成事件，传递worker实例"""
        if success and self.main_window and hasattr(self.main_window, 'set_worker_data'):
            self.main_window.set_worker_data(worker)
        elif success:
            # 尝试向上查找
            parent = self.parent()
            while parent and not hasattr(parent, 'set_worker_data'):
                parent = parent.parent()
            
            if parent and hasattr(parent, 'set_worker_data'):
                parent.set_worker_data(worker)
    
    def onProgressUpdate(self, message):
        """处理进度更新"""
        logger.info(f"[分析进度] {message}")
    
    def onAnalysisComplete(self, success, message):
        """分析完成处理"""
        # 重新启用按钮
        self.analyzeButton.setEnabled(True)
        
        # 关闭状态提示
        if self.stateTooltip:
            self.stateTooltip.close()
            self.stateTooltip = None
        
        # 显示结果
        if success:
            MessageBox("分析完成", message, self.window()).exec()
        else:
            MessageBox("分析失败", message, self.window()).exec()


class AnalysisTab(QWidget):
    """DSP分析结果标签页"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.parent_widget = parent
        
        # 存储分析数据
        self.worker_instance = None
        self.token_map = {}
        self.audio_files = []
        
        # 创建标签页容器
        self.tab_widget = QTabWidget()
        
        # 创建各个标签页
        self.token_tab = self.createTokenTab()
        self.audio_tab = self.createAudioTab()
        self.conversion_tab = self.createConversionTab()
        
        # 添加标签页
        self.tab_widget.addTab(self.token_tab, "Token映射")
        self.tab_widget.addTab(self.audio_tab, "音频文件")
        self.tab_widget.addTab(self.conversion_tab, "时间转换")
        
        # 主布局
        layout = QVBoxLayout(self)
        layout.addWidget(self.tab_widget)
    
    def createTokenTab(self):
        """创建Token映射标签页"""
        widget = QWidget()
        layout = QVBoxLayout(widget)
        
        # 创建表格
        self.token_table = TableWidget()
        self.token_table.setColumnCount(6)
        self.token_table.setHorizontalHeaderLabels([
            "Token", "Android时间", "DSP时间", "时间差(ms)", 
            "Android文件", "DSP文件"
        ])
        
        # 设置表格属性
        self.token_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Interactive)
        self.token_table.setAlternatingRowColors(True)
        self.token_table.setBorderVisible(True)
        self.token_table.setBorderRadius(8)
        
        layout.addWidget(self.token_table)
        
        return widget
    
    def createAudioTab(self):
        """创建音频文件标签页"""
        widget = QWidget()
        layout = QVBoxLayout(widget)
        
        # 创建表格
        self.audio_table = TableWidget()
        self.audio_table.setColumnCount(6)
        self.audio_table.setHorizontalHeaderLabels([
            "音频文件", "标签文件", "开始时间", "结束时间", 
            "持续时间", "切片数量"
        ])
        
        # 设置表格属性
        self.audio_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Interactive)
        self.audio_table.setAlternatingRowColors(True)
        self.audio_table.setBorderVisible(True)
        self.audio_table.setBorderRadius(8)
        self.audio_table.setMinimumHeight(400)  # 设置最小高度
        
        # 启用右键菜单
        self.audio_table.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.audio_table.customContextMenuRequested.connect(self.showAudioContextMenu)
        
        layout.addWidget(self.audio_table)
        
        return widget
    
    def showAudioContextMenu(self, position):
        """显示音频表格的右键菜单"""
        # 获取点击的行
        row = self.audio_table.rowAt(position.y())
        if row < 0:
            return
        
        # 获取音频文件完整路径（第6列，索引5）
        wav_path_item = self.audio_table.item(row, 6)  # 第7列是完整路径
        if not wav_path_item:
            return
            
        wav_path = wav_path_item.text()
        if not wav_path or not os.path.exists(wav_path):
            return
        
        # 创建右键菜单
        menu = QMenu()
        
        # 添加"打开文件所在路径并选中wav文件"选项
        open_action = QAction("打开文件所在路径并选中wav文件", self)
        open_action.triggered.connect(lambda: self.openFileDirectoryAndSelect(wav_path))
        menu.addAction(open_action)
        
        # 显示菜单
        menu.exec(self.audio_table.viewport().mapToGlobal(position))
    
    def openFileDirectory(self, file_path):
        """打开文件所在目录"""
        try:
            if os.path.exists(file_path):
                # Windows系统
                if sys.platform == "win32":
                    # 使用explorer打开文件所在目录
                    folder_path = os.path.dirname(file_path)
                    subprocess.run(["explorer", folder_path])
                # macOS系统
                elif sys.platform == "darwin":
                    subprocess.run(["open", "-R", file_path])
                # Linux系统
                else:
                    folder_path = os.path.dirname(file_path)
                    subprocess.run(["xdg-open", folder_path])
            else:
                MessageBox("错误", f"文件不存在: {file_path}", self).exec()
        except Exception as e:
            MessageBox("错误", f"打开文件目录失败: {str(e)}", self).exec()
    
    def openFileDirectoryAndSelect(self, file_path):
        """打开文件所在目录并选中文件"""
        try:
            if os.path.exists(file_path):
                # Windows系统 - 使用/select参数选中文件
                if sys.platform == "win32":
                    # explorer /select,"文件路径" - 打开文件夹并选中文件
                    subprocess.run(['explorer', '/select,', file_path], shell=True)
                # macOS系统 - 使用open -R打开并选中文件
                elif sys.platform == "darwin":
                    subprocess.run(["open", "-R", file_path])
                # Linux系统 - 使用xdg-open打开文件夹
                else:
                    folder_path = os.path.dirname(file_path)
                    subprocess.run(["xdg-open", folder_path])
            else:
                MessageBox("错误", f"文件不存在: {file_path}", self).exec()
        except Exception as e:
            MessageBox("错误", f"打开文件目录失败: {str(e)}", self).exec()
    
    def createConversionTab(self):
        """创建时间转换标签页"""
        widget = QWidget()
        layout = QVBoxLayout(widget)
        
        # 音频→Android转换部分
        audio_group = GroupHeaderCardWidget()
        audio_group.setTitle("音频进度 → Android时间")
        
        # 音频文件选择
        audio_file_layout = QHBoxLayout()
        audio_file_layout.addWidget(BodyLabel("音频文件:"))
        self.audio_file_path = LineEdit()
        self.audio_file_path.setPlaceholderText("请选择音频文件")
        audio_file_layout.addWidget(self.audio_file_path, 1)
        self.audio_browse_button = PushButton("浏览")
        audio_file_layout.addWidget(self.audio_browse_button)
        
        # 时间输入
        time_layout = QHBoxLayout()
        time_layout.addWidget(BodyLabel("音频进度(MM:SS.sss):"))
        self.audio_time_input = LineEdit()
        self.audio_time_input.setPlaceholderText("00:00.000")
        time_layout.addWidget(self.audio_time_input, 1)
        
        # 转换按钮
        self.calc_android_button = PrimaryPushButton("计算Android时间点")
        
        audio_group.viewLayout.addLayout(audio_file_layout)
        audio_group.viewLayout.addLayout(time_layout)
        audio_group.viewLayout.addWidget(self.calc_android_button)
        
        # Android→音频转换部分
        android_group = GroupHeaderCardWidget()
        android_group.setTitle("Android时间 → 音频进度")
        
        # 日期时间输入
        datetime_layout = QHBoxLayout()
        datetime_layout.addWidget(BodyLabel("日期(MM-DD):"))
        self.android_date_input = LineEdit()
        self.android_date_input.setPlaceholderText("02-02")
        datetime_layout.addWidget(self.android_date_input, 1)
        
        time2_layout = QHBoxLayout()
        time2_layout.addWidget(BodyLabel("时间(HH:MM:SS.sss):"))
        self.android_time_input = LineEdit()
        self.android_time_input.setPlaceholderText("16:09:58.902")
        time2_layout.addWidget(self.android_time_input, 1)
        
        # 转换按钮
        self.find_audio_button = PrimaryPushButton("查找相关音频进度")
        
        android_group.viewLayout.addLayout(datetime_layout)
        android_group.viewLayout.addLayout(time2_layout)
        android_group.viewLayout.addWidget(self.find_audio_button)
        
        # 结果展示区域
        result_label = BodyLabel("转换结果:")
        
        # 创建结果显示表格
        self.result_table = TableWidget()
        self.result_table.setColumnCount(7)
        self.result_table.setHorizontalHeaderLabels([
            "音频文件", "标签文件", "音频进度", "开始时间", 
            "结束时间", "绝对DSP时间", "完整路径"
        ])
        
        # 设置表格属性 - 增加表格行高和最小高度
        self.result_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Interactive)
        self.result_table.setAlternatingRowColors(True)
        self.result_table.setBorderVisible(True)
        self.result_table.setBorderRadius(8)
        self.result_table.setMinimumHeight(400)  # 设置更大的最小高度
        self.result_table.verticalHeader().setDefaultSectionSize(40)  # 增加行高
        self.result_table.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOn)  # 总是显示垂直滚动条
        
        # 设置列宽
        self.result_table.setColumnWidth(0, 200)  # 音频文件列
        self.result_table.setColumnWidth(1, 150)  # 标签文件列
        self.result_table.setColumnWidth(2, 120)  # 音频进度列
        self.result_table.setColumnWidth(3, 150)  # 开始时间列
        self.result_table.setColumnWidth(4, 150)  # 结束时间列
        self.result_table.setColumnWidth(5, 150)  # 绝对DSP时间列
        
        # 隐藏完整路径列
        self.result_table.setColumnHidden(6, True)
        
        # 启用右键菜单
        self.result_table.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.result_table.customContextMenuRequested.connect(self.showResultContextMenu)
        
        # 创建滚动区域包装结果表格
        result_table_scroll = PyQtScrollArea()
        result_table_scroll.setWidget(self.result_table)
        result_table_scroll.setWidgetResizable(True)
        result_table_scroll.setMinimumHeight(450)  # 设置滚动区域的最小高度
        result_table_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOn)
        
        # 结果摘要文本
        self.result_summary = TextEdit()
        self.result_summary.setReadOnly(True)
        self.result_summary.setMaximumHeight(200)  # 设置最大高度
        
        # 创建结果区域标签页
        result_tab_widget = QTabWidget()
        result_tab_widget.addTab(self.result_summary, "结果摘要")
        result_tab_widget.addTab(result_table_scroll, "音频文件列表")  # 使用滚动区域
        
        # 设置标签页高度策略
        result_tab_widget.setMinimumHeight(500)  # 设置标签页的最小高度
        
        # 添加到主布局
        layout.addWidget(audio_group)
        layout.addSpacing(20)
        layout.addWidget(android_group)
        layout.addSpacing(20)
        layout.addWidget(result_label)
        layout.addWidget(result_tab_widget, 1)  # 使用拉伸因子1使其占据剩余空间
        
        # 连接信号
        self.audio_browse_button.clicked.connect(self.onAudioBrowseClicked)
        self.calc_android_button.clicked.connect(self.onCalcAndroidClicked)
        self.find_audio_button.clicked.connect(self.onFindAudioClicked)
        
        return widget
    
    def showResultContextMenu(self, position):
        """显示结果表格的右键菜单"""
        # 获取点击的行
        row = self.result_table.rowAt(position.y())
        if row < 0:
            return
        
        # 获取音频文件完整路径（第7列，索引6）
        wav_path_item = self.result_table.item(row, 6)  # 第7列是完整路径
        if not wav_path_item:
            return
            
        wav_path = wav_path_item.text()
        if not wav_path or not os.path.exists(wav_path):
            return
        
        # 创建右键菜单
        menu = QMenu()
        
        # 添加"打开文件所在路径并选中wav文件"选项
        open_action = QAction("打开文件所在路径并选中wav文件", self)
        open_action.triggered.connect(lambda: self.openFileDirectoryAndSelect(wav_path))
        menu.addAction(open_action)
        
        # 显示菜单
        menu.exec(self.result_table.viewport().mapToGlobal(position))
    
    def onAudioBrowseClicked(self):
        """浏览音频文件"""
        file_path, _ = QFileDialog.getOpenFileName(
            self, "选择音频文件", "", 
            "WAV files (*.wav);;All files (*.*)"
        )
        
        if file_path:
            self.audio_file_path.setText(file_path)
    
    def time_str_to_ms(self, time_str):
        """将时间字符串转换为毫秒"""
        try:
            parts = time_str.split(':')
            ms = 0
            
            if len(parts) == 3:  # HH:MM:SS.sss
                ms += int(parts[0]) * 3600000
                ms += int(parts[1]) * 60000
                sec_parts = parts[2].split('.')
                ms += int(sec_parts[0]) * 1000
                if len(sec_parts) > 1:
                    ms_part = sec_parts[1].ljust(3, '0')[:3]
                    ms += int(ms_part)
            elif len(parts) == 2:  # MM:SS.sss
                ms += int(parts[0]) * 60000
                sec_parts = parts[1].split('.')
                ms += int(sec_parts[0]) * 1000
                if len(sec_parts) > 1:
                    ms_part = sec_parts[1].ljust(3, '0')[:3]
                    ms += int(ms_part)
                    
            return ms
        except:
            return 0
    
    def ms_to_time_str(self, ms):
        """毫秒转时间字符串"""
        hours = ms // 3600000
        ms %= 3600000
        minutes = ms // 60000
        ms %= 60000
        seconds = ms // 1000
        milliseconds = ms % 1000
        
        return f"{hours:02d}:{minutes:02d}:{seconds:02d}.{milliseconds:03d}"
    
    def ms_to_audio_progress_str(self, ms):
        """毫秒转音频进度格式"""
        minutes = ms // 60000
        ms %= 60000
        seconds = ms // 1000
        milliseconds = ms % 1000
        
        return f"{minutes}:{seconds:02d}.{milliseconds:03d}"
    
    def onCalcAndroidClicked(self):
        """计算Android时间点"""
        if not self.worker_instance or not self.worker_instance.token_map:
            self.result_summary.setText("错误：请先加载并分析数据")
            return
        
        audio_file_path = self.audio_file_path.text()
        time_str = self.audio_time_input.text()
        
        if not audio_file_path or not time_str:
            self.result_summary.setText("错误：请选择音频文件并输入时间")
            return
        
        # 查找对应的labels文件
        label_path = None
        base_name = os.path.splitext(audio_file_path)[0]
        for ext in ['.labels', '.labels.txt']:
            if os.path.exists(base_name + ext):
                label_path = base_name + ext
                break
        
        if not label_path:
            self.result_summary.setText(f"错误：未找到对应的labels文件: {audio_file_path}")
            return
        
        # 解析labels文件
        audio_info = self.parse_label_file(label_path, audio_file_path)
        if not audio_info:
            self.result_summary.setText("错误：无法解析labels文件")
            return
        
        # 将输入时间转换为毫秒（相对于音频开始）
        try:
            progress_ms = self.time_str_to_ms(time_str)
            
            # 计算对应的DSP绝对时间（毫秒）
            dsp_absolute_ms = audio_info['start_time_ms'] + progress_ms
            
            # 将DSP时间转换为时间字符串
            dsp_time_str = self.ms_to_time_str(dsp_absolute_ms)
            
            # 找到最接近的token进行时间转换
            closest_token = None
            min_time_diff = float('inf')
            closest_mapping = None
            
            for token, mapping in self.worker_instance.token_map.items():
                dsp_entry_time_ms = self.time_str_to_ms(mapping['dsp']['time_str'])
                time_diff = abs(dsp_absolute_ms - dsp_entry_time_ms)
                
                if time_diff < min_time_diff:
                    min_time_diff = time_diff
                    closest_token = token
                    closest_mapping = mapping
            
            if closest_token:
                # 计算Android时间
                android_time = closest_mapping['android']['time']
                dsp_token_time = closest_mapping['dsp']['time']
                
                # 计算时间偏移
                time_offset = (dsp_absolute_ms / 1000.0) - (self.time_str_to_ms(closest_mapping['dsp']['time_str']) / 1000.0)
                
                # 计算对应的Android时间
                target_android_time = android_time + timedelta(seconds=time_offset)
                
                # 格式化输出
                android_time_str = target_android_time.strftime("%m-%d %H:%M:%S.%f")[:-3]
                
                # 显示结果摘要
                summary_text = f"=== 音频问题点分析结果 ===\n\n"
                summary_text += f"音频文件: {os.path.basename(audio_file_path)}\n"
                summary_text += f"标签文件: {os.path.basename(label_path)}\n"
                summary_text += f"音频进度: {time_str}\n"
                summary_text += f"对应的DSP时间: {dsp_time_str}\n"
                summary_text += f"使用的Token: {closest_token}\n"
                summary_text += f"对应的Android时间: {android_time_str}\n"
                summary_text += f"时间偏差: {min_time_diff:.2f} ms\n\n"
                summary_text += f"Token参考信息:\n"
                summary_text += f"  Android时间: {closest_mapping['android']['time_str']}\n"
                summary_text += f"  DSP时间: {closest_mapping['dsp']['time_str']}\n"
                summary_text += f"  原始时间差: {closest_mapping['time_diff_ms']:.2f} ms"
                
                self.result_summary.setText(summary_text)
                
                # 清空结果表格
                self.result_table.setRowCount(0)
                
                # 在结果表格中添加找到的音频文件信息
                self.result_table.setRowCount(1)
                
                # 计算在音频文件中的进度
                progress_str = self.ms_to_audio_progress_str(progress_ms)
                
                # 添加数据到表格
                self.result_table.setItem(0, 0, QTableWidgetItem(os.path.basename(audio_file_path)))
                self.result_table.setItem(0, 1, QTableWidgetItem(os.path.basename(label_path)))
                self.result_table.setItem(0, 2, QTableWidgetItem(progress_str))
                self.result_table.setItem(0, 3, QTableWidgetItem(self.ms_to_time_str(audio_info['start_time_ms'])))
                self.result_table.setItem(0, 4, QTableWidgetItem(self.ms_to_time_str(audio_info['end_time_ms'])))
                self.result_table.setItem(0, 5, QTableWidgetItem(dsp_time_str))
                self.result_table.setItem(0, 6, QTableWidgetItem(audio_file_path))  # 完整路径，用于右键菜单
            else:
                self.result_summary.setText("错误: 未找到合适的Token进行时间转换")
                
        except Exception as e:
            self.result_summary.setText(f"错误: 时间转换错误: {str(e)}")
    
    def parse_label_file(self, label_path, wav_path):
        """解析labels文件"""
        try:
            with open(label_path, 'r', encoding='utf-8') as f:
                lines = f.readlines()
            
            time_points = []
            for line in lines:
                line = line.strip()
                if line and 'timestamp:' in line:
                    match = re.search(r'timestamp:(\d{2}:\d{2}:\d{2}\.\d{3})', line)
                    if match:
                        time_str = match.group(1)
                        ms = self.time_str_to_ms(time_str)
                        time_points.append(ms)
            
            if time_points:
                return {
                    'wav_file': wav_path,
                    'label_file': label_path,
                    'start_time_ms': time_points[0] if time_points else 0,
                    'end_time_ms': time_points[-1] if time_points else 0,
                    'slices': time_points,
                    'duration_ms': time_points[-1] - time_points[0] if len(time_points) >= 2 else 0
                }
        except Exception as e:
            logger.error(f"解析label文件错误: {label_path}, {e}")
        
        return None
    
    def onFindAudioClicked(self):
        """查找Android时间点对应的音频进度"""
        if not self.worker_instance or not self.worker_instance.token_map:
            self.result_summary.setText("错误：请先加载并分析数据")
            return
        
        date_str = self.android_date_input.text()
        time_str = self.android_time_input.text()
        
        if not date_str or not time_str:
            self.result_summary.setText("错误：请输入完整的日期和时间")
            return
        
        try:
            # 创建Android时间对象
            android_time_str = f"{date_str} {time_str}"
            android_time = datetime.strptime(android_time_str, "%m-%d %H:%M:%S.%f")
            
            # 找到最接近的token
            closest_token = None
            min_time_diff = float('inf')
            closest_mapping = None
            
            for token, mapping in self.worker_instance.token_map.items():
                token_android_time = mapping['android']['time']
                time_diff = abs((android_time - token_android_time).total_seconds())
                
                if time_diff < min_time_diff:
                    min_time_diff = time_diff
                    closest_token = token
                    closest_mapping = mapping
            
            if closest_token:
                # 计算对应的DSP时间
                android_token_time = closest_mapping['android']['time']
                dsp_token_time = closest_mapping['dsp']['time']
                
                # 计算时间偏移
                time_offset = (android_time - android_token_time).total_seconds()
                
                # 计算对应的DSP时间
                target_dsp_time = dsp_token_time + timedelta(seconds=time_offset)
                target_dsp_ms = self.time_str_to_ms(target_dsp_time.strftime("%H:%M:%S.%f")[:-3])
                
                # 显示结果摘要
                summary_text = f"=== Android问题点分析结果 ===\n\n"
                summary_text += f"Android时间: {android_time_str}\n"
                summary_text += f"使用的Token: {closest_token}\n"
                summary_text += f"对应的DSP时间: {target_dsp_time.strftime('%H:%M:%S.%f')[:-3]}\n"
                summary_text += f"时间偏差: {min_time_diff:.4f} 秒\n\n"
                summary_text += f"Token参考信息:\n"
                summary_text += f"  Android时间: {closest_mapping['android']['time_str']}\n"
                summary_text += f"  DSP时间: {closest_mapping['dsp']['time_str']}\n"
                
                self.result_summary.setText(summary_text)
                
                # 清空结果表格
                self.result_table.setRowCount(0)
                
                # 查找包含该DSP时间的音频文件
                found_files = False
                row_count = 0
                if hasattr(self.worker_instance, 'audio_files'):
                    for audio_info in self.worker_instance.audio_files:
                        if (audio_info['start_time_ms'] <= target_dsp_ms <= audio_info['end_time_ms']):
                            # 计算在音频文件中的进度
                            progress_ms = target_dsp_ms - audio_info['start_time_ms']
                            progress_str = self.ms_to_audio_progress_str(progress_ms)
                            
                            # 添加新行
                            row_position = self.result_table.rowCount()
                            self.result_table.insertRow(row_position)
                            
                            # 添加数据到表格
                            self.result_table.setItem(row_position, 0, QTableWidgetItem(os.path.basename(audio_info['wav_file'])))
                            self.result_table.setItem(row_position, 1, QTableWidgetItem(os.path.basename(audio_info['label_file'])))
                            self.result_table.setItem(row_position, 2, QTableWidgetItem(progress_str))
                            self.result_table.setItem(row_position, 3, QTableWidgetItem(self.ms_to_time_str(audio_info['start_time_ms'])))
                            self.result_table.setItem(row_position, 4, QTableWidgetItem(self.ms_to_time_str(audio_info['end_time_ms'])))
                            self.result_table.setItem(row_position, 5, QTableWidgetItem(self.ms_to_time_str(target_dsp_ms)))
                            self.result_table.setItem(row_position, 6, QTableWidgetItem(audio_info['wav_file']))  # 完整路径，用于右键菜单
                            
                            found_files = True
                            row_count += 1
                
                if not found_files:
                    self.result_summary.setText(summary_text + "\n\n涉及到的音频文件:\n  未找到包含该时间点的音频文件")
                else:
                    # 更新摘要信息
                    current_summary = self.result_summary.toPlainText()
                    self.result_summary.setText(current_summary + f"\n\n找到 {row_count} 个包含该时间点的音频文件")
                    
            else:
                self.result_summary.setText("错误: 未找到合适的Token进行时间转换")
                
        except Exception as e:
            self.result_summary.setText(f"错误: 时间转换错误: {str(e)}")
    
    def updateTokenTable(self, token_data):
        """更新Token表格"""
        self.token_table.setRowCount(len(token_data))
        
        for row, data in enumerate(token_data):
            for col, value in enumerate(data):
                item = QTableWidgetItem(str(value))
                self.token_table.setItem(row, col, item)
    
    def updateAudioTable(self, audio_data):
        """更新音频表格"""
        self.audio_table.setRowCount(len(audio_data))
        
        for row, data in enumerate(audio_data):
            # 只显示前6列（最后2列是完整路径，不显示）
            for col, value in enumerate(data[:6]):
                item = QTableWidgetItem(str(value))
                self.audio_table.setItem(row, col, item)
            
            # 存储完整路径到隐藏列
            if len(data) > 6:
                wav_path_item = QTableWidgetItem(data[6])  # 音频文件完整路径
                self.audio_table.setItem(row, 6, wav_path_item)
                
            if len(data) > 7:
                label_path_item = QTableWidgetItem(data[7])  # 标签文件完整路径
                self.audio_table.setItem(row, 7, label_path_item)
    
    def set_worker_data(self, worker):
        """设置worker实例数据"""
        self.worker_instance = worker
        if hasattr(worker, 'token_map'):
            self.token_map = worker.token_map
        if hasattr(worker, 'audio_files'):
            self.audio_files = worker.audio_files


class DSPAudio_AnalyzerCardsInfo(ScrollArea):
    """DSP音频时间对齐工具主界面"""

    def __init__(self, parent=None, routeKey=None):
        super().__init__(parent=parent)
        self.view = QWidget(self)
        self.routeKey = routeKey
        
        self.vBoxLayout = QVBoxLayout(self.view)
        self.infoCard = AppInfoCard(parent=self)
        self.descriptionCard = DescriptionCard(self)
        self.settingCard = SettingsCard(self)
        self.analysisTab = AnalysisTab(self)
        
        # 设置主窗口引用
        self.settingCard.set_main_window(self)
        
        self.setWidget(self.view)
        self.setWidgetResizable(True)
        self.setObjectName(routeKey)
        
        self.vBoxLayout.setSpacing(25)
        self.vBoxLayout.setContentsMargins(0, 0, 10, 30)
        self.vBoxLayout.addWidget(self.infoCard, 0, Qt.AlignmentFlag.AlignTop)
        self.vBoxLayout.addWidget(self.descriptionCard, 1, Qt.AlignmentFlag.AlignTop)
        self.vBoxLayout.addWidget(self.settingCard, 2, Qt.AlignmentFlag.AlignTop)
        self.vBoxLayout.addWidget(self.analysisTab, 3, Qt.AlignmentFlag.AlignTop)
        
        self.enableTransparentBackground()
    
    def updateTokenTable(self, token_data):
        """更新Token表格（供外部调用）"""
        self.analysisTab.updateTokenTable(token_data)
    
    def updateAudioTable(self, audio_data):
        """更新音频表格（供外部调用）"""
        self.analysisTab.updateAudioTable(audio_data)
    
    def set_worker_data(self, worker):
        """设置worker实例数据（供外部调用）"""
        self.analysisTab.set_worker_data(worker)


class DSPAudio_Analyzerinterface:
    """DSP音频时间对齐工具接口类"""
    
    def __init__(self, parent=None, mainWindow=None):
        self.parent = parent
        self.mainWindow = mainWindow

    def addTab(self, routeKey, text, icon):
        """添加标签页到主界面"""
        logger.info('[TAB ADD] {}'.format(routeKey))
        self.mainWindow.tabBar.addTab(routeKey, text, icon)
        
        # 添加DSP分析界面
        self.mainWindow.showInterface.addWidget(DSPAudio_AnalyzerCardsInfo(routeKey=routeKey))
        
        # 切换到当前界面
        current_widget = self.mainWindow.showInterface.findChild(DSPAudio_AnalyzerCardsInfo, routeKey)
        if current_widget:
            self.mainWindow.showInterface.setCurrentWidget(current_widget)
            self.mainWindow.stackedWidget.setCurrentWidget(self.mainWindow.showInterface)
            self.mainWindow.tabBar.setCurrentIndex(self.mainWindow.tabBar.count() - 1)