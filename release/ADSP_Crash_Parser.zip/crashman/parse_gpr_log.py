"""
\file
    parse_gpr_log.py

\brief
    Parses gpr logs dumped by t32 -- see README.txt

\copyright
    Copyright (c) 2020-2021 Qualcomm Technologies, Inc.
     All Rights Reserved.
     Confidential and Proprietary - Qualcomm Technologies, Inc.
"""

from __future__ import print_function
import struct
import sys
import argparse
import copy
from os import path
import json

from binascii import hexlify

# Helpful constants from gpr_packet.h
GPR_PKT_VERSION_MASK = 0x0000000F # Bitmask of the version field.
GPR_PKT_VERSION_SHFT = 0 # Bit shift of the version field.
GPR_PKT_HEADER_SIZE_MASK = 0x000000F0 # Bitmask of the header size field.
GPR_PKT_HEADER_SIZE_SHFT = 4 # Bit shift of the header size field.
GPR_PKT_RESERVED_MASK = 0xFFF00000 # Bitmask of the reserved field. Includes 4 reserved bits from client data field 
GPR_PKT_RESERVED_SHFT = 20 # Bit shift of the reserved field.
GPR_PKT_PACKET_SIZE_MASK = 0xFFFFFF00 # Bitmask of the packet size field.
GPR_PKT_PACKET_SIZE_SHFT = 8 # Bit shift of the packet size field.

GPR_LOG_START_WORD = b'GPRSTART'
SYNC_WORD = 0xE91111E9

SIZE_ERROR_MSG = """
FATAL: there was a problem parsing the gpr packet. This is most likely because someone changed the definition of gpr_packet_t, \
AND the header field had not been filled to the correct size. Please double check both of these. For a temprorary fix you can \
increase the value of SIZE_FLOOR. Exiting.
"""
SIZE_FLOOR = 28

GUID_CFG_PATH = sys.path[0]
GUID_MAP = {}

with open(path.join(GUID_CFG_PATH, "guid_mapper.json")) as f:
    try:
        GUID_MAP = json.load(f)
    except ValueError as e:
        sys.exit('Error: parsing JSON file ' + guid_mapper)


class GPRPacket:
    # Create the packet from the required fields
    def __init__(self, timestamp, header, dst_domain_id, src_domain_id, client_data, src_port, dst_port, token, opcode):
        self.timestamp = timestamp
        self.version = (header & GPR_PKT_VERSION_MASK) >> GPR_PKT_VERSION_SHFT
        self.header_size = (header & GPR_PKT_HEADER_SIZE_MASK) >> GPR_PKT_HEADER_SIZE_SHFT
        self.packet_size =  (header & GPR_PKT_PACKET_SIZE_MASK) >> GPR_PKT_PACKET_SIZE_SHFT
        self.dst_domain_id = dst_domain_id
        self.src_domain_id = src_domain_id
        self.client_data = client_data
        self.src_port = src_port
        self.dst_port = dst_port
        self.token = token
        self.opcode = opcode
        self.payload = None

    def pprint(self, handle):
        # Print the contents of the packet in human readable format
        handle.write("Packet sent at: {}...".format(self.timestamp))
        handle.write("Version {} Header Size: {} Packet Size {}".format(self.version, self.header_size, self.packet_size))
        handle.write("Dest Domain ID: {} Source Domain ID: {}".format(self.dst_domain_id, self.src_domain_id))
        handle.write("Dest Port: {} Source port: {}".format(self.dst_port, self.src_port))
        handle.write("Client data: 0x{:X} Token: 0x{:X} Opcode: 0x{:X}".format(self.client_data, self.token, self.opcode))
        if self.payload is not None:
            handle.write(hexlify(self.payload))


    def __str__(self):
        payload_size = len(self.payload) if self.payload is not None else 0
        usec = int(self.timestamp) % 1000
        msec = int((self.timestamp) / 1000) % 1000
        secs = int(((self.timestamp / 1000) - msec) / 1000) % 60
        mins = int(((((self.timestamp / 1000) - msec) / 1000) - secs) / 60) % 60
        # hrs =  int((((((self.timestamp / 1000) - msec) / 1000) - secs) / 60) - mins) / 60 # may want to use later
        try:
            opcode_text = GUID_MAP["0x{:08X}".format(self.opcode)]
        except KeyError:
            # Unrecognized guid, this probably means that the guid_mapper.json is older than the adsp build
            print("WARNING: Unrecognized opcode. Please check what build your guid_mapper.json belongs to!!")
            opcode_text = "UNKNOWN"
        
        rv =  "{:02}:{:02}:{:03}:{:03}|<{:02X}-0x{:08X}><{:02X}-0x{:08X}>{{0x{:08X}}}[0x{:08X}],{:};{:}\n".format(
            mins, secs, msec,usec,
            self.src_domain_id, self.src_port,
            self.dst_domain_id, self.dst_port,
            self.token, self.opcode, payload_size, 
            opcode_text)

        if self.payload is not None:
            rv += "\n"
            payload = hexlify(self.payload)
            payload_formatted = ""
            byte_count = 0
            for i,k in zip(payload[0::2], payload[1::2]):
                if (byte_count & 0b1111) == 0:
                    payload_formatted += "\n{:08X} ".format(byte_count)
                if (byte_count & 0b111) == 0:
                    payload_formatted += "|  "
                
                if sys.version_info[0] == 3:
                    payload_formatted += chr(i) + chr(k) + " "
                else:
                    payload_formatted += i + k + " "


                if (byte_count & 0b11) == 3:
                    payload_formatted += "  "              

                byte_count += 1

            rv += payload_formatted+"\n\n"
        
        return rv

# get the size of a packet (with regard to how long to parse) and return it
def get_packet_size(input_bin, has_payload):
    input_bin = input_bin[8:]
    header = struct.unpack('I', input_bin[:4])[0]
    # It turns out that packets can lie about their size. Put a floor based on the minimum possible sized header.

    if has_payload:
        return max((SIZE_FLOOR, (header & GPR_PKT_PACKET_SIZE_MASK) >> GPR_PKT_PACKET_SIZE_SHFT))
    else:
        return max((SIZE_FLOOR, (header & GPR_PKT_HEADER_SIZE_MASK) >> GPR_PKT_HEADER_SIZE_SHFT))

# parse a packet
def parse_packet(input_bin, has_payload, was_roll = False):
    timestamp = struct.unpack('Q', input_bin[:8])[0]
    input_bin = input_bin[8:]
    header = struct.unpack('I', input_bin[:4])[0]

    # python 2 and 3 treat indexing a single byte in a byte string differently 
    if sys.version_info[0] == 3:
        dst_domain_id = input_bin[4]
        src_domain_id = input_bin[5]
        client_data = input_bin[6]
    else:
        dst_domain_id = struct.unpack('B',input_bin[4])[0]
        src_domain_id = struct.unpack('B',input_bin[5])[0]
        client_data = struct.unpack('B',input_bin[6])[0]
    # byte 7 is resereved but unused
    src_port = struct.unpack('I', input_bin[8:12])[0]
    dst_port = struct.unpack('I', input_bin[12:16])[0]
    token = struct.unpack('I', input_bin[16:20])[0]
    opcode = struct.unpack('I', input_bin[20:24])[0]
    
    pkt = GPRPacket(timestamp, header, dst_domain_id, src_domain_id, client_data, src_port, dst_port, token, opcode)
    pkt.was_roll = was_roll

    if (has_payload):
        pkt.payload = copy.deepcopy(input_bin[24:pkt.packet_size])
        return (pkt, input_bin[pkt.packet_size:])
    else:
        #pkt.payload = input_bin[24:pkt.packet_size]
        return (pkt, input_bin[pkt.packet_size:])


# Parse a file from sim that has been dumping the gpr packets
def parse_log_file(input_bin):
    # detect if logfile contains payloads by looking for magic numbers
    has_payload = False
    if input_bin[:2] == b"pp":
        has_payload = True
        input_bin = input_bin[2:]

    pkt, remaining_data = parse_packet(input_bin, has_payload)
    rv = [pkt]
    while (remaining_data):
        pkt, remaining_data = parse_packet(remaining_data, has_payload)
        rv.append(pkt)

    return rv


# Parse a ramdump collected from t32
def parse_ram_dump(input_bin):
    start_word = input_bin[:8]
    assert start_word == GPR_LOG_START_WORD
    input_bin = input_bin[8:]
    bufsize = struct.unpack('I', input_bin[:4])[0]
    offset = struct.unpack('I', input_bin[4:8])[0]
    log_payloads = struct.unpack('I', input_bin[8:12])[0]
    if log_payloads == 0:
        has_payload = False
    else:
        has_payload = True

    buf = input_bin[12:12+bufsize]

    roll_amount = 0
    prev_offset = offset

    results = []
    starting_offset = offset
    is_done = False
    while True:
        has_rolled = False
        # Search for the next sync word
        prev_offset = offset
        while True:
            offset -= 4
            if offset < 0:
                has_rolled = True
                roll_amount = prev_offset
                offset = bufsize - 4 # trust that packets are 32-bit aligned
            
            if offset == starting_offset:
                # exhausted the buffer
                is_done = True
                break

            sync_word = struct.unpack('I', buf[offset:offset+4])[0]
            if sync_word == 0xE91111E9:
                # found another packet
                break

        if is_done == True:
            break
        start_pos = offset + 4

        packet_size = 0
        # special case if even getting the size would cause a roll
        if (bufsize - start_pos) < 12:
            tmp_buf = b"".join([buf[start_pos:bufsize], buf[:roll_amount]])
            packet_size = get_packet_size(tmp_buf, has_payload)
        else:
            packet_size = get_packet_size(buf[start_pos:], has_payload)

        try:
            if has_rolled:
                tmp_buf = b"".join([buf[start_pos:bufsize], buf[:roll_amount]])
                pkt, rem = parse_packet(tmp_buf, has_payload, True)
                results.append(pkt)
            else:
                finish_pos = start_pos+packet_size+8
                pkt, rem = parse_packet(buf[start_pos:finish_pos], has_payload)
                results.append(pkt)
        except (struct.error, IndexError) as e:
            print(SIZE_ERROR_MSG)
            raise e

    results.reverse()
    return results



def main():
    parser = argparse.ArgumentParser(description='Parses the gpr log dumps so they can be viewed in a human readable format.')
    parser.add_argument("-v", "--verbose", help="Make the prints more detailed")
    parser.add_argument("-o", "--output", nargs='?',  help="Writes the output to the specified filename (default is stdout)")
    parser.add_argument("filename", help="File name to be read from")
   
    args = parser.parse_args()
    output_handle = sys.stdout

    if (args.output):
        output_handle = open(args.output, "w")

    data = b""
    with open(args.filename, "rb") as f:
        data = f.read()

    results = []

    results = parse_ram_dump(data)

    
    
    output_handle.write("  Timestamp      Source        Destination\n")
    output_handle.write("m :s :ms :us |Domain    Port |Domain   Port |Token      |Opcode    |Size\n")

    for pkt in results:
        if args.verbose:
            pkt.pprint(output_handle)
        else:
            output_handle.write(str(pkt))


if __name__ == '__main__':
    main()
