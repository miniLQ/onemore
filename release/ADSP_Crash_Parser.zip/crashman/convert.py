# ------------------------------------------------------------------
#
# Copyright (c) 2019-2020 Qualcomm Technologies, Inc.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
# ------------------------------------------------------------------

import os
import re
import subprocess
import sys
import time
import datetime
import fnmatch
import io
import shutil, errno
from os import walk


def format(file_in,file_out):

	#open the file and read all the lines
	f_in = io.open(file_in, 'r',encoding="utf-8",errors = 'ignore')
	lines = f_in.readlines()
	f_in.close()

	f_out = open(file_out, 'w')
	
	for line in lines:
		line_t = ""
		try:
			hex = line.split()[0].split(':')[0]
			time = int(hex,16)/19200000.000
			ms = str(time).split('.')[1]
			total_secs = int(time)
			hours = total_secs // 3600
			minutes = (total_secs % 3600) // 60
			seconds = total_secs % 60
			line_t = line.replace(hex,hex+"  "+str(hours).zfill(2)+":"+str(minutes).zfill(2)+":" +str(seconds).zfill(2)+":"+str(ms).zfill(3)[:3]+"  "+str(total_secs).zfill(2)+"."+str(ms).zfill(6)[:6])
			f_out.write(line_t)
		except:
			pass

	f_out.close()
    
    
    
    
def main():
	OutputPath  = sys.argv[1]
	pgt_file = OutputPath+"/DSP_pgt.txt"
	
	if os.path.isfile(pgt_file):
		f_dsppgt = open(pgt_file,'r')
		f_bsc = open(OutputPath+"/DSP_pgt_converted.txt",'w')
		flag="old"
		for line_dsppgt in f_dsppgt:
			if ("task.pgt" in line_dsppgt):
				continue
			if ("VA" in line_dsppgt):
				flag="new"
				break
		f_dsppgt.close()
		
		f_dsppgt = open(pgt_file,'r')
		for line_dsppgt in f_dsppgt:
			if (flag=="old"):
				f_bsc.write(line_dsppgt)
			if (flag=="new"):
				if ( line_dsppgt[0:2] == '0x'):
					list_dsppgt = line_dsppgt.split('*')
					#print list_dsppgt
					f_bsc.write(list_dsppgt[0][0:7]+"  *"+"0x{:06x}".format(int(list_dsppgt[1],16)>>12)+" *"+list_dsppgt[3]+"\n")

		f_bsc.close()
		f_dsppgt.close()

	
if __name__ == '__main__':
	main()
