# ------------------------------------------------------------------
#
# Copyright (c) 2019-2020 Qualcomm Technologies, Inc.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
# ------------------------------------------------------------------

import re
import sys
import os
from collections import OrderedDict
OutputPath_temp  = sys.argv[1]
DumpPath = os.path.dirname(sys.argv[2])

# fileptr = open(DumpPath+"/load.cmm",'r')
# linelist = fileptr.readlines()
# # linelist = list(filter(lambda x: x if ('DDRCS' in x and 'binary' in x) else '', linelist ))
# linelist = list(filter(lambda x: x if ('binary' in x and not 'OCIMEM' in x.upper() ) else '', linelist ))
# DumpFileList = [i.split()[1] for i in linelist]
# DumpFileStartAddressList = [i.split()[2] for i in linelist]
# DumpFileStartAddressIntFormList = [int(i.split()[2],16) for i in linelist]
# fileptr.close()

DumpFilesStartAddressDict = {}
DumpFilesStartAddress_Ordered_Dict = OrderedDict()
with open(DumpPath+'/load.cmm') as fileptr:
    for line in fileptr:
        if 'd.load' in line.lower():
            line = line.split('\n')[0].strip().split(' ')
            if 'ddrc' in line[1][:4].lower() or 'dram' in line[1][:4].lower():
                DumpFilesStartAddressDict[line[1].strip()] = int(line[2].strip(), 0)
    DumpFilesStartAddressDict = sorted(DumpFilesStartAddressDict.items(),
                                       key=lambda kv: kv[1])  # sort Dict by Start_Address
    for dumpfile, address in DumpFilesStartAddressDict:
        DumpFilesStartAddress_Ordered_Dict[dumpfile] = {'startadd': address,
                                                        'endadd': address+os.path.getsize(DumpPath+'/'+dumpfile)}
    # for dumpfile, address in DumpFilesStartAddress_Ordered_Dict.items():
        # print(dumpfile, hex(address['startadd']), hex(address['endadd']))
        # print(dumpfile, address['startadd'], address['endadd'])
    pass


def get_proper_dumpfile_based_on_apps_phy_address(py_add):
    for dumpfilename, dumpfile_address in DumpFilesStartAddress_Ordered_Dict.items():
        if dumpfile_address['startadd'] <= py_add < dumpfile_address['endadd']:
            return dumpfilename, hex(dumpfile_address['startadd'])
    return 'NA', 'NA'


fileptr = open(OutputPath_temp+"/memheap_section.txt",'r')
memheapfilelinelist = fileptr.readlines()
fileptr.close()
number_of_sections = 0
for line in memheapfilelinelist: 
	if "number_of_sections" in line: number_of_sections = int(line.split()[2], 16)

command_list = []
for cnt in range(1,number_of_sections):
	# print ('\n',2+cnt,':',memheapfilelinelist[2+cnt])
	match = re.search("start_addr = ([xA-Z0-9]{3,7})[A-Z0-9]+, unaligned_start = [xA-Z0-9]{2,10}, size = (0x\d+)",memheapfilelinelist[2+cnt])
	# print (match)
	if match:
		RemoteHeapAddress = match.group(1); RemoteHeapSize = match.group(2)
		# print ("Remote Heap VPage Address :",RemoteHeapAddress," Size :",RemoteHeapSize)
		
		fileptr = open(OutputPath_temp+"/DSP_pgt.txt",'r')
		linelist = fileptr.readlines()
		fileptr.close()
		linelist = list(map(lambda x : '1 1 1 ' if ("B::task.pgt" in x or x == '\n') else x, linelist))
		Paddress = ''
		if RemoteHeapAddress in [i.split()[0] for i in linelist]: Paddress = linelist[[i.split()[0] for i in linelist].index(RemoteHeapAddress)].split()[1]
		elif RemoteHeapAddress in [i.split()[0][:6] for i in linelist]: Paddress = linelist[[i.split()[0][:6] for i in linelist].index(RemoteHeapAddress)].split()[1]
		elif RemoteHeapAddress in [i.split()[0][:5] for i in linelist]: Paddress = linelist[[i.split()[0][:5] for i in linelist].index(RemoteHeapAddress)].split()[1]
		
		if Paddress != '':
			Paddress = '0x'+Paddress[4:]+'000'
			DumpFile, StartAddress = get_proper_dumpfile_based_on_apps_phy_address(int(Paddress,16))
			# for index,address in enumerate(DumpFileStartAddressIntFormList):
			# 	if int(Paddress,16)>= DumpFileStartAddressIntFormList[index]:
			# 		StartAddress = DumpFileStartAddressList[index]
			# 		DumpFile = DumpFileList[index]
			skip = str(hex(int(Paddress, 0)-int(StartAddress, 0)))
			if 'L' in skip: skip = skip[:-1]
			# print ('PPage',':',Paddress,': Size :',RemoteHeapSize,'Skip :',skip)
			Command = "d.load.binary "+DumpPath+"/"+DumpFile+" a:"+Paddress+"++"+RemoteHeapSize+" /skip "+skip+" /noclear"
			# print(Command)
			command_list.append(Command)
	
if len(command_list)!=0:
	fileptr = open(OutputPath_temp+"/CommandToLoadRemoteHeap.cmm",'w')
	fileptr.writelines("%s\n" % command for command in command_list)
	fileptr.close()


