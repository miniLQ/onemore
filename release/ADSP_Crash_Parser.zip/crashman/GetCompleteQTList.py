import os
import sys

path = sys.argv[1]
qurt_logs = path+'/Qurt_logs/'+'dsp_QT.txt'
dsp_pgt_file = path+'/temp/'+'DSP_pgt_converted.txt'
qt_ugp_file = path+'/temp/'+'qt_ugp_mapping.txt'
qt_ugp_file = path+'/temp/'+'asid_mappings.txt'

if os.path.isfile(qurt_logs) and os.path.isfile(dsp_pgt_file):
	with open(qurt_logs, 'r') as fileptr:
		ugp_pointer_list = []
		linelist = fileptr.readlines()
		for line in linelist:
			if len(line.split())>=7:
				if '*' in line.split()[6]:
					print ("*", line.split()[0])
					ugp_pointer_list.append(line.split()[1][:-3]+'000' )
		for line in linelist:
			if 'RUNNING' in line:
				if len(line.split())==7:
					ugp_pointer_list.append(line.split()[1][:-3]+'000')
			if len(line.split())==6:
				ugp_pointer_list.append(line.split()[1][:-3]+'000')
		# ugp_pointer_list = [line.split()[1][:-3]+'000' for line in linelist if len(line.split())==6 ]
		print ("\nNumber of TCB pointer which doesn't have name =", len(ugp_pointer_list), '\n')

	with open(dsp_pgt_file, 'r') as fileptr:
		dsp_linelist = fileptr.readlines()
		dsp_linelist = [line for line in dsp_linelist if line[:2]=='0x']
		new_mapping_list = []
		for index, each_pointer in enumerate(ugp_pointer_list):
			# print (index,"UGP_VA :", each_pointer, end=' -> ')
			for line in dsp_linelist:
				# print (line.split('*'))
				vAddress = (line.split('*')[0][2:].strip()+'000')
				pAddress = (line.split('*')[1][2:].strip()+'000')
				size = line.split('*')[2][2:].strip()
				# print (each_pointer, vAddress, size)
				if int(vAddress,16) <= int(each_pointer,16) < int(vAddress,16)+int(size,16):
					ugp_pa = hex(int(pAddress,16)+int(each_pointer,16)-int(vAddress,16))
					if line.split('\n')[0] not in new_mapping_list:
						new_mapping_list.append(line.split('\n')[0])
					# print ('UGP_PA :',ugp_pa, end= '  ')
					# print ('(VA:', vAddress, 'PA:', pAddress, 'size:', size+')')
					# print ('0x'+each_pointer[:-3]+'  *'+ugp_pa[:-3]+' *0x1000')
					# new_mapping_list.append('0x'+each_pointer[:-3]+'  *'+ugp_pa[:-3]+' *0x1000')
					break
	
	# for line in new_mapping_list: print(line)
	print (len(new_mapping_list))
	with open(qt_ugp_file, 'r') as fileptr:
		linelist = fileptr.readlines()
	linelist = [line.split("\n")[0] for line in linelist]
	print (len(linelist))
	linelist = linelist+new_mapping_list
	print (len(linelist))
	linelist = list(set(linelist))
	print (len(linelist))
	with open(qt_ugp_file, 'w') as fileptr:
		fileptr.write('\n'.join(linelist))
