import os
import re
import shutil
import sys

# DSP_pgt= sys.argv[1]
# entry_point= sys.argv[2]
# size = sys.argv[3]

def get_mappings(DSP_pgt,entry_point,size,f_nonbsc):
	DSP_pgt_file=open(DSP_pgt+"\\DSP_pgt_converted.txt", "r")
	# print (entry_point, size) # 0x9700000 0x130000
	int_entry = int(entry_point,16)
	int_size = int(size,16)
	# print (int_entry, int_size) # 158334976 1245184
	for line in DSP_pgt_file:
		if (line[0:2] == '0x'):
			# print (line) #  0x09790  *0x3F7090 *0x10000  *  R  -  X *-  U        *Cacheable, write-back, non-shared, L2-cacheable*80409790 B77EE124     *00000000
			address=line.split(' ')[0] # 0x09790
			final_address =int(address,16)*4096 # 158924800
			# print (hex(final_address).replace('L','')) # 0x9790000
			if (final_address >= int_entry):
				if (final_address <= (int_entry+int_size)):
					f_nonbsc.write(line)

def get_mappings_heap(DSP_pgt,entry_point,size,f_nonbsc):
	DSP_pgt_file=open(DSP_pgt+"\\DSP_pgt_converted.txt", "r")
	# print (entry_point, size) # 0x3F7124000 0x2DC000
	int_entry = int(entry_point,16)
	int_size = int(size,16)
	# print (int_entry, int_size) # 17030070272 2998272
	for line in DSP_pgt_file:
		if (line[0:2] == '0x'):
			# print (line) #  0xE0D6C  *0x3F712B *0x1000   *  R  W  - *-  U        *Cacheable, write-back, non-shared, L2-cacheable*804E0D6C 777EE257     *00000000
			list_dsppgt = line.split()
			# print (list_dsppgt[1]) # *0x3F712B
			ipage_address= int(list_dsppgt[1].replace('*',''),16) # 4157739
			final_address = ipage_address * 0x1000 # 17030098944 = 4157739*4096
			# print (hex(final_address).replace('L','')) # 0x3f712b000 
			if (final_address >= int_entry):
				if (final_address <= (int_entry+int_size)):
					f_nonbsc.write(line)
					
if __name__ == '__main__':
    CallFun      = sys.argv[1]
    if "get_mappings" in CallFun:
        OutputPath= sys.argv[2]
        entry_point= sys.argv[3]
        size= sys.argv[4]
        f_nonbsc = open(OutputPath+"\\asid_mappings.txt",'a')
        get_mappings(OutputPath,entry_point,size,f_nonbsc)
        f_nonbsc.close()
    if "get_mappings_heap" in CallFun:
        OutputPath= sys.argv[2]
        entry_point= sys.argv[3]
        size= sys.argv[4]
        f_nonbsc = open(OutputPath+"\\asid_mappings.txt",'a')
        get_mappings_heap(OutputPath,entry_point,size,f_nonbsc)
        f_nonbsc.close()
