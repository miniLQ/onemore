# ------------------------------------------------------------------
#
# Copyright (c) 2019-2020 Qualcomm Technologies, Inc.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
# ------------------------------------------------------------------

import sys
import re
import os

#input = ipage_address
#outputs-
# found_smmu
# smmu_vpage_address, smmu_ppage_address, smmu_size
current_path=os.getcwd()
input=str(sys.argv[1])
smmu_filename=str(sys.argv[2])
pgt_filename=str(sys.argv[3])
subsystem=str(sys.argv[4])
target=sys.argv[5]
print (input)
os.chdir(input)

if target=="845":
    if subsystem=="cdsp":
        # print ("Yes 845 cdsp path")
        smmu_fastrpc_list = { \
        '0x1':'msm_fastrpc_compute_cb1',\
        '0x2':'msm_fastrpc_compute_cb2',\
        '0x3':'msm_fastrpc_compute_cb3',\
        '0x4':'msm_fastrpc_compute_cb4',\
        '0x5':'msm_fastrpc_compute_cb5',\
        '0x6':'msm_fastrpc_compute_cb6',\
        '0x7':'msm_fastrpc_compute_cb7',\
        '0x8':'msm_fastrpc_compute_cb8',\
        '0x9':'msm_fastrpc_compute_cb9',\
        '0xA':'msm_fastrpc_compute_cb10',\
        }
    else:
        smmu_fastrpc_list = { \
        '0x1':'msm_fastrpc_compute_cb1',\
        '0x7':'msm_fastrpc_compute_cb2',\
        '0x8':'msm_fastrpc_compute_cb3',\
        '0x9':'msm_fastrpc_compute_cb4',\
        '0xA':'msm_fastrpc_compute_cb5',\
        '0xB':'msm_fastrpc_compute_cb6',\
        '0xC':'msm_fastrpc_compute_cb7',\
        '0xD':'msm_fastrpc_compute_cb8',\
        '0x3':'msm_fastrpc_compute_cb11',\
        '0x4':'msm_fastrpc_compute_cb12',\
        }
elif target=="855":
    if subsystem=="cdsp":
        smmu_fastrpc_list = { \
        '0x1':'msm_fastrpc_compute_cb1',\
        '0x2':'msm_fastrpc_compute_cb2',\
        '0x3':'msm_fastrpc_compute_cb3',\
        '0x4':'msm_fastrpc_compute_cb4',\
        '0x5':'msm_fastrpc_compute_cb5',\
        '0x6':'msm_fastrpc_compute_cb6',\
        '0x7':'msm_fastrpc_compute_cb7',\
        '0x8':'msm_fastrpc_compute_cb8',\
        '0x9':'msm_fastrpc_compute_cb9'

        }
    elif subsystem=="slpi":
        print ("In SLPI")
        smmu_fastrpc_list = { 
        '0x1':'msm_fastrpc_compute_cb13',\
        '0x2':'msm_fastrpc_compute_cb14',\
        '0x3':'msm_fastrpc_compute_cb15'
        }
    else:
        smmu_fastrpc_list = { \
        '0x3':'msm_fastrpc_compute_cb10',\
        '0x4':'msm_fastrpc_compute_cb11',\
        '0x5':'msm_fastrpc_compute_cb12'
        }
elif target=="660":
    if subsystem=="cdsp":
        smmu_fastrpc_list = { \
        '0x3':'msm_fastrpc_compute_cb5',\
        '0x4':'msm_fastrpc_compute_cb6',\
        '0x5':'msm_fastrpc_compute_cb7',\
        '0x6':'msm_fastrpc_compute_cb8',\
        '0x7':'msm_fastrpc_compute_cb9',\
        '0x8':'msm_fastrpc_compute_cb1',\
        '0x9':'msm_fastrpc_compute_cb2',\
        '0xA':'msm_fastrpc_compute_cb3',\
        '0xB':'msm_fastrpc_compute_cb4',\
        }
    else:
        smmu_fastrpc_list = { \
        '0x3':'msm_fastrpc_compute_cb1',\
        '0x7':'msm_fastrpc_compute_cb2',\
        '0x8':'msm_fastrpc_compute_cb3',\
        '0x9':'msm_fastrpc_compute_cb4',\
        '0xA':'msm_fastrpc_compute_cb5',\
        '0xB':'msm_fastrpc_compute_cb6',\
        '0xC':'msm_fastrpc_compute_cb7',\
        '0xD':'msm_fastrpc_compute_cb8',\
        }
elif target ==  "670":
    if subsystem=="cdsp":
        smmu_fastrpc_list = { \
        '0x1':'msm_fastrpc_compute_cb1',\
        '0x2':'msm_fastrpc_compute_cb2',\
        '0x3':'msm_fastrpc_compute_cb3',\
        '0x4':'msm_fastrpc_compute_cb4',\
        '0x5':'msm_fastrpc_compute_cb5',\
        '0x6':'msm_fastrpc_compute_cb6',\
        '0x9':'msm_fastrpc_compute_cb7',\
        '0xA':'msm_fastrpc_compute_cb8',\

    }
    else:
        smmu_fastrpc_list = { \
            '0x3':'msm_fastrpc_compute_cb9',\
            '0x4':'msm_fastrpc_compute_cb10',\
            '0x5':'msm_fastrpc_compute_cb11',\
            '0x6':'msm_fastrpc_compute_cb12',\
        }
elif target ==  "6150" or target=="7150":
    if subsystem=="cdsp":
        smmu_fastrpc_list = { \
        '0x1':'msm_fastrpc_compute_cb1',\
        '0x2':'msm_fastrpc_compute_cb2',\
        '0x3':'msm_fastrpc_compute_cb3',\
        '0x4':'msm_fastrpc_compute_cb4',\
        '0x5':'msm_fastrpc_compute_cb5',\
        '0x6':'msm_fastrpc_compute_cb6',\
        '0x9':'msm_fastrpc_compute_cb7',\
        '0xA':'msm_fastrpc_compute_cb8',\

    }
    else:
        smmu_fastrpc_list = { \
            '0x3':'msm_fastrpc_compute_cb9',\
            '0x4':'msm_fastrpc_compute_cb10',\
            '0x5':'msm_fastrpc_compute_cb11',\
            '0x6':'msm_fastrpc_compute_cb12',\
        }
elif target == "8250" or target == "saipan" or target == "rennell" or target == "lahaina" or target == "bitra":
    if subsystem=="cdsp":
        smmu_fastrpc_list = { \
         '0x1':'msm_fastrpc_compute_cb1',\
         '0x2':'msm_fastrpc_compute_cb2',\
         '0x3':'msm_fastrpc_compute_cb3',\
         '0x4':'msm_fastrpc_compute_cb4',\
         '0x5':'msm_fastrpc_compute_cb5',\
         '0x6':'msm_fastrpc_compute_cb6',\
         '0x7':'msm_fastrpc_compute_cb7',\
         '0x8':'msm_fastrpc_compute_cb8',\
         '0x9':'msm_fastrpc_compute_cb9'
    }
    else:
        smmu_fastrpc_list = { \
          '0x3':'msm_fastrpc_compute_cb10',\
          '0x4':'msm_fastrpc_compute_cb11',\
          '0x5':'msm_fastrpc_compute_cb12'
        }
elif target == "6018":
    if subsystem=="cdsp":
        smmu_fastrpc_list = { 
          '0x1':'msm_fastrpc_compute_cb1',
          '0x2':'msm_fastrpc_compute_cb2',
          '0x3':'msm_fastrpc_compute_cb3',
          '0x4':'msm_fastrpc_compute_cb4',
          '0x5':'msm_fastrpc_compute_cb5'
    }
    else:
        smmu_fastrpc_list = { 
          '0x4':'msm_fastrpc_compute_cb1',
          '0x5':'msm_fastrpc_compute_cb2',
          '0x6':'msm_fastrpc_compute_cb3',
          '0x7':'msm_fastrpc_compute_cb4',
          '0x8':'msm_fastrpc_compute_cb5',
          '0x9':'msm_fastrpc_compute_cb6',
          '0xA':'msm_fastrpc_compute_cb7',
          '0xB':'msm_fastrpc_compute_cb8'
        }
elif target == "kamorta" or target == "mannar" or target == "strait":
    if subsystem=="cdsp":
        smmu_fastrpc_list = { 
          '0x1':'msm_fastrpc_compute_cb1',
          '0x2':'msm_fastrpc_compute_cb2',
          '0x3':'msm_fastrpc_compute_cb3',
          '0x4':'msm_fastrpc_compute_cb4',
          '0x5':'msm_fastrpc_compute_cb5',
          '0x6':'msm_fastrpc_compute_cb6',
          '0x9':'msm_fastrpc_compute_cb9'
    }
    else:
        smmu_fastrpc_list = { 
          '0x3':'msm_fastrpc_compute_cb10',
          '0x4':'msm_fastrpc_compute_cb11',
          '0x5':'msm_fastrpc_compute_cb12',
          '0x6':'msm_fastrpc_compute_cb13',
          '0x7':'msm_fastrpc_compute_cb14'
        }

def create_smmutxt_new():
    f_smmutxt = open ('smmu.txt', 'w')
    smmu_files= "soc_qcom_msm-audio-ion.txt"
    if os.path.isfile(smmu_files):
        f_smmuInputfile = open (smmu_files, 'r')
        for line_smmufile in f_smmuInputfile:
            if (line_smmufile[2:4] == 'VA'):
                list1=line_smmufile.split("|")
                p1=list1[1].split(":")[1].replace(" - ","--").replace(' ','')
                p2=list1[2].split(":")[1].replace(" - ","--").replace(' ','')
                p3='['+list1[4].replace(' ','')+']'                   
                st=p1+' '+p3+' '+'A:'+p2+' '+p3+' '+" [R/W][4K] [Non-Cached] [Outer-Shareable] [True]"+'\n'
                #print (st)
                f_smmutxt.write(st)

        f_smmuInputfile.close()
    f_smmutxt.close()

def create_smmutxt_asid_new():

    for key,smmu_fastrpc in smmu_fastrpc_list.items():
        f_smmutxt = open (smmu_fastrpc+'1.txt', 'w')
        smmu_files = "soc_qcom_msm_fastrpc_qcom_"+smmu_fastrpc+".txt"
        #print (smmu_files)
        if os.path.isfile(smmu_files):
            f_smmuInputfile = open (smmu_files, 'r')
            for line_smmufile in f_smmuInputfile:
                if (line_smmufile[2:4] == 'VA'):
                    list1=line_smmufile.split("|")
                    p1=list1[1].split(":")[1].replace(" - ","--").replace(' ','')
                    p2=list1[2].split(":")[1].replace(" - ","--").replace(' ','')
                    p3='['+list1[4].replace(' ','')+']'                   
                    st=p1+' '+p3+' '+'A:'+p2+' '+p3+' '+" [R/W][4K] [Non-Cached] [Outer-Shareable] [True]"+'\n'
                    #print (st)
                    f_smmutxt.write(st)

            f_smmuInputfile.close()
        f_smmutxt.close()
        f_dsppgt = open (smmu_fastrpc+'1.txt', 'r')
        f_out = open (smmu_fastrpc+'.txt', 'w')
        temp0 = "0"
        temp1 = "0"
        temp2 = 0
        temp3 = "0"
        temp4 = "0"
        temp5 = 0
        for line_dsppgt in f_dsppgt:
            if ( line_dsppgt[0:2] == '0x'):
                #print (line_dsppgt)
                list_dsppgt = line_dsppgt.split(' ')
                t0 = list_dsppgt[0].split('--')[0]
                t1 = list_dsppgt[0].split('--')[1]
                t2 = list_dsppgt[1].split('[')[1].split(']')[0]
                t3 = list_dsppgt[2].split('A:')[1].split('--')[0]
                t4 = list_dsppgt[2].split('A:')[1].split('--')[1]
                t5 = list_dsppgt[3].split('[')[1].split(']')[0]
                if (int(temp1,16)+1==int(t0,16) and int(temp4,16)+1==int(t3,16)):
                    temp1 = t1
                    temp2 = temp2+int(t2,16)
                    temp4 = t4
                    temp5 = temp5 + int(t5,16)
                else:
                    if temp0 != "0":
                        f_out.write(temp0+'--'+temp1+' ['+str(hex(temp2))+'] A:'+temp3+'--'+temp4+' ['+str(hex(temp5))+'] [R/W][4K] \n')
                    temp0 = t0
                    temp1 = t1
                    temp2 = int(t2,16)
                    temp3 = t3
                    temp4 = t4
                    temp5 = int(t5,16)
        if temp0 != "0":
            f_out.write(temp0+'--'+temp1+' ['+str(hex(temp2))+'] A:'+temp3+'--'+temp4+' ['+str(hex(temp5))+'] [R/W][4K] \n')
        f_dsppgt.close()
        f_out.close()
        f_out = open (smmu_fastrpc+'.txt', 'r')
        for line in f_out:
            temp = line.split('--')[0]
            if int(temp,16) >= int('0x80000000',16) and int(temp,16) < int('0x81000000',16):
                f_out1 = open (smmu_fastrpc+'_0x80.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0x81000000',16) and int(temp,16) < int('0x82000000',16):
                f_out1 = open (smmu_fastrpc+'_0x81.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0x82000000',16) and int(temp,16) < int('0x83000000',16):
                f_out1 = open (smmu_fastrpc+'_0x82.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0x83000000',16) and int(temp,16) < int('0x84000000',16):
                f_out1 = open (smmu_fastrpc+'_0x83.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0x84000000',16) and int(temp,16) < int('0x85000000',16):
                f_out1 = open (smmu_fastrpc+'_0x84.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0x85000000',16) and int(temp,16) < int('0x86000000',16):
                f_out1 = open (smmu_fastrpc+'_0x85.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0x86000000',16) and int(temp,16) < int('0x87000000',16):
                f_out1 = open (smmu_fastrpc+'_0x86.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0x87000000',16) and int(temp,16) < int('0x88000000',16):
                f_out1 = open (smmu_fastrpc+'_0x87.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0x88000000',16) and int(temp,16) < int('0x89000000',16):
                f_out1 = open (smmu_fastrpc+'_0x88.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0x89000000',16) and int(temp,16) < int('0x8a000000',16):
                f_out1 = open (smmu_fastrpc+'_0x89.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0x8a000000',16) and int(temp,16) < int('0x8b000000',16):
                f_out1 = open (smmu_fastrpc+'_0x8a.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0x8b000000',16) and int(temp,16) < int('0x8c000000',16):
                f_out1 = open (smmu_fastrpc+'_0x8b.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0x8c000000',16) and int(temp,16) < int('0x8d000000',16):
                f_out1 = open (smmu_fastrpc+'_0x8c.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0x8d000000',16) and int(temp,16) < int('0x8e000000',16):
                f_out1 = open (smmu_fastrpc+'_0x8d.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0x8e000000',16) and int(temp,16) < int('0x8f000000',16):
                f_out1 = open (smmu_fastrpc+'_0x8e.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0x8f000000',16) and int(temp,16) < int('0x90000000',16):
                f_out1 = open (smmu_fastrpc+'_0x8f.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0x90000000',16) and int(temp,16) < int('0x91000000',16):
                f_out1 = open (smmu_fastrpc+'_0x90.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0x91000000',16) and int(temp,16) < int('0x92000000',16):
                f_out1 = open (smmu_fastrpc+'_0x91.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0x92000000',16) and int(temp,16) < int('0x93000000',16):
                f_out1 = open (smmu_fastrpc+'_0x92.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0x93000000',16) and int(temp,16) < int('0x94000000',16):
                f_out1 = open (smmu_fastrpc+'_0x93.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0x94000000',16) and int(temp,16) < int('0x95000000',16):
                f_out1 = open (smmu_fastrpc+'_0x94.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0x95000000',16) and int(temp,16) < int('0x96000000',16):
                f_out1 = open (smmu_fastrpc+'_0x95.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0x96000000',16) and int(temp,16) < int('0x97000000',16):
                f_out1 = open (smmu_fastrpc+'_0x96.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0x97000000',16) and int(temp,16) < int('0x98000000',16):
                f_out1 = open (smmu_fastrpc+'_0x97.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0x98000000',16) and int(temp,16) < int('0x99000000',16):
                f_out1 = open (smmu_fastrpc+'_0x98.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0x99000000',16) and int(temp,16) < int('0x9a000000',16):
                f_out1 = open (smmu_fastrpc+'_0x99.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0x9a000000',16) and int(temp,16) < int('0x9b000000',16):
                f_out1 = open (smmu_fastrpc+'_0x9a.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0x9b000000',16) and int(temp,16) < int('0x9c000000',16):
                f_out1 = open (smmu_fastrpc+'_0x9b.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0x9c000000',16) and int(temp,16) < int('0x9d000000',16):
                f_out1 = open (smmu_fastrpc+'_0x9c.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0x9d000000',16) and int(temp,16) < int('0x9e000000',16):
                f_out1 = open (smmu_fastrpc+'_0x9d.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0x9e000000',16) and int(temp,16) < int('0x9f000000',16):
                f_out1 = open (smmu_fastrpc+'_0x9e.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0x9f000000',16) and int(temp,16) < int('0xa0000000',16):
                f_out1 = open (smmu_fastrpc+'_0x9f.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xa0000000',16) and int(temp,16) < int('0xa1000000',16):
                f_out1 = open (smmu_fastrpc+'_0xa0.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xa1000000',16) and int(temp,16) < int('0xa2000000',16):
                f_out1 = open (smmu_fastrpc+'_0xa1.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xa2000000',16) and int(temp,16) < int('0xa3000000',16):
                f_out1 = open (smmu_fastrpc+'_0xa2.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xa3000000',16) and int(temp,16) < int('0xa4000000',16):
                f_out1 = open (smmu_fastrpc+'_0xa3.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xa4000000',16) and int(temp,16) < int('0xa5000000',16):
                f_out1 = open (smmu_fastrpc+'_0xa4.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xa5000000',16) and int(temp,16) < int('0xa6000000',16):
                f_out1 = open (smmu_fastrpc+'_0xa5.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xa6000000',16) and int(temp,16) < int('0xa7000000',16):
                f_out1 = open (smmu_fastrpc+'_0xa6.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xa7000000',16) and int(temp,16) < int('0xa8000000',16):
                f_out1 = open (smmu_fastrpc+'_0xa7.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xa8000000',16) and int(temp,16) < int('0xa9000000',16):
                f_out1 = open (smmu_fastrpc+'_0xa8.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xa9000000',16) and int(temp,16) < int('0xaa000000',16):
                f_out1 = open (smmu_fastrpc+'_0xa9.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xaa000000',16) and int(temp,16) < int('0xab000000',16):
                f_out1 = open (smmu_fastrpc+'_0xaa.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xab000000',16) and int(temp,16) < int('0xac000000',16):
                f_out1 = open (smmu_fastrpc+'_0xab.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xac000000',16) and int(temp,16) < int('0xad000000',16):
                f_out1 = open (smmu_fastrpc+'_0xac.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xad000000',16) and int(temp,16) < int('0xae000000',16):
                f_out1 = open (smmu_fastrpc+'_0xad.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xae000000',16) and int(temp,16) < int('0xaf000000',16):
                f_out1 = open (smmu_fastrpc+'_0xae.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xaf000000',16) and int(temp,16) < int('0xb0000000',16):
                f_out1 = open (smmu_fastrpc+'_0xaf.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xb0000000',16) and int(temp,16) < int('0xb1000000',16):
                f_out1 = open (smmu_fastrpc+'_0xb0.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xb1000000',16) and int(temp,16) < int('0xb2000000',16):
                f_out1 = open (smmu_fastrpc+'_0xb1.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xb2000000',16) and int(temp,16) < int('0xb3000000',16):
                f_out1 = open (smmu_fastrpc+'_0xb2.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xb3000000',16) and int(temp,16) < int('0xb4000000',16):
                f_out1 = open (smmu_fastrpc+'_0xb3.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xb4000000',16) and int(temp,16) < int('0xb5000000',16):
                f_out1 = open (smmu_fastrpc+'_0xb4.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xb5000000',16) and int(temp,16) < int('0xb6000000',16):
                f_out1 = open (smmu_fastrpc+'_0xb5.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xb6000000',16) and int(temp,16) < int('0xb7000000',16):
                f_out1 = open (smmu_fastrpc+'_0xb6.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xb7000000',16) and int(temp,16) < int('0xb8000000',16):
                f_out1 = open (smmu_fastrpc+'_0xb7.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xb8000000',16) and int(temp,16) < int('0xb9000000',16):
                f_out1 = open (smmu_fastrpc+'_0xb8.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xb9000000',16) and int(temp,16) < int('0xba000000',16):
                f_out1 = open (smmu_fastrpc+'_0xb9.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xba000000',16) and int(temp,16) < int('0xbb000000',16):
                f_out1 = open (smmu_fastrpc+'_0xba.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xbb000000',16) and int(temp,16) < int('0xbc000000',16):
                f_out1 = open (smmu_fastrpc+'_0xbb.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xbc000000',16) and int(temp,16) < int('0xbd000000',16):
                f_out1 = open (smmu_fastrpc+'_0xbc.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xbd000000',16) and int(temp,16) < int('0xbe000000',16):
                f_out1 = open (smmu_fastrpc+'_0xbd.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xbe000000',16) and int(temp,16) < int('0xbf000000',16):
                f_out1 = open (smmu_fastrpc+'_0xbe.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xbf000000',16) and int(temp,16) < int('0xc0000000',16):
                f_out1 = open (smmu_fastrpc+'_0xbf.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xc0000000',16) and int(temp,16) < int('0xc1000000',16):
                f_out1 = open (smmu_fastrpc+'_0xc0.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xc1000000',16) and int(temp,16) < int('0xc2000000',16):
                f_out1 = open (smmu_fastrpc+'_0xc1.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xc2000000',16) and int(temp,16) < int('0xc3000000',16):
                f_out1 = open (smmu_fastrpc+'_0xc2.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xc3000000',16) and int(temp,16) < int('0xc4000000',16):
                f_out1 = open (smmu_fastrpc+'_0xc3.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xc4000000',16) and int(temp,16) < int('0xc5000000',16):
                f_out1 = open (smmu_fastrpc+'_0xc4.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xc5000000',16) and int(temp,16) < int('0xc6000000',16):
                f_out1 = open (smmu_fastrpc+'_0xc5.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xc6000000',16) and int(temp,16) < int('0xc7000000',16):
                f_out1 = open (smmu_fastrpc+'_0xc6.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xc7000000',16) and int(temp,16) < int('0xc8000000',16):
                f_out1 = open (smmu_fastrpc+'_0xc7.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xc8000000',16) and int(temp,16) < int('0xc9000000',16):
                f_out1 = open (smmu_fastrpc+'_0xc8.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xc9000000',16) and int(temp,16) < int('0xca000000',16):
                f_out1 = open (smmu_fastrpc+'_0xc9.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xca000000',16) and int(temp,16) < int('0xcb000000',16):
                f_out1 = open (smmu_fastrpc+'_0xca.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xcb000000',16) and int(temp,16) < int('0xcc000000',16):
                f_out1 = open (smmu_fastrpc+'_0xcb.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xcc000000',16) and int(temp,16) < int('0xcd000000',16):
                f_out1 = open (smmu_fastrpc+'_0xcc.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xcd000000',16) and int(temp,16) < int('0xce000000',16):
                f_out1 = open (smmu_fastrpc+'_0xcd.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xce000000',16) and int(temp,16) < int('0xcf000000',16):
                f_out1 = open (smmu_fastrpc+'_0xce.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xcf000000',16) and int(temp,16) < int('0xd0000000',16):
                f_out1 = open (smmu_fastrpc+'_0xcf.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xd0000000',16) and int(temp,16) < int('0xd1000000',16):
                f_out1 = open (smmu_fastrpc+'_0xd0.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xd1000000',16) and int(temp,16) < int('0xd2000000',16):
                f_out1 = open (smmu_fastrpc+'_0xd1.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xd2000000',16) and int(temp,16) < int('0xd3000000',16):
                f_out1 = open (smmu_fastrpc+'_0xd2.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xd3000000',16) and int(temp,16) < int('0xd4000000',16):
                f_out1 = open (smmu_fastrpc+'_0xd3.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xd4000000',16) and int(temp,16) < int('0xd5000000',16):
                f_out1 = open (smmu_fastrpc+'_0xd4.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xd5000000',16) and int(temp,16) < int('0xd6000000',16):
                f_out1 = open (smmu_fastrpc+'_0xd5.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xd6000000',16) and int(temp,16) < int('0xd7000000',16):
                f_out1 = open (smmu_fastrpc+'_0xd6.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xd7000000',16) and int(temp,16) < int('0xd8000000',16):
                f_out1 = open (smmu_fastrpc+'_0xd7.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xd8000000',16) and int(temp,16) < int('0xd9000000',16):
                f_out1 = open (smmu_fastrpc+'_0xd8.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xd9000000',16) and int(temp,16) < int('0xda000000',16):
                f_out1 = open (smmu_fastrpc+'_0xd9.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xda000000',16) and int(temp,16) < int('0xdb000000',16):
                f_out1 = open (smmu_fastrpc+'_0xda.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xdb000000',16) and int(temp,16) < int('0xdc000000',16):
                f_out1 = open (smmu_fastrpc+'_0xdb.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xdc000000',16) and int(temp,16) < int('0xdd000000',16):
                f_out1 = open (smmu_fastrpc+'_0xdc.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xdd000000',16) and int(temp,16) < int('0xde000000',16):
                f_out1 = open (smmu_fastrpc+'_0xdd.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xde000000',16) and int(temp,16) < int('0xdf000000',16):
                f_out1 = open (smmu_fastrpc+'_0xde.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xdf000000',16) and int(temp,16) < int('0xe0000000',16):
                f_out1 = open (smmu_fastrpc+'_0xdf.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xe0000000',16) and int(temp,16) < int('0xe1000000',16):
                f_out1 = open (smmu_fastrpc+'_0xe0.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xe1000000',16) and int(temp,16) < int('0xe2000000',16):
                f_out1 = open (smmu_fastrpc+'_0xe1.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xe2000000',16) and int(temp,16) < int('0xe3000000',16):
                f_out1 = open (smmu_fastrpc+'_0xe2.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xe3000000',16) and int(temp,16) < int('0xe4000000',16):
                f_out1 = open (smmu_fastrpc+'_0xe3.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xe4000000',16) and int(temp,16) < int('0xe5000000',16):
                f_out1 = open (smmu_fastrpc+'_0xe4.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xe5000000',16) and int(temp,16) < int('0xe6000000',16):
                f_out1 = open (smmu_fastrpc+'_0xe5.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xe6000000',16) and int(temp,16) < int('0xe7000000',16):
                f_out1 = open (smmu_fastrpc+'_0xe6.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xe7000000',16) and int(temp,16) < int('0xe8000000',16):
                f_out1 = open (smmu_fastrpc+'_0xe7.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xe8000000',16) and int(temp,16) < int('0xe9000000',16):
                f_out1 = open (smmu_fastrpc+'_0xe8.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xe9000000',16) and int(temp,16) < int('0xea000000',16):
                f_out1 = open (smmu_fastrpc+'_0xe9.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xea000000',16) and int(temp,16) < int('0xeb000000',16):
                f_out1 = open (smmu_fastrpc+'_0xea.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xeb000000',16) and int(temp,16) < int('0xec000000',16):
                f_out1 = open (smmu_fastrpc+'_0xeb.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xec000000',16) and int(temp,16) < int('0xed000000',16):
                f_out1 = open (smmu_fastrpc+'_0xec.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xed000000',16) and int(temp,16) < int('0xee000000',16):
                f_out1 = open (smmu_fastrpc+'_0xed.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xee000000',16) and int(temp,16) < int('0xef000000',16):
                f_out1 = open (smmu_fastrpc+'_0xee.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xef000000',16) and int(temp,16) < int('0xf0000000',16):
                f_out1 = open (smmu_fastrpc+'_0xef.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xf0000000',16) and int(temp,16) < int('0xf1000000',16):
                f_out1 = open (smmu_fastrpc+'_0xf0.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xf1000000',16) and int(temp,16) < int('0xf2000000',16):
                f_out1 = open (smmu_fastrpc+'_0xf1.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xf2000000',16) and int(temp,16) < int('0xf3000000',16):
                f_out1 = open (smmu_fastrpc+'_0xf2.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xf3000000',16) and int(temp,16) < int('0xf4000000',16):
                f_out1 = open (smmu_fastrpc+'_0xf3.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xf4000000',16) and int(temp,16) < int('0xf5000000',16):
                f_out1 = open (smmu_fastrpc+'_0xf4.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xf5000000',16) and int(temp,16) < int('0xf6000000',16):
                f_out1 = open (smmu_fastrpc+'_0xf5.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xf6000000',16) and int(temp,16) < int('0xf7000000',16):
                f_out1 = open (smmu_fastrpc+'_0xf6.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xf7000000',16) and int(temp,16) < int('0xf8000000',16):
                f_out1 = open (smmu_fastrpc+'_0xf7.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xf8000000',16) and int(temp,16) < int('0xf9000000',16):
                f_out1 = open (smmu_fastrpc+'_0xf8.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xf9000000',16) and int(temp,16) < int('0xfa000000',16):
                f_out1 = open (smmu_fastrpc+'_0xf9.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xfa000000',16) and int(temp,16) < int('0xfb000000',16):
                f_out1 = open (smmu_fastrpc+'_0xfa.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xfb000000',16) and int(temp,16) < int('0xfc000000',16):
                f_out1 = open (smmu_fastrpc+'_0xfb.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xfc000000',16) and int(temp,16) < int('0xfd000000',16):
                f_out1 = open (smmu_fastrpc+'_0xfc.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xfd000000',16) and int(temp,16) < int('0xfe000000',16):
                f_out1 = open (smmu_fastrpc+'_0xfd.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            elif int(temp,16) >= int('0xfe000000',16) and int(temp,16) < int('0xff000000',16):
                f_out1 = open (smmu_fastrpc+'_0xfe.txt', 'a')
                f_out1.write(line)
                f_out1.close()
            else:
                f_out1 = open (smmu_fastrpc+'_else.txt', 'a')
                f_out1.write(line)
                f_out1.close()
        f_out.close()



def find_smmu(ipage_address):

    f_smmu = open ('smmu.txt', 'r')  
    for line_smmu in f_smmu:
        list_smmu = re.split(']|0x| |--',line_smmu)
        smmu_vpage_address = int(list_smmu[1],16)        
        smmu_ppage_address = int(list_smmu[8],16)
        smmu_size = int(list_smmu[5],16)
        found_smmu=0
        if (ipage_address >= smmu_vpage_address) and (ipage_address < (smmu_vpage_address+smmu_size)):
            found_smmu = 1
            #print (line_smmu #to be commented)
            break
            
    f_smmu.close()
    return (found_smmu, smmu_vpage_address, smmu_ppage_address, smmu_size)
    
def find_smmu_asid(ipage_address,asid):

    element = None
    if asid not in smmu_fastrpc_list:
        element = "smmu.txt"
    else:
        element = smmu_fastrpc_list[asid]+'.txt'
        if ipage_address >= int('0x80000000',16) and ipage_address < int('0x81000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0x80.txt'):
                element =smmu_fastrpc_list[asid]+'_0x80.txt'
        elif ipage_address >= int('0x81000000',16) and ipage_address < int('0x82000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0x81.txt'):
                element =smmu_fastrpc_list[asid]+'_0x81.txt'
        elif ipage_address >= int('0x82000000',16) and ipage_address < int('0x83000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0x82.txt'):
                element = smmu_fastrpc_list[asid]+'_0x82.txt'
        elif ipage_address >= int('0x83000000',16) and ipage_address < int('0x84000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0x83.txt'):
                element = smmu_fastrpc_list[asid]+'_0x83.txt'
        elif ipage_address >= int('0x84000000',16) and ipage_address < int('0x85000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0x84.txt'):
                element = smmu_fastrpc_list[asid]+'_0x84.txt'
        elif ipage_address >= int('0x85000000',16) and ipage_address < int('0x86000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0x85.txt'):
                element = smmu_fastrpc_list[asid]+'_0x85.txt'
        elif ipage_address >= int('0x86000000',16) and ipage_address < int('0x87000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0x86.txt'):
                element = smmu_fastrpc_list[asid]+'_0x86.txt'
        elif ipage_address >= int('0x87000000',16) and ipage_address < int('0x88000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0x87.txt'):
                element = smmu_fastrpc_list[asid]+'_0x87.txt'
        elif ipage_address >= int('0x88000000',16) and ipage_address < int('0x89000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0x88.txt'):
                element = smmu_fastrpc_list[asid]+'_0x88.txt'
        elif ipage_address >= int('0x89000000',16) and ipage_address < int('0x8a000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0x89.txt'):
                element = smmu_fastrpc_list[asid]+'_0x89.txt'
        elif ipage_address >= int('0x8a000000',16) and ipage_address < int('0x8b000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0x8a.txt'):
                element = smmu_fastrpc_list[asid]+'_0x8a.txt'
        elif ipage_address >= int('0x8b000000',16) and ipage_address < int('0x8c000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0x8b.txt'):
                element = smmu_fastrpc_list[asid]+'_0x8b.txt'
        elif ipage_address >= int('0x8c000000',16) and ipage_address < int('0x8d000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0x8c.txt'):
                element = smmu_fastrpc_list[asid]+'_0x8c.txt'
        elif ipage_address >= int('0x8d000000',16) and ipage_address < int('0x8e000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0x8d.txt'):
                element = smmu_fastrpc_list[asid]+'_0x8d.txt'
        elif ipage_address >= int('0x8e000000',16) and ipage_address < int('0x8f000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0x8e.txt'):
                element = smmu_fastrpc_list[asid]+'_0x8e.txt'
        elif ipage_address >= int('0x8f000000',16) and ipage_address < int('0x90000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0x8f.txt'):
                element = smmu_fastrpc_list[asid]+'_0x8f.txt'
        if ipage_address >= int('0x90000000',16) and ipage_address < int('0x91000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0x90.txt'):
                element =smmu_fastrpc_list[asid]+'_0x90.txt'
        elif ipage_address >= int('0x91000000',16) and ipage_address < int('0x92000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0x91.txt'):
                element =smmu_fastrpc_list[asid]+'_0x91.txt'
        elif ipage_address >= int('0x92000000',16) and ipage_address < int('0x93000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0x92.txt'):
                element = smmu_fastrpc_list[asid]+'_0x92.txt'
        elif ipage_address >= int('0x93000000',16) and ipage_address < int('0x94000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0x93.txt'):
                element = smmu_fastrpc_list[asid]+'_0x93.txt'
        elif ipage_address >= int('0x94000000',16) and ipage_address < int('0x95000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0x94.txt'):
                element = smmu_fastrpc_list[asid]+'_0x94.txt'
        elif ipage_address >= int('0x95000000',16) and ipage_address < int('0x96000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0x95.txt'):
                element = smmu_fastrpc_list[asid]+'_0x95.txt'
        elif ipage_address >= int('0x96000000',16) and ipage_address < int('0x97000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0x96.txt'):
                element = smmu_fastrpc_list[asid]+'_0x96.txt'
        elif ipage_address >= int('0x97000000',16) and ipage_address < int('0x98000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0x97.txt'):
                element = smmu_fastrpc_list[asid]+'_0x97.txt'
        elif ipage_address >= int('0x98000000',16) and ipage_address < int('0x99000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0x98.txt'):
                element = smmu_fastrpc_list[asid]+'_0x98.txt'
        elif ipage_address >= int('0x99000000',16) and ipage_address < int('0x9a000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0x99.txt'):
                element = smmu_fastrpc_list[asid]+'_0x99.txt'
        elif ipage_address >= int('0x9a000000',16) and ipage_address < int('0x9b000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0x9a.txt'):
                element = smmu_fastrpc_list[asid]+'_0x9a.txt'
        elif ipage_address >= int('0x9b000000',16) and ipage_address < int('0x9c000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0x9b.txt'):
                element = smmu_fastrpc_list[asid]+'_0x9b.txt'
        elif ipage_address >= int('0x9c000000',16) and ipage_address < int('0x9d000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0x9c.txt'):
                element = smmu_fastrpc_list[asid]+'_0x9c.txt'
        elif ipage_address >= int('0x9d000000',16) and ipage_address < int('0x9e000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0x9d.txt'):
                element = smmu_fastrpc_list[asid]+'_0x9d.txt'
        elif ipage_address >= int('0x9e000000',16) and ipage_address < int('0x9f000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0x9e.txt'):
                element = smmu_fastrpc_list[asid]+'_0x9e.txt'
        elif ipage_address >= int('0x9f000000',16) and ipage_address < int('0xa0000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0x9f.txt'):
                element = smmu_fastrpc_list[asid]+'_0x9f.txt'
        if ipage_address >= int('0xa0000000',16) and ipage_address < int('0xa1000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xa0.txt'):
                element =smmu_fastrpc_list[asid]+'_0xa0.txt'
        elif ipage_address >= int('0xa1000000',16) and ipage_address < int('0xa2000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xa1.txt'):
                element =smmu_fastrpc_list[asid]+'_0xa1.txt'
        elif ipage_address >= int('0xa2000000',16) and ipage_address < int('0xa3000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xa2.txt'):
                element = smmu_fastrpc_list[asid]+'_0xa2.txt'
        elif ipage_address >= int('0xa3000000',16) and ipage_address < int('0xa4000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xa3.txt'):
                element = smmu_fastrpc_list[asid]+'_0xa3.txt'
        elif ipage_address >= int('0xa4000000',16) and ipage_address < int('0xa5000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xa4.txt'):
                element = smmu_fastrpc_list[asid]+'_0xa4.txt'
        elif ipage_address >= int('0xa5000000',16) and ipage_address < int('0xa6000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xa5.txt'):
                element = smmu_fastrpc_list[asid]+'_0xa5.txt'
        elif ipage_address >= int('0xa6000000',16) and ipage_address < int('0xa7000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xa6.txt'):
                element = smmu_fastrpc_list[asid]+'_0xa6.txt'
        elif ipage_address >= int('0xa7000000',16) and ipage_address < int('0xa8000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xa7.txt'):
                element = smmu_fastrpc_list[asid]+'_0xa7.txt'
        elif ipage_address >= int('0xa8000000',16) and ipage_address < int('0xa9000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xa8.txt'):
                element = smmu_fastrpc_list[asid]+'_0xa8.txt'
        elif ipage_address >= int('0xa9000000',16) and ipage_address < int('0xaa000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xa9.txt'):
                element = smmu_fastrpc_list[asid]+'_0xa9.txt'
        elif ipage_address >= int('0xaa000000',16) and ipage_address < int('0xab000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xaa.txt'):
                element = smmu_fastrpc_list[asid]+'_0xaa.txt'
        elif ipage_address >= int('0xab000000',16) and ipage_address < int('0xac000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xab.txt'):
                element = smmu_fastrpc_list[asid]+'_0xab.txt'
        elif ipage_address >= int('0xac000000',16) and ipage_address < int('0xad000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xac.txt'):
                element = smmu_fastrpc_list[asid]+'_0xac.txt'
        elif ipage_address >= int('0xad000000',16) and ipage_address < int('0xae000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xad.txt'):
                element = smmu_fastrpc_list[asid]+'_0xad.txt'
        elif ipage_address >= int('0xae000000',16) and ipage_address < int('0xaf000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xae.txt'):
                element = smmu_fastrpc_list[asid]+'_0xae.txt'
        elif ipage_address >= int('0xaf000000',16) and ipage_address < int('0xb0000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xaf.txt'):
                element = smmu_fastrpc_list[asid]+'_0xaf.txt'
        if ipage_address >= int('0xb0000000',16) and ipage_address < int('0xb1000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xb0.txt'):
                element =smmu_fastrpc_list[asid]+'_0xb0.txt'
        elif ipage_address >= int('0xb1000000',16) and ipage_address < int('0xb2000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xb1.txt'):
                element =smmu_fastrpc_list[asid]+'_0xb1.txt'
        elif ipage_address >= int('0xb2000000',16) and ipage_address < int('0xb3000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xb2.txt'):
                element = smmu_fastrpc_list[asid]+'_0xb2.txt'
        elif ipage_address >= int('0xb3000000',16) and ipage_address < int('0xb4000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xb3.txt'):
                element = smmu_fastrpc_list[asid]+'_0xb3.txt'
        elif ipage_address >= int('0xb4000000',16) and ipage_address < int('0xb5000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xb4.txt'):
                element = smmu_fastrpc_list[asid]+'_0xb4.txt'
        elif ipage_address >= int('0xb5000000',16) and ipage_address < int('0xb6000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xb5.txt'):
                element = smmu_fastrpc_list[asid]+'_0xb5.txt'
        elif ipage_address >= int('0xb6000000',16) and ipage_address < int('0xb7000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xb6.txt'):
                element = smmu_fastrpc_list[asid]+'_0xb6.txt'
        elif ipage_address >= int('0xb7000000',16) and ipage_address < int('0xb8000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xb7.txt'):
                element = smmu_fastrpc_list[asid]+'_0xb7.txt'
        elif ipage_address >= int('0xb8000000',16) and ipage_address < int('0xb9000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xb8.txt'):
                element = smmu_fastrpc_list[asid]+'_0xb8.txt'
        elif ipage_address >= int('0xb9000000',16) and ipage_address < int('0xba000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xb9.txt'):
                element = smmu_fastrpc_list[asid]+'_0xb9.txt'
        elif ipage_address >= int('0xba000000',16) and ipage_address < int('0xbb000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xba.txt'):
                element = smmu_fastrpc_list[asid]+'_0xba.txt'
        elif ipage_address >= int('0xbb000000',16) and ipage_address < int('0xbc000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xbb.txt'):
                element = smmu_fastrpc_list[asid]+'_0xbb.txt'
        elif ipage_address >= int('0xbc000000',16) and ipage_address < int('0xbd000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xbc.txt'):
                element = smmu_fastrpc_list[asid]+'_0xbc.txt'
        elif ipage_address >= int('0xbd000000',16) and ipage_address < int('0xbe000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xbd.txt'):
                element = smmu_fastrpc_list[asid]+'_0xbd.txt'
        elif ipage_address >= int('0xbe000000',16) and ipage_address < int('0xbf000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xbe.txt'):
                element = smmu_fastrpc_list[asid]+'_0xbe.txt'
        elif ipage_address >= int('0xbf000000',16) and ipage_address < int('0xc0000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xbf.txt'):
                element = smmu_fastrpc_list[asid]+'_0xbf.txt'
        if ipage_address >= int('0xc0000000',16) and ipage_address < int('0xc1000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xc0.txt'):
                element =smmu_fastrpc_list[asid]+'_0xc0.txt'
        elif ipage_address >= int('0xc1000000',16) and ipage_address < int('0xc2000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xc1.txt'):
                element =smmu_fastrpc_list[asid]+'_0xc1.txt'
        elif ipage_address >= int('0xc2000000',16) and ipage_address < int('0xc3000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xc2.txt'):
                element = smmu_fastrpc_list[asid]+'_0xc2.txt'
        elif ipage_address >= int('0xc3000000',16) and ipage_address < int('0xc4000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xc3.txt'):
                element = smmu_fastrpc_list[asid]+'_0xc3.txt'
        elif ipage_address >= int('0xc4000000',16) and ipage_address < int('0xc5000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xc4.txt'):
                element = smmu_fastrpc_list[asid]+'_0xc4.txt'
        elif ipage_address >= int('0xc5000000',16) and ipage_address < int('0xc6000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xc5.txt'):
                element = smmu_fastrpc_list[asid]+'_0xc5.txt'
        elif ipage_address >= int('0xc6000000',16) and ipage_address < int('0xc7000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xc6.txt'):
                element = smmu_fastrpc_list[asid]+'_0xc6.txt'
        elif ipage_address >= int('0xc7000000',16) and ipage_address < int('0xc8000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xc7.txt'):
                element = smmu_fastrpc_list[asid]+'_0xc7.txt'
        elif ipage_address >= int('0xc8000000',16) and ipage_address < int('0xc9000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xc8.txt'):
                element = smmu_fastrpc_list[asid]+'_0xc8.txt'
        elif ipage_address >= int('0xc9000000',16) and ipage_address < int('0xca000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xc9.txt'):
                element = smmu_fastrpc_list[asid]+'_0xc9.txt'
        elif ipage_address >= int('0xca000000',16) and ipage_address < int('0xcb000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xca.txt'):
                element = smmu_fastrpc_list[asid]+'_0xca.txt'
        elif ipage_address >= int('0xcb000000',16) and ipage_address < int('0xcc000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xcb.txt'):
                element = smmu_fastrpc_list[asid]+'_0xcb.txt'
        elif ipage_address >= int('0xcc000000',16) and ipage_address < int('0xcd000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xcc.txt'):
                element = smmu_fastrpc_list[asid]+'_0xcc.txt'
        elif ipage_address >= int('0xcd000000',16) and ipage_address < int('0xce000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xcd.txt'):
                element = smmu_fastrpc_list[asid]+'_0xcd.txt'
        elif ipage_address >= int('0xce000000',16) and ipage_address < int('0xcf000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xce.txt'):
                element = smmu_fastrpc_list[asid]+'_0xce.txt'
        elif ipage_address >= int('0xcf000000',16) and ipage_address < int('0xd0000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xcf.txt'):
                element = smmu_fastrpc_list[asid]+'_0xcf.txt'
        if ipage_address >= int('0xd0000000',16) and ipage_address < int('0xd1000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xd0.txt'):
                element =smmu_fastrpc_list[asid]+'_0xd0.txt'
        elif ipage_address >= int('0xd1000000',16) and ipage_address < int('0xd2000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xd1.txt'):
                element =smmu_fastrpc_list[asid]+'_0xd1.txt'
        elif ipage_address >= int('0xd2000000',16) and ipage_address < int('0xd3000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xd2.txt'):
                element = smmu_fastrpc_list[asid]+'_0xd2.txt'
        elif ipage_address >= int('0xd3000000',16) and ipage_address < int('0xd4000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xd3.txt'):
                element = smmu_fastrpc_list[asid]+'_0xd3.txt'
        elif ipage_address >= int('0xd4000000',16) and ipage_address < int('0xd5000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xd4.txt'):
                element = smmu_fastrpc_list[asid]+'_0xd4.txt'
        elif ipage_address >= int('0xd5000000',16) and ipage_address < int('0xd6000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xd5.txt'):
                element = smmu_fastrpc_list[asid]+'_0xd5.txt'
        elif ipage_address >= int('0xd6000000',16) and ipage_address < int('0xd7000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xd6.txt'):
                element = smmu_fastrpc_list[asid]+'_0xd6.txt'
        elif ipage_address >= int('0xd7000000',16) and ipage_address < int('0xd8000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xd7.txt'):
                element = smmu_fastrpc_list[asid]+'_0xd7.txt'
        elif ipage_address >= int('0xd8000000',16) and ipage_address < int('0xd9000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xd8.txt'):
                element = smmu_fastrpc_list[asid]+'_0xd8.txt'
        elif ipage_address >= int('0xd9000000',16) and ipage_address < int('0xda000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xd9.txt'):
                element = smmu_fastrpc_list[asid]+'_0xd9.txt'
        elif ipage_address >= int('0xda000000',16) and ipage_address < int('0xdb000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xda.txt'):
                element = smmu_fastrpc_list[asid]+'_0xda.txt'
        elif ipage_address >= int('0xdb000000',16) and ipage_address < int('0xdc000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xdb.txt'):
                element = smmu_fastrpc_list[asid]+'_0xdb.txt'
        elif ipage_address >= int('0xdc000000',16) and ipage_address < int('0xdd000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xdc.txt'):
                element = smmu_fastrpc_list[asid]+'_0xdc.txt'
        elif ipage_address >= int('0xdd000000',16) and ipage_address < int('0xde000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xdd.txt'):
                element = smmu_fastrpc_list[asid]+'_0xdd.txt'
        elif ipage_address >= int('0xde000000',16) and ipage_address < int('0xdf000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xde.txt'):
                element = smmu_fastrpc_list[asid]+'_0xde.txt'
        elif ipage_address >= int('0xdf000000',16) and ipage_address < int('0xe0000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xdf.txt'):
                element = smmu_fastrpc_list[asid]+'_0xdf.txt'
        if ipage_address >= int('0xe0000000',16) and ipage_address < int('0xe1000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xe0.txt'):
                element =smmu_fastrpc_list[asid]+'_0xe0.txt'
        elif ipage_address >= int('0xe1000000',16) and ipage_address < int('0xe2000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xe1.txt'):
                element =smmu_fastrpc_list[asid]+'_0xe1.txt'
        elif ipage_address >= int('0xe2000000',16) and ipage_address < int('0xe3000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xe2.txt'):
                element = smmu_fastrpc_list[asid]+'_0xe2.txt'
        elif ipage_address >= int('0xe3000000',16) and ipage_address < int('0xe4000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xe3.txt'):
                element = smmu_fastrpc_list[asid]+'_0xe3.txt'
        elif ipage_address >= int('0xe4000000',16) and ipage_address < int('0xe5000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xe4.txt'):
                element = smmu_fastrpc_list[asid]+'_0xe4.txt'
        elif ipage_address >= int('0xe5000000',16) and ipage_address < int('0xe6000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xe5.txt'):
                element = smmu_fastrpc_list[asid]+'_0xe5.txt'
        elif ipage_address >= int('0xe6000000',16) and ipage_address < int('0xe7000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xe6.txt'):
                element = smmu_fastrpc_list[asid]+'_0xe6.txt'
        elif ipage_address >= int('0xe7000000',16) and ipage_address < int('0xe8000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xe7.txt'):
                element = smmu_fastrpc_list[asid]+'_0xe7.txt'
        elif ipage_address >= int('0xe8000000',16) and ipage_address < int('0xe9000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xe8.txt'):
                element = smmu_fastrpc_list[asid]+'_0xe8.txt'
        elif ipage_address >= int('0xe9000000',16) and ipage_address < int('0xea000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xe9.txt'):
                element = smmu_fastrpc_list[asid]+'_0xe9.txt'
        elif ipage_address >= int('0xea000000',16) and ipage_address < int('0xeb000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xea.txt'):
                element = smmu_fastrpc_list[asid]+'_0xea.txt'
        elif ipage_address >= int('0xeb000000',16) and ipage_address < int('0xec000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xeb.txt'):
                element = smmu_fastrpc_list[asid]+'_0xeb.txt'
        elif ipage_address >= int('0xec000000',16) and ipage_address < int('0xed000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xec.txt'):
                element = smmu_fastrpc_list[asid]+'_0xec.txt'
        elif ipage_address >= int('0xed000000',16) and ipage_address < int('0xee000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xed.txt'):
                element = smmu_fastrpc_list[asid]+'_0xed.txt'
        elif ipage_address >= int('0xee000000',16) and ipage_address < int('0xef000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xee.txt'):
                element = smmu_fastrpc_list[asid]+'_0xee.txt'
        elif ipage_address >= int('0xef000000',16) and ipage_address < int('0xf0000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xef.txt'):
                element = smmu_fastrpc_list[asid]+'_0xef.txt'
        if ipage_address >= int('0xf0000000',16) and ipage_address < int('0xf1000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xf0.txt'):
                element =smmu_fastrpc_list[asid]+'_0xf0.txt'
        elif ipage_address >= int('0xf1000000',16) and ipage_address < int('0xf2000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xf1.txt'):
                element =smmu_fastrpc_list[asid]+'_0xf1.txt'
        elif ipage_address >= int('0xf2000000',16) and ipage_address < int('0xf3000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xf2.txt'):
                element = smmu_fastrpc_list[asid]+'_0xf2.txt'
        elif ipage_address >= int('0xf3000000',16) and ipage_address < int('0xf4000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xf3.txt'):
                element = smmu_fastrpc_list[asid]+'_0xf3.txt'
        elif ipage_address >= int('0xf4000000',16) and ipage_address < int('0xf5000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xf4.txt'):
                element = smmu_fastrpc_list[asid]+'_0xf4.txt'
        elif ipage_address >= int('0xf5000000',16) and ipage_address < int('0xf6000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xf5.txt'):
                element = smmu_fastrpc_list[asid]+'_0xf5.txt'
        elif ipage_address >= int('0xf6000000',16) and ipage_address < int('0xf7000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xf6.txt'):
                element = smmu_fastrpc_list[asid]+'_0xf6.txt'
        elif ipage_address >= int('0xf7000000',16) and ipage_address < int('0xf8000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xf7.txt'):
                element = smmu_fastrpc_list[asid]+'_0xf7.txt'
        elif ipage_address >= int('0xf8000000',16) and ipage_address < int('0xf9000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xf8.txt'):
                element = smmu_fastrpc_list[asid]+'_0xf8.txt'
        elif ipage_address >= int('0xf9000000',16) and ipage_address < int('0xfa000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xf9.txt'):
                element = smmu_fastrpc_list[asid]+'_0xf9.txt'
        elif ipage_address >= int('0xfa000000',16) and ipage_address < int('0xfb000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xfa.txt'):
                element = smmu_fastrpc_list[asid]+'_0xfa.txt'
        elif ipage_address >= int('0xfb000000',16) and ipage_address < int('0xfc000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xfb.txt'):
                element = smmu_fastrpc_list[asid]+'_0xfb.txt'
        elif ipage_address >= int('0xfc000000',16) and ipage_address < int('0xfd000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xfc.txt'):
                element = smmu_fastrpc_list[asid]+'_0xfc.txt'
        elif ipage_address >= int('0xfd000000',16) and ipage_address < int('0xfe000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xfd.txt'):
                element = smmu_fastrpc_list[asid]+'_0xfd.txt'
        elif ipage_address >= int('0xfe000000',16) and ipage_address < int('0xff000000',16):
            if os.path.isfile(smmu_fastrpc_list[asid]+'_0xfe.txt'):
                element = smmu_fastrpc_list[asid]+'_0xfe.txt'
        else:
            if os.path.isfile(smmu_fastrpc_list[asid]+'_else.txt'):
                element = smmu_fastrpc_list[asid]+'_else.txt'
    f_smmu = open (element, 'r')  
    found_smmu=0
    smmu_vpage_address=0x0
    smmu_ppage_address=0x0
    smmu_size=0x0 
    for line_smmu in f_smmu:
        list_smmu = re.split(']|0x| |--',line_smmu)
        #print (list_smmu)
        if (subsystem=="slpi"):
            smmu_vpage_address = int(list_smmu[1],16)%4294967296
        else:
            smmu_vpage_address = int(list_smmu[1],16)
        # smmu_vpage_address = int(list_smmu[1],16)        
        smmu_ppage_address = int(list_smmu[8],16)
        smmu_size = int(list_smmu[5],16)
        found_smmu=0
        if (ipage_address >= smmu_vpage_address) and (ipage_address < (smmu_vpage_address+smmu_size)):
            found_smmu = 1
            #print (line_smmu #to be commented)
            break
            
    f_smmu.close()
    return (found_smmu, smmu_vpage_address, smmu_ppage_address, smmu_size)


def map_smmu(vpage_address, ipage_address, size, f_out):
        
    vpage_address_temp= vpage_address
    ipage_address_temp= ipage_address
    size_temp = size
    f_output = f_out
    while(size_temp!= 0x0):
        found_smmu=0
        smmu_vpage_address=0x0
        smmu_ppage_address=0x0
        smmu_size=0x0 
        result_find_smmu= find_smmu(ipage_address_temp)
        found_smmu= result_find_smmu[0]
        smmu_vpage_address = result_find_smmu[1]
        smmu_ppage_address = result_find_smmu[2]
        smmu_size = result_find_smmu[3]
        
        if found_smmu:
            size3=  smmu_vpage_address+smmu_size- ipage_address_temp
            size1=  smmu_size - size3
            size2 = size_temp
            if (size3 <= size_temp): 
                size2 = size3 
            smmu_ppage_result_address = smmu_ppage_address + size1
            f_output.write( 'mmu.create ' + hex(vpage_address_temp).rstrip('L') + '++' + hex(size2-1).rstrip('L')+' ' + hex(smmu_ppage_result_address).rstrip('L') + '++' + hex(size2-1).rstrip('L')+'\n' )
            size_temp =  size_temp-size2
            #print ('size_temp'+ hex(size_temp)#)
            vpage_address_temp = vpage_address_temp+ size2
            ipage_address_temp = ipage_address_temp+ size2
        else:
            f_output.write( 'mmu.create ' + hex(vpage_address_temp).rstrip('L') + '++' + hex(size_temp-1).rstrip('L')+' ' + hex(ipage_address_temp).rstrip('L') + '++' + hex(size_temp-1).rstrip('L')+'\n' )
            size_temp=0x0
    
def map_smmu_asid(vpage_address, ipage_address, size, f_out,asid):
        
    vpage_address_temp= vpage_address
    ipage_address_temp= ipage_address
    size_temp = size
    f_output = f_out
    while(size_temp!= 0x0):
        found_smmu=0
        smmu_vpage_address=0x0
        smmu_ppage_address=0x0
        smmu_size=0x0 
        result_find_smmu= find_smmu_asid(ipage_address_temp,asid)
        found_smmu= result_find_smmu[0]
        smmu_vpage_address = result_find_smmu[1]
        smmu_ppage_address = result_find_smmu[2]
        smmu_size = result_find_smmu[3]
        
        if found_smmu:
            size3=  smmu_vpage_address+smmu_size- ipage_address_temp
            size1=  smmu_size - size3
            size2 = size_temp
            if (size3 <= size_temp): 
                size2 = size3 
            smmu_ppage_result_address = smmu_ppage_address + size1
            f_output.write( 'mmu.create ' + hex(vpage_address_temp).rstrip('L') + '++' + hex(size2-1).rstrip('L')+' ' + hex(smmu_ppage_result_address).rstrip('L') + '++' + hex(size2-1).rstrip('L')+'\n' )
            size_temp =  size_temp-size2
            #print ('size_temp'+ hex(size_temp)#)
            vpage_address_temp = vpage_address_temp+ size2
            ipage_address_temp = ipage_address_temp+ size2
        else:
            f_output.write( 'mmu.create ' + hex(vpage_address_temp).rstrip('L') + '++' + hex(size_temp-1).rstrip('L')+' ' + hex(ipage_address_temp).rstrip('L') + '++' + hex(size_temp-1).rstrip('L')+'\n' )
            size_temp=0x0


def main():
        
    f_out=open(smmu_filename,'w')
    f_dsppgt= open (pgt_filename, 'r')
    #f_out.write('mmu.reset\n')
    if "6GB_BasicMapping.txt" in pgt_filename:
        create_smmutxt_new()
    else:
        create_smmutxt_asid_new()

    for line_dsppgt in f_dsppgt:
        if ( line_dsppgt[0:2] == '0x'):
            list_dsppgt = line_dsppgt.split()
            vpage_address = int(list_dsppgt[0].replace('*',''),16)
            vpage_address = vpage_address * 0x1000
            asid = None
            if len(list_dsppgt[1]) > 8:
                asid = str(list_dsppgt[1][1:4])
                list_dsppgt[1] = list_dsppgt[1].replace('*','')
                list_dsppgt[1] = '0x'+list_dsppgt[1][3:]
            ipage_address= int(list_dsppgt[1].replace('*',''),16)
            ipage_address = ipage_address * 0x1000
            size= int(list_dsppgt[2].replace('*',''),16)
            #print (line_dsppgt)
            if asid == None:
                map_smmu(vpage_address, ipage_address, size, f_out)
            else:
                map_smmu_asid(vpage_address, ipage_address, size, f_out,asid)
    
    f_out.write('mmu.format QURT QURTK_pagetables\n')
    f_out.write('mmu.on\n')
    f_out.write('mmu.autoscan on\n')
    f_out.write('mmu.tablewalk on\n')
    
    f_dsppgt.close()
    f_out.close()



if __name__ == '__main__':
  main()

os.chdir(current_path)
