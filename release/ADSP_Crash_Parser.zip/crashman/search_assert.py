import re
import os

import sys
F3_path = sys.argv[1]
OutputPath    = sys.argv[2]


def search_str(file_path, word):
    with open(file_path, 'r') as fp:
        lines = fp.readlines()
        for line in lines:
            if word.lower() in line.lower():
                #print(word, 'string exists in file')
                #print('Line Number:', lines.index(line))
                #print('Line:', line)
                return line
    return ""
        

 #Assertion forw_offset >= sizeof(freeBlockList)            

words = ['Assertion'] #'Assertion !INTEGRITY_CHECK_ON_USED_HEADER','Assertion forw_offset'

for word in words:
	for file in os.listdir(F3_path):
		#print(file)
		if "root" in file.lower() and ".txt" in file.lower():
			line = search_str(F3_path+"/"+file, word)


blocks_info = re.findall(r'\b0x[\da-fA-F]+\b',line)
if len(blocks_info)>2:
	f = open(OutputPath+'/heap_assert.txt','w')
    f.write(blocks_info[-2])
    f.write(blocks_info[-1])
else:
    print("Assertion not found\n")


