# ------------------------------------------------------------------
#
# Copyright (c) 2019-2020 Qualcomm Technologies, Inc.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
# ------------------------------------------------------------------

import sys
import re
import os.path
import binascii
import datetime
import glob
import codecs

input=str(sys.argv[1])
outputpath=str(sys.argv[2])
TargetName=str(sys.argv[3])
subsystem = str(sys.argv[4])
new_target_flag = str(sys.argv[5])
start_address_file = outputpath+"//temp//adspstartaddr.txt"
alignment_address_file = outputpath+"//temp//alignment.txt"
dumpformat = outputpath+"//temp//dumpformant.txt"

print ("\nDump File : "+ input)
print ("Target    : "+ TargetName)
print ("Susbsytem : "+ subsystem)

if os.path.isfile(start_address_file): os.remove(start_address_file)

def DetectStartAddress_From_Provided_DumpFile(inputdump,outputpath,extension,TargetName,subsystem):

	def is_adsp_start_string(file,index,string,outputpath,input,seek_offset,TargetName,subsystem):
		# seek_offset = 121634824
		print ("Looking for "+string,seek_offset)
		StartAddress = False
		VirtualAddress = False
		if new_target_flag == "True":
			# if cdsp_flag == "True": len_30mb = 10485760 #10MB value
			# else: len_30mb = 31457280 #35MB value
			if subsystem == "cdsp":
				len_30mb = 10485760 #10MB value
				string_search = "IMAGE_VARIANT_STRING="+TargetName+".cdsp"
			else:
				len_30mb = 31457280 #35MB value
				string_search = "IMAGE_VARIANT_STRING="+TargetName+".adsp"
			file = open(input,'rb')
			file.seek(seek_offset) #125771029
			check_30mb = file.tell()
			count = 0
			cond_cdsp = False
			for line in file:
				line = line.decode(errors='ignore')
				count = count + 1
				offset = file.tell()
				if (offset-check_30mb)>=len_30mb: break
				if string_search in line: cond_cdsp = True
				if 'MINIDUMP' in string: cond_cdsp = True
				if string in line and cond_cdsp:
					try:
						temp =  line.split(string)[1].split()[0].strip()
						if not "%x" in temp:
							StartAddress = temp
							temp1 = line.split('VA-')[1].split('\x00')[0]
							if not "%x" in temp1:
								VirtualAddress = temp1
								if "*" in VirtualAddress:
									VirtualAddress = VirtualAddress.split('*')[0]
					except:
						print ("Error in Message!!")
					if VirtualAddress != False:
						VA = outputpath+"//temp//VA.txt"
						f2 = open(VA, 'w')
						f2.write(VirtualAddress)
						f2.close()
						break
			file.close()
		else:
			len_30mb = 36700160 #35MB value
			file = open(input,'rb')
			file.seek(seek_offset)
			check_30mb = file.tell()
			count = 0
			for line in file:
				count = count + 1
				offset = file.tell()
				if (offset-check_30mb)>=len_30mb:
					break
				if "*ADSP_START_ADDRESS: PA-" in line:
					try:
						temp =  line.split('*ADSP_START_ADDRESS: PA-')[1].split()[0]
						if not "%x" in temp:
							StartAddress = temp
							temp1 = line.split('VA-')[1].split('\x00')[0]
							if not "%x" in temp1:
								VirtualAddress = temp1
								if "*" in VirtualAddress:
									VirtualAddress = VirtualAddress.split('*')[0]
					except:
						print ("Error in Message!!")
					print (StartAddress)
					print (VirtualAddress)
					if VirtualAddress != False:
						VA = outputpath+"//temp//VA.txt"
						f2 = open(VA, 'w')
						f2.write(VirtualAddress)
						f2.close()
						break
			file.close()
		return StartAddress
	
	# list1=[0x00,0xC0,0x00,0x78,0x06,0x40,0x00,0x67]
	# list2=[0x0E,0xC0,0x00,0x58,0x00,0xC0,0x00,0x58]
	# string1,string2 = ["",""]
	# for item in list1: string1=string1+chr(item)
	# for item in list2: string2=string2+chr(item)
	list1=['00','C0','00','78','06','40','00','67']
	list2=['0E','C0','00','58','00','C0','00','58']
	string1 = "".join(list1)
	string2 = "".join(list2)
	inputfile = open(inputdump, 'rb')
	align_1mb = 0
	key = str((binascii.hexlify(inputfile.read(8))).decode(errors='ignore'))
	first_time_skip = 0
	address = None
	image_size = None
	while(key):
		if key.lower() == string1.lower() or key.lower() == string2.lower() or extension == ".elf" or extension == ".ELF":
			if first_time_skip == 0:
				first_time_skip = 1
				address = inputfile.tell()
			else:
				start_addr = is_adsp_start_string(inputfile,0,"ADSP_START_ADDRESS: PA-",outputpath,inputdump,inputfile.tell(),TargetName,subsystem)
				if start_addr != False:
					print ('Start_Addr',start_addr)
					f2 = open(start_address_file, 'w')
					f2.write(start_addr)
					f2.close()
					f2 = open(alignment_address_file, 'w')
					if (TargetName == "nicobar") or (TargetName == "6018") or (TargetName == "kamorta") or (TargetName == "divar"):
						i = int(start_addr,16) & 0x3FFFFFFF
					else:
						i = int(start_addr,16) & 0x7FFFFFFF
					if hex(i).replace('L','') == hex(align_1mb):
						f2.write(str(hex(align_1mb)))
						print ('Alignment_Address:',str(hex(align_1mb)))
					else:    
						f2.write(str(hex(i).replace('L','')))
						print ('Alignment_Address:',str(hex(i).replace('L','')))
					f2.close()
					break
		
		align_1mb = align_1mb+(0x100000)
		inputfile.seek(align_1mb)
		key = str((binascii.hexlify(inputfile.read(8))).decode(errors='ignore'))
	
	if first_time_skip == 1 and address != None and not os.path.isfile(start_address_file):
		print ("Looking for Second Time")
		inputfile.seek(address)
		start_addr = is_adsp_start_string(inputfile,0,"ADSP_START_ADDRESS: PA-",outputpath,inputdump,inputfile.tell(),TargetName,subsystem) 
		if start_addr != False:
			print ('Start_Addr',start_addr)
			f2 = open(start_address_file, 'w')
			f2.write(start_addr)
			f2.close()
	
	if first_time_skip == 1 and address != None and not os.path.isfile(start_address_file):
		if subsystem == "cdsp": tempstr = "*CDSP_MINIDUMP - "
		else: tempstr = "*ADSP_MINIDUMP  - "
		start_addr = is_adsp_start_string(inputfile,0,tempstr,outputpath,inputdump,inputfile.tell(),TargetName,subsystem)
		if start_addr != False:
			if '0X' not in start_addr: start_addr = '0X'+start_addr
			print ('Start_Addr',start_addr)
			f2 = open(start_address_file, 'w')
			f2.write(start_addr)
			f2.close()
	
	inputfile.close()

def Extract_StartAddress_and_ImageSize(binary_chunks,subsystem):
	for i in range(1,len(binary_chunks)):
		try:
			if subsystem=="cdsp1":
				address =  binary_chunks[i][6:14]
				image_size =  binary_chunks[i][6+8+8:14+8+8]
			elif subsystem=="gpdsp0" or subsystem=="gpdsp1":
				address =  binary_chunks[i][4:12]
				image_size =  binary_chunks[i][4+8+8:12+8+8]
			else:
				address =  binary_chunks[i][8:16]
				image_size =  binary_chunks[i][8+8+8:16+8+8]
		except:
			print("Error during Start Address Detection !!\n")
		address = '0x'+address[-2:]+address[-4:-2]+address[-6:-4]+address[-8:-6]
		image_size = '0x'+image_size[-2:]+image_size[-4:-2]+image_size[-6:-4]+image_size[-8:-6]
		print (address)
		print (image_size)
		if address[-5:]=='00000' and address!="0x00000000":
			StartAddress = address
			if image_size[-3:]=='000' and image_size!="0x00000000":
				return StartAddress,image_size
	return "",""
def DetectStartAddress_From_Ocimem_File(input,outputpath,subsystem):
	
	while True:  ## Extracting Ocimem file from dump location
		ocimem_check = ''
		for file in glob.glob(os.path.dirname(input)+'/ocimem*.BIN'): ocimem_check = file
		if ocimem_check == '':
			for file in glob.glob(os.path.dirname(input)+'//OCIMEM*.BIN'): ocimem_check = file
		if ocimem_check == '':
			for file in glob.glob(os.path.dirname(input)+'/ocimem*.lst'): ocimem_check = file
		if ocimem_check == '':
			print ("Ocimem file not present at Dump location")
			return False
		break
	
	if True:
		StartAddress = False
		ImageSize = False
		IssueType1,IssueType2,hextype1,hextype2 = ['adsp','ADSP','61647370','41445350']
		if subsystem =="cdsp" or subsystem =="cdsp0":
			IssueType1,IssueType2,hextype1,hextype2 = ['cdsp','CDSP','63647370','43445350']
		elif subsystem=="cdsp1":
			IssueType1,IssueType2,hextype1,hextype2 = ['cdsp1','CDSP1','6364737031','4344535031']
		elif subsystem == "slpi": 
			IssueType1,IssueType2,hextype1,hextype2 = ['slpi','SLPI','736c7069','534c5049']
		elif subsystem == "gpdsp0": 
			IssueType1,IssueType2,hextype1,hextype2 = ['gpdsp0','GPDSP0','677064737030','475044535030']
		elif subsystem == "gpdsp1": 
			IssueType1,IssueType2,hextype1,hextype2 = ['gpdsp1','GPDSP1','677064737031','475044535031']
		print ("Checking @ "+ocimem_check)
		with open(ocimem_check, 'rb') as readfile:
			for line in readfile:
				linetemp = binascii.hexlify(line).decode(errors='ignore')
				if hextype1 in linetemp or hextype2 in linetemp:
					#print (line,'\n**********\n')
					#print (linetemp,'\n**********\n')
					#print (binascii.hexlify(line),'\n**********\n')
					binary_chunks1 = binascii.hexlify(line).decode(errors='ignore').split(hextype1)
					binary_chunks2 = binascii.hexlify(line).decode(errors='ignore').split(hextype2)
					StartAddress,ImageSize =  Extract_StartAddress_and_ImageSize(binary_chunks1,subsystem)
					if(StartAddress=="" or ImageSize==""):
						StartAddress,ImageSize =  Extract_StartAddress_and_ImageSize(binary_chunks2,subsystem)
					else:
						#Start Address and Image Size detected, we can break
						break
						
					#print ("image--> ",image_size)
			if StartAddress!="" and ImageSize!="":					
				print ("Start_Address : "+StartAddress)
				f2 = open(start_address_file, 'w')
				f2.write(StartAddress+'\n')
				f2.close()
				print ("Image_Size : "+ImageSize)				
				f2 = open(outputpath+"//temp//adspimagesize.txt", 'w')
				f2.write(ImageSize)
				f2.close()
			else:
				print("Unable to extract START ADRESS\n")
			
	
	if offset_from_ocimem and StartAddress:  ## Extract Aligment Address from provided dump file
		offset = (str(hex(int(StartAddress, 0)-int(offset_from_ocimem, 0))))
		if 'L' in offset: offset = offset.replace("L",'')
		f2 = open(alignment_address_file, 'w')
		f2.write(offset)
		print ('Alignment_Addressss: '+offset)
		f2.close()


while True:   ## Type of dump file
	extension = os.path.splitext(input)[1]
	f1 = open(outputpath+"/temp/dumpformant.txt", 'w')
	if (extension == ".elf" or extension == ".ELF"):
		f1.write("2")
	else:
		f1.write("1")
	f1.close()
	break

while False:  ## Get Total Dump size
	possible_dump_name=["DDRCS0.BIN","DDRCS1.BIN","DDRCS0_0.BIN","DDRCS0_1.BIN","DDRCS0_2.BIN","DDRCS1_0.BIN","DDRCS1_1.BIN","DDRCS1_2.BIN","ADSP0.bin","EBICS0.RAM","dram_0x80000000--0xffffffff.lst","dram1_0x100000000--0x17fffffff.lst","dram_0x40000000--0xffffffff.lst","dram1_0x100000000--0x1bfffffff.lst","dram_cs1_0x100000000--0x17fffffff.lst","dram_cs1_0x180000000--0x1ffffffff.lst","dram_cs0_0x80000000--0xffffffff.lst","dram_cs0_0x100000000--0x17fffffff.lst","slpi_dump.bin","adsp_dump.bin",'rennell_dump.bin','EBICS0.bin']
	s1 =  os.path.getsize(input)
	DumpSize = 0
	for file in possible_dump_name:
		dump_file = os.path.dirname(input)+"/"+file
		if os.path.isfile(dump_file):
			DumpSize = DumpSize + os.path.getsize(dump_file)
	Enable_6GB = False
	if DumpSize > 4294967296: Enable_6GB = True 
	print ("Dump Size :",hex(DumpSize),':',DumpSize)
	break

try:          ## Get Dump file Start Address of dump file from load.cmm file
	offset_from_ocimem = ""
	if os.path.isfile(os.path.dirname(input)+"/load.cmm"):
		fileptr = open(os.path.dirname(input)+"/load.cmm",'r')
		linelist = fileptr.readlines()
		fileptr.close()
		linelist = list(filter(lambda x: x if ('binary' in x and not 'OCIMEM' in x.upper() ) else '', linelist ))
		DumpFileList =  [i.split()[1] for i in linelist]
		DumpFileStartAddressList =  [i.split()[2] for i in linelist]
		load_cmm_file_dict = dict (zip(DumpFileList,DumpFileStartAddressList))
		offset_from_ocimem = load_cmm_file_dict[os.path.basename(input)]
		print ("Dump File Start_Addrs :"+offset_from_ocimem)
except:
	pass

print ("\nPlease wait, finding start address...")

if not "md_adsp" in input.split("\\")[-1].lower() and not "md_cdsp" in input.split("\\")[-1].lower()  :
	return_flag = DetectStartAddress_From_Ocimem_File(input,outputpath,subsystem)
	if os.path.isfile(start_address_file): sys.exit(0)
	if return_flag!=False: print ("Start Address not detected from Ocimem file.")

	print ("\nTrying to extract address from ",input)
	DetectStartAddress_From_Provided_DumpFile(input,outputpath,extension,TargetName,subsystem)
	if os.path.isfile(start_address_file): sys.exit(0)
	print ('\nNot able to extract Start Address from Ocimem file and from Dump file')

else :
	""" Minidump Support """
	start_address_md_blobs={}  #Dictionary to maintain addresses and names of Bin's
	md_file = input.split("\\")
	md_file_location = ""
	# print(md_file)

	for val in range(len(md_file)-1) :
		md_file_location += md_file[val]
		md_file_location += "/"

	# print(outputpath)
	# print(md_file[-1])
	fp = open(outputpath +r"/temp/ExtractAddress.txt",'r')
	while True:
		var = fp.readline()
		if len(var) == 0:
			break
		if (md_file[-1].split("_")[1] in var or "FRPC" in var):
			start_address_md_blobs[var.split(" ")[-1].strip("\n")] = var.split(" ")[0]
	fp.close()
	print("start_address_md_blobs:")
	print(start_address_md_blobs)
	fp = open(outputpath +r"/temp/Minidump_Address.txt",'w')
	for key,val in start_address_md_blobs.items() :
		command = "d.load.binary "+md_file_location+key+" "+val+" /noclear" +"\n"
		fp.write(command)
	fp.close()

	offset_from_EA = start_address_md_blobs[md_file[-1].split(".")[0] + ".BIN"]
	print("offset_from_EA : "+offset_from_EA)
	""" """

if 'md_adsp' in input.split("/")[-1].lower() or 'md_cdsp' in input.split("/")[-1].lower():
	print ('Start_Addr :'+offset_from_EA)
	f2 = open(start_address_file, 'w')
	f2.write(offset_from_EA)
	f2.close()
"""	
if (os.path.splitext(input)[1] == ".elf" or os.path.splitext(input)[1] == ".ELF"):
	f1 = open(dumpformat, 'w')
	f1.write('2')
	f1.close()
	
	f4 = open(input,"rb")
	f4.seek(60)
	s1=str((binascii.hexlify(f4.read(1))).decode(errors='ignore'))
	s2=str((binascii.hexlify(f4.read(1))).decode(errors='ignore'))
	s3=str((binascii.hexlify(f4.read(1))).decode(errors='ignore'))
	s4=str((binascii.hexlify(f4.read(1))).decode(errors='ignore'))
	address = "0x"+s4+s3+s2+s1
	f4.close()
	print ('Start_Addr : '+address)
	f2 = open(start_address_file, 'w')
	f2.write(address)
	f2.close()
"""