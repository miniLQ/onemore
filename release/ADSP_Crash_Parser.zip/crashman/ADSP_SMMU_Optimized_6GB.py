# ------------------------------------------------------------------
#
# Copyright (c) 2019-2020 Qualcomm Technologies, Inc.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
# IP -> OP
# 6GB_BasicMapping.txt -> DSP_smmu_pagetables_basic.cmm
# 6GB_NonBasicMapping.txt -> DSP_smmu_pagetables_nonbasic.cmm
# ------------------------------------------------------------------

import sys
import re
import os
import datetime
import time

current_path=os.getcwd()
input=str(sys.argv[1])
smmu_filename=str(sys.argv[2])
pgt_filename=str(sys.argv[3])
key=str(sys.argv[4])
target_id = sys.argv[5]
new_target_flag = sys.argv[6]

os.chdir(input)


smmu_fastrpc_list_initialize = {
			  'adsp':{
					  'bitra':{
								'0x1':['msm-audio-ion'],
								'0x3':['msm_fastrpc_compute_cb10'],
								'0x4':['msm_fastrpc_compute_cb11'],
								'0x5':['msm_fastrpc_compute_cb12']
							   },
					  'atherton':{
							  '0x3':['msm_fastrpc_compute_cb1'],
							  '0x4':['msm_fastrpc_compute_cb2'],
							  '0x5':['msm_fastrpc_compute_cb3'],
							  '0x6':['msm_fastrpc_compute_cb4'],
							  '0x7':['msm_fastrpc_compute_cb5']
							 },
					  'kamorta':{
							  '0x1':['msm-audio-ion'],
							  '0x3':['msm_fastrpc_compute_cb10'],
							  '0x4':['msm_fastrpc_compute_cb11'],
							  '0x5':['msm_fastrpc_compute_cb12'],
							  '0x6':['msm_fastrpc_compute_cb13'],
							  '0x7':['msm_fastrpc_compute_cb14']
							 },
					  'divar':{
							  '0x1':['msm-audio-ion'],
							  '0x3':['msm_fastrpc_compute_cb10'],
							  '0x4':['msm_fastrpc_compute_cb11'],
							  '0x5':['msm_fastrpc_compute_cb12'],
							  '0x6':['msm_fastrpc_compute_cb13'],
							  '0x7':['msm_fastrpc_compute_cb14']
							 },
					  'mannar':{
							  '0x1':['msm-audio-ion'],
							  '0x3':['msm_fastrpc_compute_cb10'],
							  '0x4':['msm_fastrpc_compute_cb11'],
							  '0x5':['msm_fastrpc_compute_cb12'],
							  '0x6':['msm_fastrpc_compute_cb13'],
							  '0x7':['msm_fastrpc_compute_cb14']
							 },
					  'strait':{
							  '0x1':['msm-audio-ion'],
							  '0x3':['msm_fastrpc_compute_cb10'],
							  '0x4':['msm_fastrpc_compute_cb11'],
							  '0x5':['msm_fastrpc_compute_cb12'],
							  '0x6':['msm_fastrpc_compute_cb13'],
							  '0x7':['msm_fastrpc_compute_cb14']
							 },
					  '6018':{
							'0x1':['msm-audio-ion'],
							'0x4':['msm_fastrpc_compute_cb1'],
							'0x5':['msm_fastrpc_compute_cb2'],
							'0x6':['msm_fastrpc_compute_cb3'],
							'0x7':['msm_fastrpc_compute_cb4'],
							'0x8':['msm_fastrpc_compute_cb5'],
							'0x9':['msm_fastrpc_compute_cb6'],
							'0xa':['msm_fastrpc_compute_cb7'],
							'0xb':['msm_fastrpc_compute_cb8']
							   },
					  'rennell':{
								'0x1':['msm-audio-ion'],
								'0x3':['msm_fastrpc_compute_cb10'],
								'0x4':['msm_fastrpc_compute_cb11'],
								'0x5':['msm_fastrpc_compute_cb12']
							   },
					  'saipan':{
								'0x1':['msm-audio-ion'],
								'0x3':['msm_fastrpc_compute_cb10'],
								'0x4':['msm_fastrpc_compute_cb11'],
								'0x5':['msm_fastrpc_compute_cb12']
							   },
					  'halliday':{
								'0x1':['msm-audio-ion'],
								'0x3':['msm_fastrpc_compute_cb10'],
								'0x4':['msm_fastrpc_compute_cb11'],
								'0x5':['msm_fastrpc_compute_cb12']
							   },
					  'aurora':{
								'0x1':['msm-audio-ion'],
								'0x3':['msm_fastrpc_compute_cb10'],
								'0x4':['msm_fastrpc_compute_cb11'],
								'0x5':['msm_fastrpc_compute_cb12'],
								'0x6':['msm_fastrpc_compute_cb13']
							   },
					  '8250':{
								'0x1':['msm-audio-ion'],
								'0x3':['msm_fastrpc_compute_cb10'],
								'0x4':['msm_fastrpc_compute_cb11'],
								'0x5':['msm_fastrpc_compute_cb12']
							   },
					  'nicobar':{
								'0x1':['msm-audio-ion'],
								'0x3':['msm_fastrpc_compute_cb10'],
								'0x4':['msm_fastrpc_compute_cb10'],
								},
					  '7150':{
							  '0x1':['msm-audio-ion'],
							  '0x3':['msm_fastrpc_compute_cb10'],
							  '0x4':['msm_fastrpc_compute_cb11'],
							  '0x5':['msm_fastrpc_compute_cb12'],
							  '0x6':['msm_fastrpc_compute_cb13'],
							  '0x7':['msm_fastrpc_compute_cb14'],
							  '0x8':['msm_fastrpc_compute_cb15']
							 },
					  '6150':{
							  '0x1':['msm-audio-ion'],
							  '0x3':['msm_fastrpc_compute_cb10'],
							  '0x4':['msm_fastrpc_compute_cb11'],
							  '0x5':['msm_fastrpc_compute_cb12'],
							  '0x6':['msm_fastrpc_compute_cb13'],
							  '0x7':['msm_fastrpc_compute_cb14'],
							  '0x8':['msm_fastrpc_compute_cb15']
							 },
					  '855':{
							  '0x1':['msm-audio-ion'],
							  '0x3':['msm_fastrpc_compute_cb10'],
							  '0x4':['msm_fastrpc_compute_cb11'],
							  '0x5':['msm_fastrpc_compute_cb12']
							 },
					  'lahaina':{
							  '0x1':['msm-audio-ion'],
							  '0x3':['msm_fastrpc_compute_cb10'],
							  '0x4':['msm_fastrpc_compute_cb11'],
							  '0x5':['msm_fastrpc_compute_cb12']
							 },
					  'waipio':{
							  '0x1':['msm-audio-ion'],
							  '0x3':['msm_fastrpc_compute_cb10'],
							  '0x4':['msm_fastrpc_compute_cb11'],
							  '0x5':['msm_fastrpc_compute_cb12']
							 },
					  'kailua':{
							  '0x1':['msm-audio-ion'],
							  '0x3':['msm_fastrpc_compute_cb10'],
							  '0x4':['msm_fastrpc_compute_cb11'],
							  '0x5':['msm_fastrpc_compute_cb12'],
							  '0x6':['msm_fastrpc_compute_cb13'],
							  '0x7':['msm_fastrpc_compute_cb14']
							 },
					  'camano':{
							  '0x1':['msm-audio-ion'],
							  '0x3':['msm_fastrpc_compute_cb10'],
							  '0x4':['msm_fastrpc_compute_cb11'],
							  '0x5':['msm_fastrpc_compute_cb12'],
							  '0x6':['msm_fastrpc_compute_cb13']
							 },
					  'lanai':{
							  '0x1':['msm-audio-ion'],
							  '0x3':['msm_fastrpc_compute_cb10'],
							  '0x4':['msm_fastrpc_compute_cb11'],
							  '0x5':['msm_fastrpc_compute_cb12'],
							  '0x6':['msm_fastrpc_compute_cb13'],
							  '0x7':['msm_fastrpc_compute_cb14']
							 },
					  'hamoa':{
							  '0x3':['0x17030180','0x20'],
							  '0x4':['0x170301A0','0x21'],
							  '0x5':['0x170301C0','0x22'],
							  '0x6':['0x170301E0','0x23'],
							  '0x7':['0x17030200','0x24']
							 },
					  'makena':{
							  '0x3':['0x17030034','0x2c'],
							  '0x4':['0x17030035','0x2d'],
							  '0x5':['0x17030036','0x2e']
							 },
					  'cedros':{
							  '0x1':['msm-audio-ion'],
							  '0x3':['msm_fastrpc_compute_cb10'],
							  '0x4':['msm_fastrpc_compute_cb11'],
							  '0x5':['msm_fastrpc_compute_cb12']
							 },
					  'fillmore':{
							  '0x1':['msm-audio-ion'],
							  '0x3':['msm_fastrpc_compute_cb10'],
							  '0x4':['msm_fastrpc_compute_cb11'],
							  '0x5':['msm_fastrpc_compute_cb12']
							 },
					  'netrani':{
							  '0x1':['msm-audio-ion'],
							  '0x3':['msm_fastrpc_compute_cb10'],
							  '0x4':['msm_fastrpc_compute_cb11'],
							  '0x5':['msm_fastrpc_compute_cb12']
							 },
					  'clarence':{
							  '0x1':['msm-audio-ion'],
							  '0x3':['msm_fastrpc_compute_cb1'],
							  '0x4':['msm_fastrpc_compute_cb2'],
							  '0x5':['msm_fastrpc_compute_cb3']
							 },
					  'kodiak':{
							  '0x1':['msm-audio-ion'],
							  '0x3':['msm_fastrpc_compute_cb10','0x26'],
							  '0x4':['msm_fastrpc_compute_cb11','0x27'],
							  '0x5':['msm_fastrpc_compute_cb12','0x28']
							 },
					  '670':{
							'0x1':['msm-audio-ion'],
							'0x3':['msm_fastrpc_compute_cb9'],
							'0x4':['msm_fastrpc_compute_cb10'],
							'0x5':['msm_fastrpc_compute_cb11'],
							'0x6':['msm_fastrpc_compute_cb12']
							 },
					  '845':{
							'0x3':['msm_fastrpc_compute_cb11'],
							'0x4':['msm_fastrpc_compute_cb12']
							 },
					  '1000':{
							'0x3':['msm_fastrpc_compute_cb11'],
							'0x4':['msm_fastrpc_compute_cb12']
							 },
					  '660':{
							'0x3':['msm_fastrpc_compute_cb1'],
							'0x7':['msm_fastrpc_compute_cb2'],
							'0x8':['msm_fastrpc_compute_cb3'],
							'0x9':['msm_fastrpc_compute_cb4'],
							'0xa':['msm_fastrpc_compute_cb5'],
							'0xb':['msm_fastrpc_compute_cb6'],
							'0xc':['msm_fastrpc_compute_cb7'],
							'0xd':['msm_fastrpc_compute_cb8'],
							 },
					  '8996':{
							'0x8':['msm_fastrpc_compute_cb1'],
							'0x9':['msm_fastrpc_compute_cb2'],
							'0xa':['msm_fastrpc_compute_cb3'],
							'0xb':['msm_fastrpc_compute_cb4'],
							'0xc':['msm_fastrpc_compute_cb5'],
							'0xd':['msm_fastrpc_compute_cb6'],
							'0xe':['msm_fastrpc_compute_cb7'],
							'0xf':['msm_fastrpc_compute_cb8'],
							 },
					  '405':{
							'0x4':['msm_fastrpc_compute_cb6'],
							'0x5':['msm_fastrpc_compute_cb7'],
							'0x6':['msm_fastrpc_compute_cb8']
							 },
					 },
			  'cdsp':{
					  'bitra':{
								'0x1':['msm_fastrpc_compute_cb1'],
								'0x2':['msm_fastrpc_compute_cb2'],
								'0x3':['msm_fastrpc_compute_cb3'],
								'0x4':['msm_fastrpc_compute_cb4'],
								'0x5':['msm_fastrpc_compute_cb5'],
								'0x6':['msm_fastrpc_compute_cb6'],
								'0x7':['msm_fastrpc_compute_cb7'],
								'0x8':['msm_fastrpc_compute_cb8'],
								'0x9':['msm_fastrpc_compute_cb9']
								},
					  '405':{
							'0x1':['msm_fastrpc_compute_cb1'],
							'0x2':['msm_fastrpc_compute_cb2'],
							'0x3':['msm_fastrpc_compute_cb3'],
							'0x4':['msm_fastrpc_compute_cb4'],
							'0x5':['msm_fastrpc_compute_cb5']
							 },
					  'kamorta':{
								'0x1':['msm_fastrpc_compute_cb1'],
								'0x2':['msm_fastrpc_compute_cb2'],
								'0x3':['msm_fastrpc_compute_cb3'],
								'0x4':['msm_fastrpc_compute_cb4'],
								'0x5':['msm_fastrpc_compute_cb5'],
								'0x6':['msm_fastrpc_compute_cb6'],
								'0x9':['msm_fastrpc_compute_cb9']
								},
					  'divar':{
								'0x1':['msm_fastrpc_compute_cb1'],
								'0x2':['msm_fastrpc_compute_cb2'],
								'0x3':['msm_fastrpc_compute_cb3'],
								'0x4':['msm_fastrpc_compute_cb4'],
								'0x5':['msm_fastrpc_compute_cb5'],
								'0x6':['msm_fastrpc_compute_cb6'],
								'0x9':['msm_fastrpc_compute_cb9']
								},
					  'mannar':{
								'0x1':['msm_fastrpc_compute_cb1'],
								'0x2':['msm_fastrpc_compute_cb2'],
								'0x3':['msm_fastrpc_compute_cb3'],
								'0x4':['msm_fastrpc_compute_cb4'],
								'0x5':['msm_fastrpc_compute_cb5'],
								'0x6':['msm_fastrpc_compute_cb6'],
								'0x9':['msm_fastrpc_compute_cb9']
								},
					  'strait':{
								'0x1':['msm_fastrpc_compute_cb1'],
								'0x2':['msm_fastrpc_compute_cb2'],
								'0x3':['msm_fastrpc_compute_cb3'],
								'0x4':['msm_fastrpc_compute_cb4'],
								'0x5':['msm_fastrpc_compute_cb5'],
								'0x6':['msm_fastrpc_compute_cb6'],
								'0x9':['msm_fastrpc_compute_cb9']
								},
					  '6018':{
								'0x1':['msm_fastrpc_compute_cb1'],
								'0x2':['msm_fastrpc_compute_cb2'],
								'0x3':['msm_fastrpc_compute_cb3'],
								'0x4':['msm_fastrpc_compute_cb4'],
								'0x5':['msm_fastrpc_compute_cb5']
							   },
					  'rennell':{
								'0x1':['msm_fastrpc_compute_cb1'],
								'0x2':['msm_fastrpc_compute_cb2'],
								'0x3':['msm_fastrpc_compute_cb3'],
								'0x4':['msm_fastrpc_compute_cb4'],
								'0x5':['msm_fastrpc_compute_cb5'],
								'0x6':['msm_fastrpc_compute_cb6'],
								'0x7':['msm_fastrpc_compute_cb7'],
								'0x8':['msm_fastrpc_compute_cb8'],
								'0x9':['msm_fastrpc_compute_cb9']
								},
					  'saipan':{
								'0x1':['msm_fastrpc_compute_cb1'],
								'0x2':['msm_fastrpc_compute_cb2'],
								'0x3':['msm_fastrpc_compute_cb3'],
								'0x4':['msm_fastrpc_compute_cb4'],
								'0x5':['msm_fastrpc_compute_cb5'],
								'0x6':['msm_fastrpc_compute_cb6'],
								'0x7':['msm_fastrpc_compute_cb7'],
								'0x8':['msm_fastrpc_compute_cb8'],
								'0x9':['msm_fastrpc_compute_cb9']
								},
					  'aurora':{
								'0x1':['msm_fastrpc_compute_cb1'],
								'0x2':['msm_fastrpc_compute_cb2'],
								'0x3':['msm_fastrpc_compute_cb3'],
								'0x4':['msm_fastrpc_compute_cb4'],
								'0x5':['msm_fastrpc_compute_cb5'],
								'0x6':['msm_fastrpc_compute_cb6'],
								'0x7':['msm_fastrpc_compute_cb7'],
								'0x8':['msm_fastrpc_compute_cb8'],
								'0x9':['msm_fastrpc_compute_cb9']
								},
					  'halliday':{
								'0x1':['msm_fastrpc_compute_cb1'],
								'0x2':['msm_fastrpc_compute_cb2'],
								'0x3':['msm_fastrpc_compute_cb3'],
								'0x4':['msm_fastrpc_compute_cb4'],
								'0x5':['msm_fastrpc_compute_cb5'],
								'0x6':['msm_fastrpc_compute_cb6'],
								'0x7':['msm_fastrpc_compute_cb7'],
								'0x8':['msm_fastrpc_compute_cb8'],
								'0x9':['msm_fastrpc_compute_cb9'],
								'0xb':['msm_fastrpc_compute_cb13'],
								'0xc':['msm_fastrpc_compute_cb14'],
								'0xd':['msm_fastrpc_compute_cb15'],
								'0xe':['msm_fastrpc_compute_cb16']
								},
					  '8250':{
								'0x1':['msm_fastrpc_compute_cb1'],
								'0x2':['msm_fastrpc_compute_cb2'],
								'0x3':['msm_fastrpc_compute_cb3'],
								'0x4':['msm_fastrpc_compute_cb4'],
								'0x5':['msm_fastrpc_compute_cb5'],
								'0x6':['msm_fastrpc_compute_cb6'],
								'0x7':['msm_fastrpc_compute_cb7'],
								'0x8':['msm_fastrpc_compute_cb8'],
								'0x9':['msm_fastrpc_compute_cb9']
							 },
					  'nicobar':{
								'0x1':['msm_fastrpc_compute_cb1'],
								'0x2':['msm_fastrpc_compute_cb2'],
								'0x3':['msm_fastrpc_compute_cb3'],
								'0x4':['msm_fastrpc_compute_cb4'],
								'0x5':['msm_fastrpc_compute_cb5'],
								'0x6':['msm_fastrpc_compute_cb6'],
								'0x9':['msm_fastrpc_compute_cb9']
								},
					  '7150':{
							  '0x1':['msm_fastrpc_compute_cb1'],
							  '0x2':['msm_fastrpc_compute_cb2'],
							  '0x3':['msm_fastrpc_compute_cb3'],
							  '0x4':['msm_fastrpc_compute_cb4'],
							  '0x5':['msm_fastrpc_compute_cb5'],
							  '0x6':['msm_fastrpc_compute_cb6'],
							  '0x9':['msm_fastrpc_compute_cb9']
							 },
					  '6150':{
							  '0x1':['msm_fastrpc_compute_cb1'],
							  '0x2':['msm_fastrpc_compute_cb2'],
							  '0x3':['msm_fastrpc_compute_cb3'],
							  '0x4':['msm_fastrpc_compute_cb4'],
							  '0x5':['msm_fastrpc_compute_cb5'],
							  '0x6':['msm_fastrpc_compute_cb6'],
							  '0x9':['msm_fastrpc_compute_cb9']
							 },
					  '855':{
							'0x1':['msm_fastrpc_compute_cb1','STCU_CB19'],
							'0x2':['msm_fastrpc_compute_cb2'],
							'0x3':['msm_fastrpc_compute_cb3'],
							'0x4':['msm_fastrpc_compute_cb4'],
							'0x5':['msm_fastrpc_compute_cb5'],
							'0x6':['msm_fastrpc_compute_cb6'],
							'0x7':['msm_fastrpc_compute_cb7'],
							'0x8':['msm_fastrpc_compute_cb8'],
							'0x9':['msm_fastrpc_compute_cb9']
							 },
					  'lahaina':{
							'0x1':['msm_fastrpc_compute_cb1'],
							'0x2':['msm_fastrpc_compute_cb2'],
							'0x3':['msm_fastrpc_compute_cb3'],
							'0x4':['msm_fastrpc_compute_cb4'],
							'0x5':['msm_fastrpc_compute_cb5'],
							'0x6':['msm_fastrpc_compute_cb6'],
							'0x7':['msm_fastrpc_compute_cb7'],
							'0x8':['msm_fastrpc_compute_cb8'],
							'0x9':['msm_fastrpc_compute_cb9'],
							'0xb':['msm_fastrpc_compute_cb16'],
							'0xc':['msm_fastrpc_compute_cb17'],
							'0xd':['msm_fastrpc_compute_cb18'],
							'0xe':['msm_fastrpc_compute_cb19']
							 },
					  'waipio':{
							'0x1':['msm_fastrpc_compute_cb1'],
							'0x2':['msm_fastrpc_compute_cb2'],
							'0x3':['msm_fastrpc_compute_cb3'],
							'0x4':['msm_fastrpc_compute_cb4'],
							'0x5':['msm_fastrpc_compute_cb5'],
							'0x6':['msm_fastrpc_compute_cb6'],
							'0x7':['msm_fastrpc_compute_cb7'],
							'0x8':['msm_fastrpc_compute_cb8'],
							'0x9':['msm_fastrpc_compute_cb9'],
							'0xb':['msm_fastrpc_compute_cb16'],
							'0xc':['msm_fastrpc_compute_cb17'],
							'0xd':['msm_fastrpc_compute_cb18'],
							'0xe':['msm_fastrpc_compute_cb19']
							 },
					  'kailua':{
							'0x1':['msm_fastrpc_compute_cb1'],
							'0x2':['msm_fastrpc_compute_cb2'],
							'0x3':['msm_fastrpc_compute_cb3'],
							'0x4':['msm_fastrpc_compute_cb4'],
							'0x5':['msm_fastrpc_compute_cb5'],
							'0x6':['msm_fastrpc_compute_cb6'],
							'0x7':['msm_fastrpc_compute_cb7'],
							'0x8':['msm_fastrpc_compute_cb8'],
							'0x9':['msm_fastrpc_compute_cb9'],
							'0xc':['msm_fastrpc_compute_cb15'],
							'0xd':['msm_fastrpc_compute_cb16'],
							'0xe':['msm_fastrpc_compute_cb17'],
							'0xf':['msm_fastrpc_compute_cb18']
							 },
					  'camano':{
							'0x1':['msm_fastrpc_compute_cb1'],
							'0x2':['msm_fastrpc_compute_cb2'],
							'0x3':['msm_fastrpc_compute_cb3'],
							'0x4':['msm_fastrpc_compute_cb4'],
							'0x5':['msm_fastrpc_compute_cb5'],
							'0x6':['msm_fastrpc_compute_cb6'],
							'0x7':['msm_fastrpc_compute_cb7'],
							'0x8':['msm_fastrpc_compute_cb8'],
							'0x9':['msm_fastrpc_compute_cb9'],
							'0xc':['msm_fastrpc_compute_cb14'],
							'0xd':['msm_fastrpc_compute_cb15'],
							'0xe':['msm_fastrpc_compute_cb16'],
							'0xf':['msm_fastrpc_compute_cb17']
							 },
					  'lanai':{
							'0x1':['msm_fastrpc_compute_cb1'],
							'0x2':['msm_fastrpc_compute_cb2'],
							'0x3':['msm_fastrpc_compute_cb3'],
							'0x4':['msm_fastrpc_compute_cb4'],
							'0x5':['msm_fastrpc_compute_cb5'],
							'0x6':['msm_fastrpc_compute_cb6'],
							'0x7':['msm_fastrpc_compute_cb7'],
							'0x8':['msm_fastrpc_compute_cb8'],
							'0x9':['msm_fastrpc_compute_cb9'],
							'0xc':['msm_fastrpc_compute_cb15'],
							'0xd':['msm_fastrpc_compute_cb16'],
							'0xe':['msm_fastrpc_compute_cb17']
							 },
					  'makena':{
							'0x1':['0x17030000','0x1f','STCU_CB40'],
							'0x2':['0x17030004','0x20','STCU_CB41'],
							'0x3':['0x17030008','0x21','STCU_CB42'],
							'0x4':['0x1703000c','0x22','STCU_CB43'],
							'0x5':['0x17030010','0x23','STCU_CB44'],
							'0x6':['0x17030014','0x24','STCU_CB45'],
							'0x7':['0x17030018','0x25','STCU_CB46'],
							'0x8':['0x1703001c','0x26','STCU_CB47'],
							'0xb':['0x17030020','0x27'],
							'0xc':['0x17030024','0x28'],
							'0xd':['0x17030028','0x29'],
							'0xe':['0x1703002c','0x2a'],
							'0xf':['0x17030030','0x2b']
							 },
					  'hamoa':{
							'0x1':['0x17030000','0x14','STCU_CB40'],
							'0x2':['0x17030020','0x15','STCU_CB41'],
							'0x3':['0x17030040','0x16','STCU_CB42'],
							'0x4':['0x17030060','0x17','STCU_CB43'],
							'0x5':['0x17030080','0x18','STCU_CB44'],
							'0x6':['0x170300A0','0x19','STCU_CB45'],
							'0x7':['0x170300C0','0x1A','STCU_CB46'],
							'0x8':['0x170300E0','0x1B','STCU_CB47'],
							'0xc':['0x17030100','0x1C'],
							'0xd':['0x17030120','0x1D'],
							'0xe':['0x17030140','0x1E'],
							'0xf':['0x17030160','0x1F']
							 },
					  'cedros':{
							'0x1':['msm_fastrpc_compute_cb1'],
							'0x2':['msm_fastrpc_compute_cb2'],
							'0x3':['msm_fastrpc_compute_cb3'],
							'0x4':['msm_fastrpc_compute_cb4'],
							'0x5':['msm_fastrpc_compute_cb5'],
							'0x6':['msm_fastrpc_compute_cb6'],
							'0x7':['msm_fastrpc_compute_cb7'],
							'0x8':['msm_fastrpc_compute_cb8'],
							'0x9':['msm_fastrpc_compute_cb9'],
							'0xb':['msm_fastrpc_compute_cb16'],
							'0xc':['msm_fastrpc_compute_cb17'],
							'0xd':['msm_fastrpc_compute_cb18'],
							'0xe':['msm_fastrpc_compute_cb19']
							 },
					  'fillmore':{
							'0x1':['msm_fastrpc_compute_cb1'],
							'0x2':['msm_fastrpc_compute_cb2'],
							'0x3':['msm_fastrpc_compute_cb3'],
							'0x4':['msm_fastrpc_compute_cb4'],
							'0x5':['msm_fastrpc_compute_cb5'],
							'0x6':['msm_fastrpc_compute_cb6'],
							'0x7':['msm_fastrpc_compute_cb7'],
							'0x8':['msm_fastrpc_compute_cb8'],
							'0x9':['msm_fastrpc_compute_cb9'],
							'0xb':['msm_fastrpc_compute_cb13'],
							'0xc':['msm_fastrpc_compute_cb14'],
							'0xd':['msm_fastrpc_compute_cb15'],
							'0xe':['msm_fastrpc_compute_cb16']
							 },
					  'netrani':{
							'0x1':['msm_fastrpc_compute_cb1'],
							'0x2':['msm_fastrpc_compute_cb2'],
							'0x3':['msm_fastrpc_compute_cb3'],
							'0x4':['msm_fastrpc_compute_cb4'],
							'0x5':['msm_fastrpc_compute_cb5'],
							'0x6':['msm_fastrpc_compute_cb6'],
							'0x7':['msm_fastrpc_compute_cb7'],
							'0x8':['msm_fastrpc_compute_cb8'],
							'0x9':['msm_fastrpc_compute_cb9'],
							'0xb':['msm_fastrpc_compute_cb13'],
							'0xc':['msm_fastrpc_compute_cb14'],
							'0xd':['msm_fastrpc_compute_cb15'],
							'0xe':['msm_fastrpc_compute_cb16']
							 },
					  'kodiak':{
							'0x1':['msm_fastrpc_compute_cb1','0x19'],
							'0x2':['msm_fastrpc_compute_cb2','0x1a'],
							'0x3':['msm_fastrpc_compute_cb3','0x1b'],
							'0x4':['msm_fastrpc_compute_cb4','0x1c'],
							'0x5':['msm_fastrpc_compute_cb5','0x1d'],
							'0x6':['msm_fastrpc_compute_cb6','0x1e'],
							'0x7':['msm_fastrpc_compute_cb7','0x1f'],
							'0x8':['msm_fastrpc_compute_cb8','0x20'],
							'0x9':['msm_fastrpc_compute_cb9'],
							'0xb':['msm_fastrpc_compute_cb13','0x21'],
							'0xc':['msm_fastrpc_compute_cb14','0x22'],
							'0xd':['msm_fastrpc_compute_cb15','0x23'],
							'0xe':['msm_fastrpc_compute_cb16','0x24'],
							'0xf':['0x25']
							 },
					  '670':{
							'0x1':['msm_fastrpc_compute_cb1'],
							'0x2':['msm_fastrpc_compute_cb2'],
							'0x3':['msm_fastrpc_compute_cb3'],
							'0x4':['msm_fastrpc_compute_cb4'],
							'0x5':['msm_fastrpc_compute_cb5'],
							'0x6':['msm_fastrpc_compute_cb6'],
							'0x9':['msm_fastrpc_compute_cb7'],
							'0xa':['msm_fastrpc_compute_cb8'],
							 },
					  '845':{
							'0x1':['msm_fastrpc_compute_cb1'],
							'0x2':['msm_fastrpc_compute_cb2'],
							'0x3':['msm_fastrpc_compute_cb3'],
							'0x4':['msm_fastrpc_compute_cb4'],
							'0x5':['msm_fastrpc_compute_cb5'],
							'0x6':['msm_fastrpc_compute_cb6'],
							'0x7':['msm_fastrpc_compute_cb7'],
							'0x8':['msm_fastrpc_compute_cb8'],
							'0x9':['msm_fastrpc_compute_cb9'],
							'0xa':['msm_fastrpc_compute_cb10']
							 },
					  '1000':{
							'0x1':['msm_fastrpc_compute_cb1','STCU_CB25'],
							'0x2':['msm_fastrpc_compute_cb2'],
							'0x3':['msm_fastrpc_compute_cb3'],
							'0x4':['msm_fastrpc_compute_cb4'],
							'0x5':['msm_fastrpc_compute_cb5'],
							'0x6':['msm_fastrpc_compute_cb6'],
							'0x7':['msm_fastrpc_compute_cb7'],
							'0x8':['msm_fastrpc_compute_cb8'],
							'0x9':['msm_fastrpc_compute_cb9'],
							'0xa':['msm_fastrpc_compute_cb10']
							 },
					  '660':{
							'0x3':['msm_fastrpc_compute_cb5'],
							'0x4':['msm_fastrpc_compute_cb6'],
							'0x5':['msm_fastrpc_compute_cb7'],
							'0x6':['msm_fastrpc_compute_cb8'],
							'0x7':['msm_fastrpc_compute_cb9'],
							'0x8':['msm_fastrpc_compute_cb1'],
							'0x9':['msm_fastrpc_compute_cb2'],
							'0xa':['msm_fastrpc_compute_cb3'],
							'0xb':['msm_fastrpc_compute_cb4'],
							 },
					  '8996':{
							'0x8':['msm_fastrpc_compute_cb1'],
							'0x9':['msm_fastrpc_compute_cb2'],
							'0xa':['msm_fastrpc_compute_cb3'],
							'0xb':['msm_fastrpc_compute_cb4'],
							'0xc':['msm_fastrpc_compute_cb5'],
							'0xd':['msm_fastrpc_compute_cb6'],
							'0xe':['msm_fastrpc_compute_cb7'],
							'0xf':['msm_fastrpc_compute_cb8']
							 }
					 },
			  'slpi':{
					  'bitra':{
								'0x1':['msm_fastrpc_compute_cb13'],
								'0x2':['msm_fastrpc_compute_cb14'],
								'0x3':['msm_fastrpc_compute_cb15']
								},
					  'saipan':{
								'0x1':['msm_fastrpc_compute_cb13'],
								'0x2':['msm_fastrpc_compute_cb14'],
								'0x3':['msm_fastrpc_compute_cb15']
								},
					  'rennell':{
								'0x1':['msm_fastrpc_compute_cb13'],
								'0x2':['msm_fastrpc_compute_cb14'],
								'0x3':['msm_fastrpc_compute_cb15']
								},
					  '8250':{
								'0x1':['msm_fastrpc_compute_cb13'],
								'0x2':['msm_fastrpc_compute_cb14'],
								'0x3':['msm_fastrpc_compute_cb15']
							 },
					  'nicobar':{
								'0x1':['msm_fastrpc_compute_cb13'],
								'0x2':['msm_fastrpc_compute_cb14'],
								'0x3':['msm_fastrpc_compute_cb15']
								},
					  '7150':{},
					  '6150':{},
					  '855':{
							'0x1':['msm_fastrpc_compute_cb13'],
							'0x2':['msm_fastrpc_compute_cb14'],
							'0x3':['msm_fastrpc_compute_cb15']
								},
					  'lahaina':{
							'0x1':['msm_fastrpc_compute_cb13'],
							'0x2':['msm_fastrpc_compute_cb14'],
							'0x3':['msm_fastrpc_compute_cb15']
								},
					  'waipio':{
							'0x1':['msm_fastrpc_compute_cb13'],
							'0x2':['msm_fastrpc_compute_cb14'],
							'0x3':['msm_fastrpc_compute_cb15']
								},
					  '670':{},
					  '845':{},
					  '1000':{},
					  '660':{},
					  '8996':{
							'0x8':['msm_fastrpc_compute_cb1'],
							'0x9':['msm_fastrpc_compute_cb2'],
							'0xa':['msm_fastrpc_compute_cb3'],
							'0xb':['msm_fastrpc_compute_cb4'],
							'0xc':['msm_fastrpc_compute_cb5'],
							'0xd':['msm_fastrpc_compute_cb6'],
							'0xe':['msm_fastrpc_compute_cb7'],
							'0xf':['msm_fastrpc_compute_cb8'],
							 }
					 },
				'cdsp0':{
						'makena':{
							'0x1':['0x17030000','0x1f','STCU_CB40'],
							'0x2':['0x17030004','0x20','STCU_CB41'],
							'0x3':['0x17030008','0x21','STCU_CB42'],
							'0x4':['0x1703000c','0x22','STCU_CB43'],
							'0x5':['0x17030010','0x23','STCU_CB44'],
							'0x6':['0x17030014','0x24','STCU_CB45'],
							'0x7':['0x17030018','0x25','STCU_CB46'],
							'0x8':['0x1703001c','0x26','STCU_CB47'],
							'0xb':['0x17030020','0x27'],
							'0xc':['0x17030024','0x28'],
							'0xd':['0x17030028','0x29'],
							'0xe':['0x1703002c','0x2a'],
							'0xf':['0x17030030','0x2b']
							 }
					}
			 }

def create_smmutxt():
	arm_iommu_file_name_list = []
	for (dirpath, dirnames, filenames) in os.walk(input):
		for temp_file in filenames:
			if 'arm_iommu_domain' in temp_file: arm_iommu_file_name_list.append(temp_file)
		break
	f_smmutxt = open ('smmu.txt', 'w')
	for cnt in range(len(arm_iommu_file_name_list)):
		cnt1 = str("{0:0=2d}".format(cnt))
		smmu_files = 'msm_iommu_domain_'+cnt1+".txt"
		if not os.path.isfile(smmu_files):  
			smmu_files = 'arm_iommu_domain_'+cnt1+".txt"
		if os.path.isfile(smmu_files):
			f_smmuInputfile= open (smmu_files, 'r')
			first = 0
			for line_smmufile in f_smmuInputfile:
				if first == 0:
					if not "audio" in line_smmufile: break
				first = 1
				if (line_smmufile[0:2] == '0x'):
					if not (re.search('UNMAPPED',line_smmufile)): 
						f_smmutxt.write(line_smmufile)
			f_smmuInputfile.close()
	f_smmutxt.close()

def splitting_iommu_file():
	
	try:  ## Create a dictionary of all arm_iommu_domain files present inside temp folder
		# print ('\n*****************************')
		arm_iommu_file_splitted_dictionary = {}
		arm_iommu_file_dictionary_temp = {}
		arm_iommu_file_dictionary = {}
		arm_iommu_file_name_list = []
		for (dirpath, dirnames, filenames) in os.walk(input):
			for temp_file in filenames:
				if 'arm_iommu_domain' in temp_file: arm_iommu_file_name_list.append(temp_file)
			break
		print ('\nTotal Number of arm_iommu_domain file :',len(arm_iommu_file_name_list))
		print('\nTotal CB :',list(smmu_fastrpc_list.values()),'\n')
		total_number_of_iommu_file = len(arm_iommu_file_name_list)
		
		for temp_arm_file in arm_iommu_file_name_list:  # Create Dict. remove UNMAPPED line and line which donesnot have 0X.
			file_ptr = open(input+'\\'+temp_arm_file,'r')
			temp_line_list = file_ptr.readlines()
			for key, value in smmu_fastrpc_list.items():
				for context_bank in value:
					if context_bank in temp_line_list[0]:
						print (temp_arm_file,':',len(temp_line_list),':',context_bank)
						temp_line_list_temp = []
						for temp_line in temp_line_list:
							if (temp_line[0:2] != '0x') or 'UNMAPPED' in temp_line: continue
							if create_smmutxt_asid_flag:
								a0 = temp_line.split(' A:0x')[0]
								a1 = temp_line.split(' A:0x')[1].split('--')[0]
								a3 = temp_line.split(' A:0x')[1].split('--')[1]
								a2 = hex((int(a1,16)>>12)<<12).replace('L','')
								temp_line = a0+' A:'+a2+'--'+a3
							try:
								temp_pa = temp_line.split("A:")[1].split('--')[0]
								new_temp_pa = temp_pa[:-3]+'000'
								temp_line = temp_line.replace(temp_pa,new_temp_pa)
							except:
								print ("Error coming while removing last 3 digit")
								pass
							temp_line_list_temp.append(temp_line)
						if len(temp_line_list_temp)==0: continue
						if context_bank not in arm_iommu_file_dictionary.keys(): 
							arm_iommu_file_dictionary[context_bank] = []
							arm_iommu_file_dictionary[context_bank] = temp_line_list_temp
						else:
							arm_iommu_file_dictionary[context_bank] = arm_iommu_file_dictionary[context_bank]+temp_line_list_temp
						break
		print ('\nAvailable CB :',list(arm_iommu_file_dictionary.keys()),'\n')  # ['msm_fastrpc_compute_cb3[', 'msm_fastrpc_compute_cb2[', 'msm_fastrpc_compute_cb1[']
		
		for arm_iommu_file in arm_iommu_file_dictionary: # merging same interval block
			print (arm_iommu_file,':',len(arm_iommu_file_dictionary[arm_iommu_file]))
			temp_list = []
			# print (arm_iommu_file,':',len(arm_iommu_file_dictionary[arm_iommu_file]))
			# for temp_line in arm_iommu_file_dictionary[arm_iommu_file]:
				# print ('        ',temp_line.split('\n')[0])
				
			temp0 = "0"
			temp1 = "0"
			temp2 = 0
			temp3 = "0"
			temp4 = "0"
			temp5 = 0
			for line_dsppgt in arm_iommu_file_dictionary[arm_iommu_file]:
				if ( line_dsppgt[0:2] == '0x'):
					list_dsppgt = line_dsppgt.split(' ')
					t0 = list_dsppgt[0].split('--')[0]
					t1 = list_dsppgt[0].split('--')[1]
					t2 = list_dsppgt[1].split('[')[1].split(']')[0]
					t3 = list_dsppgt[2].split('A:')[1].split('--')[0]
					t4 = list_dsppgt[2].split('A:')[1].split('--')[1]
					t5 = list_dsppgt[3].split('[')[1].split(']')[0]
					if (int(temp1,16)+1==int(t0,16) and int(temp4,16)+1==int(t3,16)):
						temp1 = t1
						temp2 = temp2+int(t2,16)
						temp4 = t4
						temp5 = temp5 + int(t5,16)
					else:
						if temp0 != "0": temp_list.append(temp0+'--'+temp1+' ['+str(hex(temp2))+'] A:'+temp3+'--'+temp4+' ['+str(hex(temp5))+'] [R/W][4K]')
						temp0 = t0
						temp1 = t1
						temp2 = int(t2,16)
						temp3 = t3
						temp4 = t4
						temp5 = int(t5,16)
			if temp0 != "0": temp_list.append(temp0+'--'+temp1+' ['+str(hex(temp2))+'] A:'+temp3+'--'+temp4+' ['+str(hex(temp5))+'] [R/W][4K]')
			
			arm_iommu_file_dictionary_temp[arm_iommu_file] = []
			arm_iommu_file_dictionary_temp[arm_iommu_file] = temp_list
		
		arm_iommu_file_dictionary = {}
		arm_iommu_file_dictionary = arm_iommu_file_dictionary_temp
		print ("\nAfter Merging same interval Block Dict reduced to...")
		for arm_iommu_file in arm_iommu_file_dictionary:
			print (arm_iommu_file,':',len(arm_iommu_file_dictionary[arm_iommu_file]))
			temp_split_dict = {}
			for tmp_line in arm_iommu_file_dictionary[arm_iommu_file]:
				tmp_line=tmp_line.replace('0x0','0x')
				#print "*******vik*******"+tmp_line
				if not tmp_line[0:4] in temp_split_dict.keys():
					temp_split_dict[tmp_line[0:4]]=[]
					temp_split_dict[tmp_line[0:4]].append(tmp_line.split('\n')[0])
				else: temp_split_dict[tmp_line[0:4]].append(tmp_line.split('\n')[0])
			arm_iommu_file_splitted_dictionary[arm_iommu_file] = temp_split_dict
		print ('\nSpliting Dictionary into Sub dictionary as per ASID\n')
		# while True:
			# for key in arm_iommu_file_splitted_dictionary.keys():
				# print (key,':',arm_iommu_file_splitted_dictionary[key].keys())
				# print (key,':',len(arm_iommu_file_splitted_dictionary[key].keys()))
				# for temp_asid in arm_iommu_file_splitted_dictionary[key].keys():
					# print (temp_asid,':')
					# for temp_line in arm_iommu_file_splitted_dictionary[key][temp_asid]:
						# print ('      ',temp_line)
			# break
		print ('\nSplited context_bank successfully\n\n***************************\n')
		
		
		return arm_iommu_file_splitted_dictionary
	except:
		print ('Error arised during spltting context_bank')
		return {}
	
def map_smmu(vpage_address, ipage_address, size):

	def find_smmu(ipage_address):
		found_smmu=0
		smmu_vpage_address=0x0
		smmu_ppage_address=0x0
		smmu_size=0x0 
		f_smmu = open ('smmu.txt', 'r')  
		for line_smmu in f_smmu:
			list_smmu = re.split(']|0x| |--',line_smmu)  # 0x1ffaa000--0x1ffaafff [0x1000] A:0x1e2237000--0x1e2237fff [0x1000] [R/W][4K] [Non-Cached] [Outer-Shareable] [True]
			# print (list_smmu)  # ['', '1ffaa000', '', '1ffaafff', '[', '1000', '', 'A:', '1e2237000', '', '1e2237fff', '[', '1000', '', '[R/W', '[4K', '', '[Non-Cached', '', '[Outer-Shareable', '', '[True', '\n']
			smmu_vpage_address = int(list_smmu[1],16) # 1ffaa000
			smmu_ppage_address = int(list_smmu[8],16) # 1e2237000
			smmu_size = int(list_smmu[5],16)          # 1000
			found_smmu=0
			if (ipage_address >= smmu_vpage_address) and (ipage_address < (smmu_vpage_address+smmu_size)):
				found_smmu = 1
				break
				
		f_smmu.close()
		return (found_smmu, smmu_vpage_address, smmu_ppage_address, smmu_size)
	
	vpage_address_temp= vpage_address
	ipage_address_temp= ipage_address
	size_temp = size
	while(size_temp!= 0x0):
		found_smmu=0
		smmu_vpage_address=0x0
		smmu_ppage_address=0x0
		smmu_size=0x0 
		result_find_smmu= find_smmu(ipage_address_temp)
		found_smmu= result_find_smmu[0]
		smmu_vpage_address = result_find_smmu[1]
		smmu_ppage_address = result_find_smmu[2]
		smmu_size = result_find_smmu[3]
		
		if found_smmu:
			size3=  smmu_vpage_address+smmu_size- ipage_address_temp
			size1=  smmu_size - size3
			size2 = size_temp
			if (size3 <= size_temp): 
				size2 = size3 
			smmu_ppage_result_address = smmu_ppage_address + size1
			main_list_temp.append('mmu.create ' + hex(vpage_address_temp).rstrip('L') + '++' + hex(size2-1).rstrip('L')+' ' + hex(smmu_ppage_result_address).rstrip('L') + '++' + hex(size2-1).rstrip('L'))
			size_temp =  size_temp-size2
			#print ('size_temp'+ hex(size_temp)#)
			vpage_address_temp = vpage_address_temp+ size2
			ipage_address_temp = ipage_address_temp+ size2
		else:
			main_list_temp.append('mmu.create ' + hex(vpage_address_temp).rstrip('L') + '++' + hex(size_temp-1).rstrip('L')+' ' + hex(ipage_address_temp).rstrip('L') + '++' + hex(size_temp-1).rstrip('L'))
			size_temp=0x0
	
def map_smmu_asid(vpage_address,ipage_address,size,asid,splitted_address):
	
	def find_smmu_asid(ipage_address,asid,splitted_address):
		found_smmu=0
		smmu_vpage_address=0x0
		smmu_ppage_address=0x0
		smmu_size=0x0 
		for item in smmu_fastrpc_list[asid]:
			if item in splitted_arm_iommu_file_dict.keys():
				break
		try:
			for line_smmu in splitted_arm_iommu_file_dict[item][splitted_address.lower()]:
				list_smmu = re.split(']|0x| |--',line_smmu)
				if (key=="slpi"): smmu_vpage_address = int(list_smmu[1],16)%4294967296
				else: smmu_vpage_address = int(list_smmu[1],16)            
				smmu_ppage_address = int(list_smmu[8],16)
				smmu_size = int(list_smmu[5],16)
				found_smmu=0
				if (ipage_address >= smmu_vpage_address) and (ipage_address < (smmu_vpage_address+smmu_size)): 
					found_smmu = 1
					break
		except:
			return (found_smmu, smmu_vpage_address, smmu_ppage_address, smmu_size)
		return (found_smmu, smmu_vpage_address, smmu_ppage_address, smmu_size)

	vpage_address_temp= vpage_address
	ipage_address_temp= ipage_address
	size_temp = size
	var_cnt_temp = 1
	while(size_temp!= 0x0):
		found_smmu=0
		smmu_vpage_address=0x0
		smmu_ppage_address=0x0
		smmu_size=0x0 
		result_find_smmu= find_smmu_asid(ipage_address_temp,asid,splitted_address)
		found_smmu= result_find_smmu[0]
		smmu_vpage_address = result_find_smmu[1]
		smmu_ppage_address = result_find_smmu[2]
		smmu_size = result_find_smmu[3]
		# print ('              ',smmu_vpage_address,':',smmu_ppage_address,':',smmu_size)
		# print ('              ',hex(smmu_vpage_address).rstrip('L'),':',hex(smmu_ppage_address).rstrip('L'),':',hex(smmu_size).rstrip('L'))
		# sys.exit()
		if found_smmu:
			size3=  smmu_vpage_address+smmu_size- ipage_address_temp
			size1=  smmu_size - size3
			size2 = size_temp
			if (size3 <= size_temp): 
				size2 = size3 
			smmu_ppage_result_address = smmu_ppage_address + size1
			main_list_temp.append('mmu.create ' + hex(vpage_address_temp).rstrip('L') + '++' + hex(size2-1).rstrip('L')+' ' + hex(smmu_ppage_result_address).rstrip('L') + '++' + hex(size2-1).rstrip('L'))
			# print ('      ',var_cnt_temp,' : found','mmu.create ' + hex(vpage_address_temp).rstrip('L') + '++' + hex(size2-1).rstrip('L')+' ' + hex(smmu_ppage_result_address).rstrip('L') + '++' + hex(size2-1).rstrip('L'))
			size_temp =  size_temp-size2
			#print ('size_temp'+ hex(size_temp)#)
			vpage_address_temp = vpage_address_temp+ size2
			ipage_address_temp = ipage_address_temp+ size2
		else:
			main_list_temp.append('mmu.create ' + hex(vpage_address_temp).rstrip('L') + '++' + hex(size_temp-1).rstrip('L')+' ' + hex(ipage_address_temp).rstrip('L') + '++' + hex(size_temp-1).rstrip('L'))
			# print ( '      ',var_cnt_temp,' : Not found','mmu.create ' + hex(vpage_address_temp).rstrip('L') + '++' + hex(size_temp-1).rstrip('L')+' ' + hex(ipage_address_temp).rstrip('L') + '++' + hex(size_temp-1).rstrip('L'))
			size_temp=0x0
		var_cnt_temp += 1
	
def main():
	
	f_dsppgt= open (pgt_filename, 'r')   # 6GB_BasicMapping.txt/6GB_NonBasicMapping.txt
	non_basic_file_line_list = f_dsppgt.readlines()
	for cnt_temp in range(0,len(non_basic_file_line_list)):
		# if cnt_temp==5:break
		line_dsppgt = non_basic_file_line_list[cnt_temp]  ## 0xFE000  *0x089700 *0x100000 *  -  -  - *G  -        *Cacheable, write-back, non-shared, L2-cacheable*C00FE000 07112E10     *00000001
		if ( line_dsppgt[0:2] == '0x'):
			# print ('\n',line_dsppgt.split('\n')[0])
			list_dsppgt = line_dsppgt.split()
			asid = None
			if len(list_dsppgt[1]) > 8:
				asid = str(list_dsppgt[1][1:4])
				list_dsppgt[1] = list_dsppgt[1].replace('*','')
				list_dsppgt[1] = '0x'+list_dsppgt[1][3:]
			vpage_address = (int(list_dsppgt[0].replace('*',''),16))* 0x1000
			ipage_address= int(list_dsppgt[1].replace('*',''),16) * 0x1000
			size= int(list_dsppgt[2].replace('*',''),16)
			# print (cnt_temp)
			# print ('              ',list_dsppgt[0],':',list_dsppgt[1],':',list_dsppgt[2],':',list_dsppgt[1][:4])  ##   0xFE000    : 0x89700    : *0x100000 : 0x89
			# print ('              ',vpage_address,':',ipage_address,':',size,':',asid,':',list_dsppgt[1][:4])     ## 0 4261412864 : 2305818624 : 1048576 : 0x0 : 0x89
			if asid == None or asid == '0x0':
				map_smmu(vpage_address, ipage_address, size)
			else:
				map_smmu_asid(vpage_address,ipage_address,size,asid,list_dsppgt[1][:4])
			
	# main_list_temp.append('mmu.format QURT QURTK_pagetables')
	main_list_temp.append('mmu.on')
	main_list_temp.append('mmu.autoscan on')
	main_list_temp.append('mmu.tablewalk on')
	# print (len(main_list_temp))
	outfile = open(smmu_filename, 'w')  # DSP_smmu_pagetables_basic.cmm / DSP_smmu_pagetables_nonbasic.cmm
	outfile.write("\n".join(main_list_temp))
	outfile.close()

if __name__ == '__main__':

	smmu_fastrpc_list = smmu_fastrpc_list_initialize[key][target_id]

	create_smmutxt_asid_target_list = ['8250','saipan','rennell']
	create_smmutxt_asid_flag = False
	if target_id in create_smmutxt_asid_target_list: create_smmutxt_asid_flag = True
	smmu_fastrpc_file_flag = False
	if new_target_flag=='False' or target_id == '660': smmu_fastrpc_file_flag = True
	if new_target_flag == 'False' or target_id=='405': target_id = '8996'

	print (datetime.datetime.now())
	main_list_temp = []
	###################
	# 6GB_BasicMapping.txt -> files which contain "msm-audio-ion" keyword -> smmu.txt
	###################
	if pgt_filename == "6GB_BasicMapping.txt": create_smmutxt()
	###################
	# splitted_arm_iommu_file_dict = 
	###################
	if pgt_filename == "6GB_NonBasicMapping.txt": splitted_arm_iommu_file_dict = splitting_iommu_file() 
	main() # IP:6GB_BasicMapping.txt/6GB_NonBasicMapping.txt && OP : DSP_smmu_pagetables_basic.cmm / DSP_smmu_pagetables_nonbasic.cmm
	print (datetime.datetime.now())

os.chdir(current_path)
