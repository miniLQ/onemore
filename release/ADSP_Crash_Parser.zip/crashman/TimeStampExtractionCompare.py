import sys
import re
import os

crashman_asha_flag = False
subsystemp_type = 'adsp|slpi|cdsp'
# subsystemp_type = 'adsp|cdsp'

timestamp_output_list = []
keyword = 'OEM_IMAGE_UUID_STRING=Q_SENTINEL_{'
def Get_TimeStamp(filename, subsystemp_type, crashman_asha_flag):
	image_variant = ""
	try:
		detected_subsystem = ''
		print ('\nChecking into '+filename)
		timestamp_output_list.append('\nChecking into '+filename+'\n')
		with open(filename, 'rb') as readfile:
			for line in readfile:
				line = line.decode(errors='ignore')
				if re.match('.*OEM_IMAGE_UUID_STRING=Q_SENTINEL_{.*',line):
					matchObj1 = re.match('.*QC_IMAGE_VERSION_STRING=((?:'+subsystemp_type+'))',line, re.IGNORECASE)  ## Filter : Based on Processor Type
					matchObj2 = re.match('.*IMAGE_VARIANT_STRING=[0-9a-z]+.((?:'+subsystemp_type+'))',line, re.IGNORECASE)
					# matchObj = re.match('.*IMAGE_VARIANT_STRING=([0-9a-zA-Z]+).(?:'+subsystemp_type+')',line, re.IGNORECASE)
					matchObj= False
					if matchObj1: matchObj = matchObj1
					if matchObj2: matchObj = matchObj2
					if matchObj:
						# if detected_subsystem == subsystemp_type: break # if all requested subsystem timestamp detected then come out from loop
						if matchObj.group(1).lower() in detected_subsystem: continue  # if a subsystem timestamp already detected then keep it continue
						if detected_subsystem=='' :detected_subsystem = matchObj.group(1).lower()
						else: detected_subsystem += '|' + matchObj.group(1).lower()
						
						for word in line.split('\x00'):
							if 'IMAGE_VARIANT_STRING' in word: 
								print ('    '+word)
								image_variant = word.split('=')[1].strip()
								timestamp_output_list.append('    '+word+'\n')
								if 'AAAAAAAAQ' not in word:
									print ('    TARGETID = '+word.split('=')[1].split('.')[0])
									timestamp_output_list.append('    TARGETID = '+word.split('=')[1].split('.')[0]+'\n')
							if 'QC_IMAGE_VERSION_STRING' in word or 'OEM_IMAGE_VERSION_STRING' in word: 
								print('    '+word.strip())
								timestamp_output_list.append('    '+word.strip()+'\n')
							if 'OEM_IMAGE_UUID_STRING=Q_SENTINEL_{' in word: 
								print ('    '+word+'\n')
								timestamp_output_list.append('    '+word+'\n')
								timestamp = word
						if crashman_asha_flag : return timestamp.split("}_")[1], True,image_variant
						if detected_subsystem == subsystemp_type: break # if all requested subsystem timestamp detected then come out from loop
	except:
		err_msg = "Error arised while extracting timestamp from "+filename
		print ("\n"+err_msg)
		timestamp_output_list.append(err_msg+'\n')
		return err_msg,False,image_variant
		
	err_msg = "Timestamps not detected from "+filename
	print ("\n"+err_msg)
	timestamp_output_list.append(err_msg+'\n')
	return err_msg,False,image_variant

				#print(timestamp_output_list)

								
								
							





#ukernel elf processing
def getUkernelTimeStamp(file):

	try:
		_bin = open(file,'rb') 
	except:
		print("File opening failed")
		return ""
	
	for line in _bin:
		decoded_string = line.decode('ascii',errors='ignore')
		if "QURT Kernel ver" in decoded_string:
			#print(decoded_string)
			pattern_date_time = '(QURT\sKernel\sver.:.*[0-9]{2}:[0-9]{2}:[0-9]{2})'
			#print(decoded_string)
			x = re.findall(pattern_date_time,decoded_string)
			#print(x)
			temp = x[0].split('\x00\x00')
			timestamp = temp[len(temp)-1]
			return timestamp
	return ""
def getUserElfTimeStamp(file,OpPath=None):
	try:
		_bin = open(file,'rb') 
	except:
		print("File opening failed")
		return
	time_stamps = []
	for line in _bin:
		decoded_string = line.decode('ascii',errors='ignore')
		if "OEM_IMAGE_UUID_STRING=Q_SENTINEL_{" in decoded_string:
			pattern = 'OEM_IMAGE_UUID_STRING=Q_SENTINEL_{.*}_[0-9]{8}_[0-9]{4}'
			timestamp = re.findall(pattern,decoded_string)
			time_stamps.append(timestamp[0])
	return time_stamps
	
def pd_dump_tmstamp_handling(dumppath, elfpath, OpPath, subsystemp_type,pd):
	elf_time_stamps = getUserElfTimeStamp(elfpath,OpPath)
	dump_time_stamps = getUserElfTimeStamp(dumppath,OpPath)
	OpFile5 = OpPath+ r'/temp/list_of_elf_file_need_to_load.txt'
	timestmp_match = False
	for elf_tmstmp in elf_time_stamps:
		for dump_tmstmp in dump_time_stamps:
			if elf_tmstmp == dump_tmstmp:
				timestmp_match = True
				_file = open(OpPath+"/temp/userpd_tstmp.txt","w")
				_file.write("1\n")
				_file.write("ELF Timestamp : "+elf_tmstmp+"\n")
				_file.write("DUMP Timestamp : "+dump_tmstmp+"\n")
				_file.close()
				return
	try:
		original_elf_timestamp = elf_time_stamps[0]
	except:
		original_elf_timestamp = ""
	if "audio" in pd.lower():
		pd = "AUDIO"
	elif "sensor" in pd.lower():
		pd = "SENSOR"
	print ('\nTimestamps or image variant are not matching with above ELF. Checking into other ELF.')
	dump_timestamp, dump_check_flag,dump_image_variant = Get_TimeStamp(dumppath,subsystemp_type,True)
	if "adsp" in  timestamp_output_list[3] or "cdsp" in  timestamp_output_list[3] or "slpi" in timestamp_output_list[3]:
		elf_varient = timestamp_output_list[3].split()[0].split('.')[-1]
		if "prodQ" in elf_varient:
			elf_varient = "prodQ"
		elif "prod2Q" in elf_varient:
			elf_varient = "prod2Q"
		elif "coreQ" in elf_varient:
			elf_varient = "coreQ"
		new_target_id = timestamp_output_list[4].split()[-1]
		new_subsystem = timestamp_output_list[3].split()[0].split('.')[-2]
		new_elf = os.path.dirname(elfpath)+ r'/'+pd+'_'+new_target_id+'.'+new_subsystem+'.'+elf_varient+'.elf'
		if subsystemp_type not in new_subsystem: #for comparision in case cdsp and cdsp0
			new_elf = os.path.dirname(elfpath)+ r'/'+pd+'_'+new_target_id+'.'+new_subsystem+'.'+elf_varient+'.elf'
		if os.path.exists(new_elf):
			elf_time_stamps = getUserElfTimeStamp(new_elf,OpPath)
		for elf_tmstmp in elf_time_stamps:
			for dump_tmstmp in dump_time_stamps:
				if elf_tmstmp == dump_tmstmp:
					timestmp_match = True
					_file = open(OpPath+"/temp/userpd_tstmp.txt","w")
					_file.write("1\n")
					_file.write("ELF Timestamp : "+elf_tmstmp+"\n")
					_file.write("DUMP Timestamp : "+dump_tmstmp+"\n")
					_file.close()
					f_out = open(OpFile5,"w")
					f_out.write(new_elf)
					return
	if timestmp_match == False:
		_file = open(OpPath+"/temp/userpd_tstmp.txt","w")
		_file.write("0\n")
		if len(elf_time_stamps)>0:
			_file.write("ELF Timestamp : "+original_elf_timestamp+"\n")
		else:
			_file.write("ELF Timestamp : \n")
		if len(dump_time_stamps)>0:
			_file.write("DUMP Timestamp : "+dump_time_stamps[0]+"\n")
		else:
			_file.write("DUMP Timestamp : \n")
		_file.close()
if __name__=="__main__":
	crashman_asha_flag = True
	dumpath, elfpath, OpPath, subsystemp_type = sys.argv[1],sys.argv[2],sys.argv[3],sys.argv[4].lower()
	is_pd_dump = False
	if "pddump" in str(sys.argv):
		pd_dump_tmstamp_handling(dumpath, elfpath, OpPath, subsystemp_type,sys.argv[5])
		sys.exit()
	OpFile1 = OpPath+ r'/TimestampExtractedData.txt'
	OpFile2 = OpPath+ r'/TimestampResult.txt'
	OpFile3 = OpPath+ r'/TimestampNewELFFile.txt'
	OpFile4 = OpPath+ r'/asha_logs.txt'
	OpFile5 = OpPath+ r'/list_of_elf_file_need_to_load.txt'
	if True: #ROOT timestamp comparison
		if crashman_asha_flag:
			dump_timestamp, dump_check_flag,dump_image_variant = Get_TimeStamp(dumpath,subsystemp_type,crashman_asha_flag)
			elf_timestamp, elf_check_flag,elf_image_variant = Get_TimeStamp(elfpath,subsystemp_type,crashman_asha_flag)
			with open(OpFile2, 'w') as fileptr:
				if dump_check_flag and elf_check_flag:  ## if Timestamps are detected from Dump and ELF
					if dump_timestamp == elf_timestamp and dump_image_variant==elf_image_variant: ## if Timestamps are Matching and image_variant are matching
						fileptr.write('1'+'\n')
						fileptr.write("DumpTimestamp : "+dump_timestamp+' && ELFTimestamp : '+elf_timestamp+"\n")
						fileptr.write("DumpImageVariant : "+dump_image_variant+" && ELFImageVariant: "+elf_image_variant)
						print ("Timestamps and Image variant are matching")
						timestamp_output_list.append("Timestamps and Image variant are matching")
					else:  ## if timestamps are not matching. Checking for other ELF file.
						print ('\nTimestamps or image variant are not matching with above ELF. Checking into other ELF.')
						timestamp_output_list.append('\nTimestamps or image variant are not matching with above ELF. Checking for other ELF.')
						find_flag = False
						if "adsp" in  timestamp_output_list[2] or "cdsp" in  timestamp_output_list[2] or "slpi" in timestamp_output_list[2]:
							elf_varient = timestamp_output_list[2].split()[0].split('.')[-1]
							new_target_id = timestamp_output_list[3].split()[-1]
							new_subsystem = timestamp_output_list[2].split()[0].split('.')[-2]
							new_elf = os.path.dirname(elfpath)+ r'/ROOT_'+new_target_id+'.'+new_subsystem+'.'+elf_varient+'.elf'
							if subsystemp_type not in new_subsystem: #for comparision in case cdsp and cdsp0
								new_elf = os.path.dirname(elfpath)+ r'/ROOT_'+new_target_id+'.'+new_subsystem+'.'+elf_varient+'.elf'
							if os.path.exists(new_elf) and new_elf!=elfpath: ## check for timestamp of new_elf only if image variant found in dump was different than the passed elf
								elf_timestamp, elf_check_flag,elf_image_variant = Get_TimeStamp(new_elf,subsystemp_type,crashman_asha_flag)
								if elf_check_flag:
									if dump_timestamp == elf_timestamp and dump_image_variant==elf_image_variant:
										fileptr.write('1'+'\n')
										fileptr.write("DumpTimestamp : "+dump_timestamp+' && ELFTimestamp : '+elf_timestamp+"\n")
										fileptr.write("DumpImageVariant : "+dump_image_variant+" && ELFImageVariant: "+elf_image_variant)
										print ("Timestamps and image variant are matching")
										timestamp_output_list.append("Timestamps and image variant are matching")
										find_flag = True
										with open(OpFile3, 'w') as fileptr3:  ## ASHA
											fileptr3.write(new_elf+'\n')
											fileptr3.write(new_target_id+'\n')
											fileptr3.write(elf_varient+'\n')
											fileptr3.write(subsystemp_type+'\n')
										if os.path.isfile(OpFile5):
											with open(OpFile5, 'r') as fileptr:
												linelist = fileptr.readlines()
												elfpath = os.path.dirname(linelist[0])
												linelist = [os.path.basename(line).split('.') for line in linelist]
												for cnt in range(len(linelist)): linelist[cnt][2] = elf_varient
												if new_subsystem != subsystemp_type:
													for cnt in range(len(linelist)): linelist[cnt][1] = new_subsystem
												linelist = [elfpath+'/'+'.'.join(sublist)  for sublist in linelist]
											f_out = open(OpFile5,"w")
											for temp_elf in linelist: 
												if os.path.exists(temp_elf.split('\n')[0]):
													f_out.write(temp_elf)
											f_out.close()
						if not find_flag:
							fileptr.write('0'+'\n')
							fileptr.write("Time stamp or ImageVariant in dump and elf file not matching\n")
							fileptr.write("DumpTimestamp : "+dump_timestamp+' && ELFTimestamp : '+elf_timestamp+"\n")
							fileptr.write("DumpImageVariant : "+dump_image_variant+" && ELFImageVariant: "+elf_image_variant+'\n')
							fileptr.write('Please check Logs from '+OpFile1+' file.')
							print ("Time Stamp or image variant in Dumps and ELF File are not Matching ->  DumpTimestamp : "+dump_timestamp+' && ELFTimestamp : '+elf_timestamp+"\n"+"DumpImageVariant : "+dump_image_variant+" && ELFImageVariant: "+elf_image_variant)
				else:  ## if not able to detect timestamp from Dump or ELF file
					fileptr.write('0'+'\n')
					fileptr.write("Time stamp or image variant dection failed\n")
					fileptr.write("DumpTimestamp : "+dump_timestamp+' && ELFTimestamp : '+elf_timestamp+"\n")
					fileptr.write("DumpImageVariant : "+dump_image_variant+" && ELFImageVariant: "+elf_image_variant+'\n')
					fileptr.write('Please check Logs from '+OpFile1+' file.')
			with open(OpFile1, 'w') as fileptr1:  ## Write Complete logs list into .txt file
				fileptr1.write("".join(timestamp_output_list))
			if os.path.isfile(OpFile4):  ## Write complete logs into ASHA_log.txt file
				with open(OpFile4, 'a') as fileptr1: 
					fileptr1.write("".join(timestamp_output_list))
		else:
			for cnt in range(1,len(sys.argv)):
				Get_TimeStamp(sys.argv[cnt],subsystemp_type,crashman_asha_flag)
	if True: #Ukernel timestamp comparison
		_f = open(OpPath+"/list_of_elf_file_need_to_load.txt",'r')
		elfpath = _f.readline()
		while "ukernel" not in elfpath.lower() and elfpath!="":
			elfpath = _f.readline()
		_f.close()
		print(elfpath)
		tstmp_dump = getUkernelTimeStamp(dumpath)
		tstmp_elf = getUkernelTimeStamp(elfpath.strip())
		_file = open(OpPath+"/ukernel_tstmp.txt","w")
		_file.write(tstmp_dump+"\n")
		_file.write(tstmp_elf)
		_file.close()
