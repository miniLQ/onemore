# ------------------------------------------------------------------
#
# Copyright (c) 2019-2020 Qualcomm Technologies, Inc.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
# ------------------------------------------------------------------

import os
import re
import sys

#OutputPath="C:/Temp/try/"
OutputPath1=sys.argv[1]
OutputPath=OutputPath1+"/temp/"
str_sch = "-000\*"
for csno in range(1,1000):
    str_sch = str_sch+'|'+'-'+"{0:0=3d}".format(csno)+"\*"


def update_callstack(filename):

    if os.path.exists(filename):
        sum = OutputPath1+"/"+"All_HWT_callstack.txt"
        f_sum = open(sum,'a+')
        f_qt = open(filename, 'r+')
        f_sum.write("\nRunning CallStack for thread-" + str(hw_thread)+'\n')
        f_sum.write("=========================\n")
        for line in f_qt:
            if not "B::" in line: 
                if "****end of frame" in line:
                    f_sum.write("----|end of frame\n\n")
                    #UpdateDDField(OutputPath,DDField1)
                    break;
                y = re.search(str_sch,line)
                if y:
                    cs = re.split('\(',str(line))[0]
                    cs = cs.replace('*', '|')
                    f_sum.write(cs+"()\n")
        f_qt.close()
        f_sum.close()

def update_heapstat(filename,keyword):

    if os.path.exists(filename):
        sum = OutputPath1+"/"+"All_HWT_callstack.txt"
        f_sum = open(sum,'a+')
        f_qt = open(filename, 'r+')
        f_sum.write("Heap stat for - "+keyword+':\n')
        f_sum.write("----------------------\n")
        for line in f_qt:
            f_sum.write(line)
        f_sum.write('\n\n')
        f_sum.close()

for hw_thread in range(0,4):
    DSP_QT = OutputPath+"thread"+str(hw_thread)+"_callstack.txt"
    #print (DSP_QT)
    update_callstack(DSP_QT)

update_heapstat(OutputPath1+"/Def_Heap/Heap_stat.txt", "Default Heap")
update_heapstat(OutputPath1+"/Qurt_logs/qurtos_heap_stat.txt", "Qurtos Heap")
update_heapstat(OutputPath1+"/Def_Heap_forSensors_img/Heap_stat.txt", "Default Heap for Sensor image")
update_heapstat(OutputPath1+"/Def_Heap_for_AUDIO_img/Heap_stat.txt", "Default Heap for Audio image")

