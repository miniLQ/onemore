# ------------------------------------------------------------------
#
# Copyright (c) 2019-2020 Qualcomm Technologies, Inc.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
# ------------------------------------------------------------------

import os
import sys
import re

try:
	OutputPath_temp  = sys.argv[1]
	qurt_file = OutputPath_temp.split('temp')[0]+'Qurt_logs/dsp_QT.txt'
	qt_file_line_list = []
	if os.path.exists(qurt_file): 
		file_ptr = open(qurt_file,'r')
		line_list = file_ptr.readlines()
		task_dict = {}
		for cnt in range(2,len(line_list)):
			if line_list[cnt].split(' ')[0].strip() == '': continue
			qt_file_line_list.append(line_list[cnt])
	file_paths = OutputPath_temp+'/thread_callstack'
	var_cnt = 0
	f_cmm = open(OutputPath_temp+"/all_thread_callstack.txt",'w+')
	filelist = []
	for r,d,f in os.walk(file_paths, topdown=True):
		for file in f:
			if re.match("thread.*_callstack.txt",file):
				filelist.append(file)
	filelist.sort()
	#filelist = filelist[1:]
	for file in filelist:
		if True:
			# for r,d,f in os.walk(file_paths, topdown=True):
			# for file in f:
			if 'collect_thread_callstack' in file: continue
			file_ptr = open(os.path.join(file_paths,file),'r')
			line_list = file_ptr.readlines()
			if '000' in file or '001' in file or '002' in file or '003' in file:
				for cnt in range(len(line_list)):
					if 'end of frame' in line_list[cnt]: break
					temp_line = line_list[cnt].replace('*','').strip()
					if temp_line == '': continue
					if 'B::v.f' in line_list[cnt] and 'task' in line_list[cnt]:
						try:
							# print (line_list[cnt].split('\n')[0]+' : '+ task_dict[line_list[cnt].split('\n')[0].split('task')[1].strip().split('0x')[1]])
							f_cmm.write(line_list[cnt].split('\n')[0]+' : '+ task_dict[line_list[cnt].split('\n')[0].split('task')[1].strip().split('0x')[1]]+'\n')
						except:
							# print (line_list[cnt].split('\n')[0])
							f_cmm.write(line_list[cnt].split('\n')[0]+'\n')
					else:
						# print (line_list[cnt].split('\n')[0])
						f_cmm.write(line_list[cnt].split('\n')[0]+'\n')
				# print ('\n********************************************************\n')
				f_cmm.write('\n********************************************************\n\n')
				continue
			# print (var_cnt,':',qt_file_line_list[var_cnt])
			f_cmm.write(str(var_cnt)+':'+qt_file_line_list[var_cnt]+'\n')
			for temp_line in line_list:
				if ('B::Area q6_sw' in temp_line or temp_line=='\n'): continue 
				# print (temp_line.split('\n')[0])
				f_cmm.write(temp_line.split('\n')[0]+'\n')
			# print ('\n********************************************************\n')
			f_cmm.write('\n********************************************************\n\n')
			var_cnt += 1
except:
	print ('Error arised')
