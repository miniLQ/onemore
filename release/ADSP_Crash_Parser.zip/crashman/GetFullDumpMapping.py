from __future__ import print_function
import os
import sys
import glob
import time, datetime
import re
import json
from collections import OrderedDict
# from Variable_Initialization import SID_TO_CB_MAPPING
from ADSP_SMMU_Optimized_6GB import smmu_fastrpc_list_initialize
SID_TO_CB_MAPPING = smmu_fastrpc_list_initialize
non_basic_aperture_maps = []
aperture_addr = '0x10000000'
non_basic_maps = []
basic_maps = []
Total_Dump_size = '0x0'
DumpFilesStartAddressDict = {}
DumpFilesStartAddress_Ordered_Dict = OrderedDict()
_log = []
sid_list = []
skipped_SIDs = []
starttime = time.time()
CURRENT_PATH = ""
DUMP_PATH = ""
TARGET_ID = ""
SUBSYSTEM = ""
CLARA_OP = ""
SMMU_OP = ""
Enable_6GB_dumps = ""
addr_sepr_enable = ""
PARSER_TYPE = ""
thresold_mapping_count = 1000
dsp_tlb_info = {}
apps_tlb_info = {}
total_maps = {}
_log_level = 2
total_bin = {"before":'0x0',"after":'0x0',"apps_non_basic":'0x0',"non_basic":'0x0'}

def _hex_sum(hex1, hex2): #hex1 and hex2 are hexadecimal strings
    return hex(int(hex1,16)+int(hex2,16))
def _int(hex0): #hex string
    return int(hex0,16)
def _hex(hex0):
    return hex(_int(hex0))

def _hex_diff(hex1, hex2): #hex1 and hex2 are hexadecimal strings
    return hex(int(hex2,16)-int(hex1,16))
def handle_dsp_tlbs():
    tlb_info ={}#dictionary of type dict{ asid: { sid: []}}
    global sid_list
    global total_bin
    with open(CURRENT_PATH + r'\tlb.txt', 'r') as fileptr:
        for eachline in fileptr:
            try:
                va,ipa,asid,size = eachline.split()
                asid = hex(int(asid))
                pa,sid = hex(int(ipa,16)&0xFFFFFFFF)[2:],hex((int(ipa,16)&0xF00000000)>>32)[2:]
                sid_list.append(hex(int(sid,16)))
                if asid not in tlb_info.keys():
                    tlb_info[asid] = {}
                if sid not in tlb_info[asid].keys():
                    tlb_info[asid][sid]={'PA':[],'VA':[],'SIZE':[]}
                tlb_info[asid][sid]['PA'].append(pa)
                tlb_info[asid][sid]['VA'].append(va)
                tlb_info[asid][sid]['SIZE'].append(size)
                total_bin["before"]=_hex_sum(total_bin["before"],size)
            except:
                pass
    if _log_level >=2: print_msg("\nDSP Mappings:",1)
    tlb_info_clubbed ={}
    for asid,sid_maps in tlb_info.items():
        if asid not in tlb_info_clubbed.keys():
            tlb_info_clubbed[asid]={}
        for sid,tlb_maps in sid_maps.items():
            if sid not in tlb_info_clubbed[asid].keys():
                tlb_info_clubbed[asid][sid]={'PA':[],'VA':[],'SIZE':[]}
            _size_before = len(tlb_maps['VA'])
            _sorted_va,_sorted_pa,_sorted_sizes = sort_tlbs(tlb_maps['VA'],tlb_maps['PA'],tlb_maps['SIZE'])
            tlb_info_clubbed[asid][sid]['VA'],tlb_info_clubbed[asid][sid]['PA'],tlb_info_clubbed[asid][sid]['SIZE'] = club_tlbs_internal(_sorted_va,_sorted_pa,_sorted_sizes)
            _size_after = len(tlb_info_clubbed[asid][sid]['VA'])
            if _log_level >=2: print_msg("ASID: "+str(asid)+" -> SID: "+str(sid)+ " Before: "+str(_size_before)+" After: "+str(_size_after),1)
    sid_list = list(set(sid_list))
    return tlb_info_clubbed
def check_trace_version():
    if os.path.isfile(CURRENT_PATH+'/version_check.txt'):
        with open(CURRENT_PATH+'/version_check.txt', 'r') as _f:
            temp = _f.readline()
            print("temp:"+temp)
            while("Trace" not in temp and temp!=""):
                temp = _f.readline()
                print(temp)
            year = temp.split('.')[1]
            if(int(year)<2021):
                with open(CURRENT_PATH+'/T32_version.txt', 'w') as _log:
                    _log.write("36-bit dump loading not supported in "+temp)
                    _log.write("Latest T32 QIPL: "+r'\\hydmmdbld08\Jira_Automation_Tool\Crashman_script\Crashman_User\LT210824_138680'+"\n")
                    _log.write("Latest T32 SD: "+r'\\batman\qdsp6_sw_release\TRACE32\Run\LT210824_138680'+"\n")
                    _log.write("Usage: -use_t32 <t32_path>\n")
                    sys.exit()

def club_tlbs_internal(virtual_addlist,physical_addlist,block_sizelist):  # Combine Continues Blocks to Single Block
    if len(virtual_addlist)==0 or len(physical_addlist)==0 or len(block_sizelist)==0:
        return [[],[],[]]
    combined_virtual_addlist, combined_physical_addlist, combined_block_sizelist = [[virtual_addlist[0]],[physical_addlist[0]], [block_sizelist[0]]]
    for index in range(1, len(physical_addlist)):
        if hex(int(combined_physical_addlist[-1],16)+int(combined_block_sizelist[-1],16)) == hex(int(physical_addlist[index],16)) and \
                hex(int(combined_virtual_addlist[-1],16)+int(combined_block_sizelist[-1],16)) == hex(int(virtual_addlist[index],16)) :
            combined_block_sizelist[-1] = hex(int(combined_block_sizelist[-1],16) + int(block_sizelist[index],16))[2:]
        else:
            combined_virtual_addlist.append(virtual_addlist[index])
            combined_physical_addlist.append(physical_addlist[index])
            combined_block_sizelist.append(block_sizelist[index])
    return combined_virtual_addlist, combined_physical_addlist, combined_block_sizelist
def sort_tlbs(va,pa,size): #sorted based on vas, return lists of va's,pa's,size's sorted according to va's
    temp = {}
    for i in range(0,len(va)):
        temp[va[i]]=i
    sorted_vas = []
    sorted_pas = []
    sorted_sizes = []
    for key in sorted(temp.keys()):
        sorted_vas.append(key)
        sorted_pas.append(pa[temp[key]])
        sorted_sizes.append(size[temp[key]])
    return sorted_vas,sorted_pas,sorted_sizes
def get_apps_pgt_info(*argv):
    filename = argv[0]
    check_flag = argv[1]
    with open(filename, 'r') as fileptr:
        file_all_line_list = fileptr.readlines()
    if check_flag == 'clara':
        file_all_line_list = [line for line in file_all_line_list if '| VA: ' in line]
        virtual_addlist = [hex(_int(line.split('| ')[1].split(' ')[1])&0xFFFFFF000) for line in file_all_line_list]
        physical_addlist = [hex(_int(line.split('| ')[2].split(' ')[1])&0xFFFFFF000) for line in file_all_line_list]
        block_sizelist = [hex(_int(line.split('| ')[4].strip())&0xFFFFFF000) for line in file_all_line_list]
    elif check_flag == 'smmu':
        file_all_line_list = [line for line in file_all_line_list if line[:2] == '0x' and not 'UNMAPPED' in line]
        virtual_addlist = [hex(_int(line.split('--')[0])&0xFFFFFF000) for line in file_all_line_list]
        physical_addlist = [hex(_int(line.split('--')[1].split('A:')[1])&0xFFFFFF000) for line in file_all_line_list]
        block_sizelist = [hex(_int(line.split('--')[1].split('[')[1].split(']')[0])&0xFFFFFF000) for line in file_all_line_list]
    combined_virtual_addlist, combined_physical_addlist, combined_block_sizelist = club_tlbs_internal(virtual_addlist,physical_addlist,block_sizelist)
    if _log_level>=2: print_msg(' '+os.path.basename(filename)+' -> Total Mapping : '+str(len(virtual_addlist))+' ->'+str(len(combined_virtual_addlist)), 3)
    return combined_virtual_addlist, combined_physical_addlist, combined_block_sizelist
def handle_apps_tlbs():
    global skipped_SIDs
    tlb_info = {key: {} for key in sid_list}
    if _log_level >=2: print_msg("\nAPPS mappings:")
    for sid in sorted(sid_list):
        if sid == "0x0":
            continue
        respective_file = detect_file(sid,PARSER_TYPE)
        if respective_file != 'NA':
            tlb_info[sid]['VA'], tlb_info[sid]['PA'],\
                tlb_info[sid]['SIZE'], = get_apps_pgt_info(respective_file, PARSER_TYPE)
        else:
            if _log_level>=2: print_msg(" Couldn't find apps pgts", 3)
            skipped_SIDs.append(sid)
    return tlb_info
def parse_input_params():  # Input Parameter Validation
    global CURRENT_PATH
    global DUMP_PATH
    global TARGET_ID
    global SUBSYSTEM 
    global CLARA_OP
    global SMMU_OP 
    global Enable_6GB_dumps
    global addr_sepr_enable 
    global PARSER_TYPE 
    CURRENT_PATH = sys.argv[1]
    DUMP_PATH = os.path.dirname(sys.argv[2])
    if DUMP_PATH[-1] == '\\':
        DUMP_PATH = DUMP_PATH[:-1]
    TARGET_ID = sys.argv[3]
    SUBSYSTEM = sys.argv[4]
    CLARA_OP = sys.argv[5]
    SMMU_OP = sys.argv[6]
    Enable_6GB_dumps = sys.argv[7]
    addr_sepr_enable = sys.argv[8]
    PARSER_TYPE = 'smmu'
    if CLARA_OP != 'False': PARSER_TYPE = 'clara'

def print_msg(*argv):
    global _log
    if True:
        massage = argv[0]
        newline_flag = 0
        if len(argv) == 2: newline_flag = argv[1]

        if newline_flag == 1:  # To Close line without newline
            print(massage, end=' ')
            _log.append(massage)
        elif newline_flag == 2: # To append line with previous line
            print(massage)
            _log[-1] += massage
        elif newline_flag == 3: # To append line with previous line
            print(massage, end=' ')
            _log[-1] += massage
        else:
            print(massage)
            _log.append(massage)


def get_proper_dumpfile_based_on_apps_phy_address(py_add):
    for dumpfilename, dumpfile_address in DumpFilesStartAddress_Ordered_Dict.items():
        if dumpfile_address['startadd'] <= py_add < dumpfile_address['endadd']:
            return dumpfilename, dumpfile_address['startadd']
    return '',0



def detect_file(sid,PARSER_TYPE):
    try:
        if _log_level>=2: print_msg('SID:'+sid+' -> '+",".join(SID_TO_CB_MAPPING[SUBSYSTEM][TARGET_ID][sid])+' ->', 1)
    except:
        if _log_level>=2: print_msg('Equivalent mapping for SID:'+sid+' not present into SID_TO_CB_MAPPING dictionary.')
    # Output: combined_virtual_addlist, combined_physical_addlist, combined_block_sizelist
    ###############################################################################################################

        #skipped_SIDs.append(sid)

            # if New_Qurt_Model:
                # virtual_addlist = [int(line.split('*')[0].strip(), 0) for line in file_all_line_list]
                # physical_addlist = [int('0x'+line.split('*')[1][3:].strip(), 0) for line in file_all_line_list]
                # block_sizelist = [int(line.split('*')[3].strip(), 0) for line in file_all_line_list]
            # else:
        return 'NA'
    respective_file = 'NA'
    if PARSER_TYPE == 'clara':
        for keyword in SID_TO_CB_MAPPING[SUBSYSTEM][TARGET_ID][sid]:
            if "msm-audio-ion" in keyword:
                file = CURRENT_PATH+ r'\soc_qcom_msm-audio-apr_qcom_msm-audio-ion.txt'
            else:
                file = CURRENT_PATH + r'\soc_qcom_msm_fastrpc_qcom_'+keyword+'.txt'
            if os.path.isfile(file): 
                respective_file = file
                # print(os.path.basename(filename), '-> Total Mapping :', len(file_all_line_list), end=' -> ')
                break
    elif PARSER_TYPE == 'smmu':
        # keyword = '.*msm-audio.*' # if sid == '0x0'
        for keyword in SID_TO_CB_MAPPING[SUBSYSTEM][TARGET_ID][sid]:
            if 'msm_fastrpc_compute' in keyword:
                keyword = '.*'+keyword+'\[.*'
            elif 'STCU' in keyword:
                file = CURRENT_PATH+"/"+keyword+'.txt'

                if os.path.isfile(file):
                    respective_file = file

            else:
                keyword = '.*'+keyword+'.*'
        # print('After Clubbing :',len(combined_virtual_addlist))
            for file in glob.glob(CURRENT_PATH + r'\arm_iommu_domain_*.txt'):
                with open(file, 'r') as fileptr:
                    matchObj = re.match(keyword, fileptr.readline())
                    if matchObj:
                        respective_file = file
                        break
            if respective_file!='NA': break
    return respective_file

def get_dsp_to_apps_mapping(dsp_mapping_dict,apps_mapping_dict,asid,sid):

    ###############################################################################################################
    # Task  : Extract Physical, Virtual address and size from Files/List. create 3 Lists of it and Club them.
    # Input : DSP_side_SID_based_Mapping(list) or Parser(smmu/clara) output files
    # Output: combined_virtual_addlist, combined_physical_addlist, combined_block_sizelist
    ###############################################################################################################

    def binarysearch(leftindex, rightindex, dsp_phy_address):
        if rightindex >= leftindex:  # Check base case
            mid = leftindex + (rightindex - leftindex) // 2
            # print('mid :', mid)
            if mid == len(apps_mapping_dict['VA'])-1:
                if _int(apps_mapping_dict['VA'][mid]) <= _int(dsp_phy_address) < _int(apps_mapping_dict['VA'][mid])+ _int(apps_mapping_dict['SIZE'][mid]):  # If element is present at the end itself
                    return mid
                else:
                    return -1
            elif _int(apps_mapping_dict['VA'][mid]) <= _int(dsp_phy_address) < _int(apps_mapping_dict['VA'][mid+1]) and _int(dsp_phy_address) < _int(apps_mapping_dict['VA'][mid])+ _int(apps_mapping_dict['SIZE'][mid]):  # If element is present at the middle itself
                return mid
            elif _int(apps_mapping_dict['VA'][mid]) > _int(dsp_phy_address):  # If element is smaller than mid, then it can only be present in left subarray
                return binarysearch(leftindex, mid - 1, dsp_phy_address)
            else:  # Else the element can only be present in right subarray.
                return binarysearch(mid + 1, rightindex, dsp_phy_address)
        else:  # Element is not present in the array
            return -1

    global Total_Dump_size
    global aperture_addr
    global non_basic_aperture_maps
    global non_basic_maps
    global DumpFilesStartAddress_Ordered_Dict
    global DumpFilesStartAddressDict
    global total_bin
    global total_maps
    for dsp_vir_add, dsp_phy_add, dsp_blocksize in zip(dsp_mapping_dict['VA'], dsp_mapping_dict['PA'], dsp_mapping_dict['SIZE']):
        # print('\nDSP Mapping  :', hex(dsp_vir_add), hex(dsp_phy_add), hex(dsp_blocksize))
        total_bin["after"]=_hex_sum(total_bin["after"],dsp_blocksize)
        total_bin["non_basic"]=_hex_sum(total_bin["non_basic"],dsp_blocksize)
        [dsp_vir_add_temp, dsp_phy_add_temp, dsp_blocksize_temp] = [dsp_vir_add, dsp_phy_add, dsp_blocksize]

        while dsp_blocksize_temp != '0x0':
            # print('\n', hex(dsp_phy_add_temp))
            # print(hex(dsp_blocksize_temp))
            matched_index = binarysearch(0, len(apps_mapping_dict['VA']) - 1, dsp_phy_add_temp)
            if matched_index != -1:
                apps_vir_add = apps_mapping_dict['VA'][matched_index]
                apps_phy_add = apps_mapping_dict['PA'][matched_index]
                apps_blocksize = apps_mapping_dict['SIZE'][matched_index]
                # print('APPS Mapping  :', hex(apps_vir_add), hex(apps_phy_add), hex(apps_blocksize))

                size3 = _hex_diff(dsp_phy_add_temp, _hex_sum(apps_vir_add,apps_blocksize))
                size1 = _hex_diff(size3,apps_blocksize)
                mmu_block_size = dsp_blocksize_temp
                if _int(size3) <= _int(dsp_blocksize_temp):
                    mmu_block_size = size3
                apps_phy_add_temp = _hex_sum(apps_phy_add,size1)
                dumpfile_tmp, dumpfile_startaddress = get_proper_dumpfile_based_on_apps_phy_address(_int(apps_phy_add_temp))
                dumpfile_startaddress = hex(dumpfile_startaddress)
                try:
                    skip_add = _hex_diff(dumpfile_startaddress,apps_phy_add_temp)
                except:
                    dsp_blocksize_temp = 0
                    continue

                if True:
                    if (Enable_6GB_dumps == "True"):
                        # print('\n', hex(dsp_vir_add_temp), '++', hex(mmu_block_size - 1), ':',
                        #                    hex(apps_phy_add_temp), '(', hex(MMU_Mapping_StartAddress), ')',  '++', hex(mmu_block_size - 1), '->',
                        #                    dumpfile_tmp, ':', hex(dumpfile_startaddress), ':', hex(skip_add))
                        # print(' mmu.create '+str(hex(dsp_vir_add_temp))+'++'+str(hex(mmu_block_size - 1))+' '
                                           # +str(hex(MMU_Mapping_StartAddress))+'++'+str(hex(mmu_block_size - 1)))
                        # print(' d.load.binary '+DUMP_PATH+'\\'+dumpfile_tmp+'  a:'+str(hex(MMU_Mapping_StartAddress))+'++'
                              # +str(hex(mmu_block_size - 1))+' /SKIP '+str(hex(skip_add))+' /noclear')
                        mmu_cmd = 'mmu.create '+_hex(asid)+':'+_hex(dsp_vir_add_temp)+'++'+ _hex_diff('0x1',mmu_block_size)+' '+_hex(aperture_addr)+'++'+_hex_diff('0x1',mmu_block_size)
                                                     
                        non_basic_aperture_maps.append(mmu_cmd)
                        mmu_cmd = 'd.load.binary '+DUMP_PATH+'\\'+dumpfile_tmp+' ' +'a:'+_hex(aperture_addr)+'++'+_hex_diff('0x1',mmu_block_size)+' ' +'/SKIP '+_hex(skip_add) + ' ' +'/noclear'
                        non_basic_aperture_maps.append(mmu_cmd)
                        #f_log.write(mmu_cmd+'\n')                                           
                        new_apps_add = apps_phy_add_temp
                        if len(new_apps_add)==11:
                            new_apps_add = new_apps_add[:3]+':0x'+new_apps_add[3:]
                        else:
                            new_apps_add = '0x0:0x'+new_apps_add[2:]
                        # new_apps_add = 'a:0x'+str(hex(apps_phy_add_temp)).rstrip('L')[-8:][:-3]+'000' ## for 4GB dump
                        # print ('mmu.create '+str(hex(dsp_vir_add_temp)).rstrip('L')+'++'+
                                                             # str(hex(mmu_block_size - 1)).rstrip('L')+' '+
                                                             # new_apps_add +'++'+
                                                             # str(hex(mmu_block_size - 1)).rstrip('L'))
                        non_basic_maps.append('trans.create '+_hex(asid)+':'+_hex(dsp_vir_add_temp)+'++'+
                                                             _hex_diff('0x1',mmu_block_size)+' '+
                                                             new_apps_add+'++'+
                                                             _hex_diff('0x1',mmu_block_size)+' /More')
                        total_bin["apps_non_basic"]=_hex_sum(total_bin["apps_non_basic"],mmu_block_size)
                    else:
                        new_apps_add = apps_phy_add_temp
                        if len(new_apps_add)==11:
                            new_apps_add = new_apps_add[:3]+':0x'+new_apps_add[3:]
                        else:
                            new_apps_add = '0x0:0x'+new_apps_add[2:]
                        non_basic_maps.append('trans.create '+_hex(asid)+':'+_hex(dsp_vir_add_temp)+'++'+
                                                             _hex_diff('0x1',mmu_block_size)+' '+
                                                             new_apps_add+'++'+
                                                             _hex_diff('0x1',mmu_block_size)+' /More')
                    pass
                    if _hex(sid) not in total_maps.keys():
                        total_maps[_hex(sid)]=1;
                    else:
                        total_maps[_hex(sid)]=total_maps[_hex(sid)]+1
                Total_Dump_size = _hex_sum(Total_Dump_size,_hex_diff('0x1',mmu_block_size))
                if hex(_int(aperture_addr)&0xFF000000) == '0x78':  # Skip 0x7800000 to 0x98000000
                    aperture_addr = _hex_sum(aperture_addr,'0x20000000')
                aperture_addr = _hex_sum(aperture_addr,mmu_block_size)
                dsp_blocksize_temp = _hex_diff(mmu_block_size,dsp_blocksize_temp)
                dsp_vir_add_temp = _hex_sum(mmu_block_size,dsp_vir_add_temp)
                dsp_phy_add_temp = _hex_sum(mmu_block_size,dsp_phy_add_temp)
            else:
                # print("Mapping is not present from APPS side")
                dsp_blocksize_temp = "0x0"
        # break

    return

# Detect Start_address for all Dump Binary files from load.cmm.
def parse_bins():
    global DumpFilesStartAddressDict
    global DumpFilesStartAddress_Ordered_Dict
    with open(DUMP_PATH+r'\load.cmm') as fileptr:
        for line in fileptr:
            if 'd.load' in line.lower():
                line = line.split('\n')[0].strip().split(' ')
                if 'ddrc' in line[1][:4].lower() or 'dram' in line[1][:4].lower():
                    DumpFilesStartAddressDict[line[1].strip()] = int(line[2].strip(), 0)
        DumpFilesStartAddressDict = sorted(DumpFilesStartAddressDict.items(),
                                           key=lambda kv: kv[1])  # sort Dict by Start_Address
        for dumpfile, address in DumpFilesStartAddressDict:
            DumpFilesStartAddress_Ordered_Dict[dumpfile] = {'startadd': address,'endadd': address+os.path.getsize(DUMP_PATH+'\\'+dumpfile)}
        
        if _log_level>=1:
            print_msg('\nBinary Files Address Ranges :')
            for dumpfile, address in DumpFilesStartAddress_Ordered_Dict.items():
                print_msg(dumpfile+'->'+hex(address['startadd'])+' to '+hex(address['endadd']))

# Grouping all DSP side mapping based on SID
    ###############################################################################################################
    # Input : DSP_pgt_converted.txt
    # Output: DSP_side_SID_based_Mapping(dictionary), Available_SIDs(list), DSP_side_SID_based_Mapping.json
    ###############################################################################################################

    
def generate_mmu_maps():
    global basic_maps 
    for asid,sid_maps in dsp_tlb_info.items():
        for sid,tlb_maps in sid_maps.items():
            if _hex(sid) not in skipped_SIDs:
                if (_hex(sid) != "0x0"):  
                    get_dsp_to_apps_mapping(tlb_maps,apps_tlb_info[_hex(sid)],asid,sid)
    

# Clubbing continues Memory Block by calling respective function
    ###############################################################################################################
    # Task  : Clubbing continues Memory Block by calling respective function.
    # Input : DSP_side_SID_based_Mapping(dictionary), Available_SIDs(list).
    # Output: DSP_side_SID_based_clubbed_Mapping(dictionary), SID_0x0_MMU_Create_List(list)
    # DSP_side_SID_based_clubbed_Mapping = {'0x0':{'VA':[], 'PA':[], 'SIZE':[]},
    #                                       '0x1':{'VA':[], 'PA':[], 'SIZE':[]}
    #                                      }
    ###############################################################################################################

        # print('with SID_'+sid, ' :', len(DSP_side_SID_based_Mapping[sid]), end=' -> ')


            # print(hex(Vadd), ':', hex(Padd), ':', hex(size))

# Detect equivalent parser output file(.txt) based on SID in which APPS side mapping present.
# also Clubbing continues Memory Block
    ###############################################################################################################
    # Input : Parser output files, SID_TO_CB_MAPPING(dictionary), , Available_SIDs(list)
    # Output: APPS_side_SID_based_clubbed_Mapping(dictionary), APPS_side_SID_based_clubbed_Mapping.json
    # APPS_side_SID_based_clubbed_Mapping = {'0x1':{'VA':[], 'PA':[], 'SIZE':[]},
    #                                        '0x2':{'VA':[], 'PA':[], 'SIZE':[]},}
    ###############################################################################################################

    # print('\nParser file Equivalent to SIDs :')
    # skipped_SIDs = []
            # file = CURRENT_PATH+ r'\soc_qcom_msm-audio-apr_qcom_msm-audio-ion.txt' # if sid == '0x0'
                else:
            # keyword = '.*msm-audio.*' # if sid == '0x0'
                    for i in range(0,len(tlb_maps['VA'])):
                        if _hex(tlb_maps['SIZE'][i])!="0x0":
                            basic_maps.append('trans.create ' + _hex(asid)+":" + _hex(tlb_maps['VA'][i]) + '++' + _hex_diff('0x1',tlb_maps['SIZE'][i]) + ' '+ _hex(tlb_maps['PA'][i]) + '++' + _hex_diff('0x1',tlb_maps['SIZE'][i]) + ' /More')
                            total_bin["after"]=_hex_sum(tlb_maps['SIZE'][i],total_bin["after"])
                            if _hex(sid) not in total_maps.keys():
                                total_maps[_hex(sid)] = 1
                            else: total_maps[_hex(sid)] = total_maps[_hex(sid)] + 1   
                            
def main(): 
    parse_input_params()   
    parse_bins()
    
    global dsp_tlb_info
    global apps_tlb_info
    
    dsp_tlb_info = handle_dsp_tlbs()
    apps_tlb_info = handle_apps_tlbs()
            
    global total_bin 
    global _log
    with open(CURRENT_PATH + r'\apps_tlb_info.json', 'w') as outfile:
        json.dump(apps_tlb_info, outfile)
    with open(CURRENT_PATH + r'\dsp_tlb_info.json', 'w') as outfile:
        json.dump(dsp_tlb_info, outfile)

    generate_mmu_maps()
    # for Vadd, Padd, size in zip(TempDict['VA'], TempDict['PA'], TempDict['SIZE']):
    #     print(hex(Vadd), ':', hex(Padd), ':', hex(size))
    

    with open(CURRENT_PATH + r'\non_basic_maps.json', 'w') as outfile:
# Create MMU Mapping and Frame command to load equivalent Binary portion. Generate 6GB.CMM and 6GB_Dumps.CMM
    ###############################################################################################################
    # Input : Available_SIDs(list), DSP_side_SID_based_clubbed_Mapping(dict), APPS_side_SID_based_clubbed_Mapping(dict)
    # Output: 6GB.CMM, 6GB_Dumps.CMM
    ###############################################################################################################
    # print('\nSMMU Mapping Address Range as per SID:')
        json.dump(non_basic_maps, outfile)
    with open(CURRENT_PATH + r'\non_basic_aperture_maps.json', 'w') as outfile:
        # print(hex(MMU_Mapping_StartAddress))
        json.dump(non_basic_aperture_maps, outfile)
    with open(CURRENT_PATH + r'\basic_maps.json', 'w') as outfile:
        json.dump(basic_maps, outfile)
    
    Total_Nonbasic_Mapping = len(basic_maps)+len(non_basic_maps)
    if _log_level>=1:
        print_msg('\nClubbed Mapping Count as per SID:')
        for sid,count in total_maps.items():
            print_msg("SID: "+str(sid)+" -> "+str(count),1)
        print_msg('\nTotal Number of SMMU Mapping : '+str(len(basic_maps)+len(non_basic_maps)))
        print_msg('Basic(with SID 0x0) Mapping  : '+str(len(basic_maps)))
        print_msg('NonBasic  Mapping : '+str(len(non_basic_maps)))
    #print_msg('Total Binary size need to load : '+(Total_Dump_size)+'('+str(hex(Total_Dump_size))+')')
    # for index, mapping in enumerate(D_Load_Binary_List):
    #     print(str(index)+'->' +  MMU_Create_List[len(SID_0x0_MMU_Create_List) + index])
    #     print('   '+ mapping)

    with open(CURRENT_PATH + '\\6GBScript_OP.CMM', 'w') as fileptr1:
        fileptr1.write("area.create 6GBScript_OP")
        fileptr1.write("\nWINPOS 50% 0. 70% 75% 0. 0. 6GBScript_OP")
        fileptr1.write("\narea.view 6GBScript_OP")
        fileptr1.write("\narea.select 6GBScript_OP\n")
        _log = ['print \nprint "' + msg[1:] + '"' if msg[0] == '\n' else 'print "' + msg + '"' for msg in
                          _log]
        fileptr1.write('\n'.join(_log))

    with open(CURRENT_PATH+'\\6GB.CMM', 'w') as fileptr1:
       if Total_Nonbasic_Mapping > thresold_mapping_count or Enable_6GB_dumps=="False":
           if Enable_6GB_dumps!="False":
               check_trace_version()
           if os.path.isfile(CURRENT_PATH+'\\newload.CMM'):
               with open(CURRENT_PATH+'\\newload.CMM', 'r') as fileptr:
                   linelist = fileptr.readlines()
                   fileptr1.writelines(''.join(linelist))
                   fileptr1.write('\n\n')
       fileptr1.write("area.create SMMU_Loading")
       fileptr1.write("\nWINPOS 50% 75% 50% 30% 0. 0. SMMU_Loading")
       fileptr1.write("\narea.view SMMU_Loading")
       fileptr1.write("\narea.select SMMU_Loading\n")

       fileptr1.write('\nmmu.reset\n')
       fileptr1.write('mmu.off\n')
       if "true" in addr_sepr_enable.lower():
           fileptr1.write('\nSYStem.Option.MMUspaces ON\n')
       fileptr1.write('\n'.join(basic_maps))

       fileptr1.write('\nprint "Total # of Binary need to load : ' + str(Total_Nonbasic_Mapping) + '"\n')
       temp_list = list()
       cnt_var = 0
       skip_count = 200
       if Total_Nonbasic_Mapping > thresold_mapping_count or Enable_6GB_dumps=="False":
           skip_count = int(len(non_basic_maps)/10)
           for index, mmu_mapping in enumerate(non_basic_maps):
               if index % skip_count == 0 or index == 0:
                   temp_list.append('&tsec = clock.unix()')
                   temp_list.append('print "Creating MMU Mapping -> ' + str(index) + '-' + str(min(len(non_basic_maps),index+skip_count-1)) + ' (Total:' + str(Total_Nonbasic_Mapping)+') : &tsec" ')
                   #print('print "Creating MMU Mapping -> ' + str(index) + '-' + str(index+skip_count-1) + ' (Total:' + str(Total_Nonbasic_Mapping)+')"')
               temp_list.append(mmu_mapping)
       else:
           for index in range(0, len(non_basic_aperture_maps)-1, 2):
               if cnt_var % skip_count == 0 or cnt_var == 0:
                   temp_list.append('print "Loading Binary -> ' + str(cnt_var) + '-' + str(cnt_var+skip_count-1) + ' (Total:' + str(Total_Nonbasic_Mapping)+')"')
               temp_list.append(non_basic_aperture_maps[index])
               temp_list.append(non_basic_aperture_maps[index+1])
               cnt_var += 1
       fileptr1.write('\n'.join(temp_list))
       fileptr1.write('\ntrans.create 0x0++0x0 0x0++0x0')
       fileptr1.write('\nmmu.on')
       fileptr1.write('\nmmu.autoscan on')
       if TARGET_ID!="fillmore" and TARGET_ID!="kailua" and TARGET_ID!="makena" and TARGET_ID!="waipio" and TARGET_ID!="netrani" and TARGET_ID!="lanai":
            fileptr1.write('\nmmu.tablewalk on')
       #fileptr1.write('\nmmu.tablewalk on')
       fileptr1.write("\nWINClear TOP")
if __name__ == "__main__":
    main()



