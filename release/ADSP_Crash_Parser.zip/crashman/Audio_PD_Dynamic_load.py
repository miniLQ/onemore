# ------------------------------------------------------------------
#
# Copyright (c) 2019-2020 Qualcomm Technologies, Inc.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
# ------------------------------------------------------------------

import re
import sys
import os
import glob
OutputPath_temp  = sys.argv[1]
DumpPath = os.path.dirname(sys.argv[2])

LoadcmmFile = ''
if os.path.isfile(DumpPath+"/"+"load.cmm"): LoadcmmFile = DumpPath+"/"+"load.cmm"
if LoadcmmFile == '': 
	for file in glob.glob(DumpPath+"/"+"load.cmm.*"): LoadcmmFile = file
if LoadcmmFile == '': 
	print ("Load.cmm file is not present")
	sys.exit()
	
# print ("LoadcmmFile :",LoadcmmFile)
fileptr = open(LoadcmmFile,'r')
linelist = fileptr.readlines()
fileptr.close()
linelist = list(filter(lambda x: x if ('binary' in x and not 'OCIMEM' in x.upper() ) else '', linelist ))
DumpFileList =  [i.split()[1] for i in linelist]
DumpFileStartAddressList =  [i.split()[2] for i in linelist]
DumpFileStartAddressIntFormList = [int(i.split()[2],16) for i in linelist]

if not os.path.isfile(OutputPath_temp+"/AudioPDDynnamicLoading.txt"):
	print ("AudioPDDynnamicLoading.txt file isnot created")

fileptr = open(OutputPath_temp+"/AudioPDDynnamicLoading.txt",'r')
linelist = fileptr.readlines()
fileptr.close()
Paddress = ''
match = re.search("phy_addr = ([xA-Z0-9]*)",linelist[7])
if match: Paddress = match.group(1)
match = re.search("page_size = ([xA-Z0-9]*)",linelist[8])
if match: size = match.group(1)
if Paddress!='':
	# print ('Dynamic Audio PD Start_address :',Paddress,': Size',size)
	for index,address in enumerate(DumpFileStartAddressIntFormList):
		if int(Paddress,16)>= DumpFileStartAddressIntFormList[index]:
			StartAddress = DumpFileStartAddressList[index]
			DumpFile = DumpFileList[index]
	skip = str(hex(int(Paddress, 0)-int(StartAddress, 0)))
	# print ("Start Address :",StartAddress)
	# print ('PPage',':',Paddress,': Size :',size,'Skip :',skip)
	if not os.path.isfile(DumpPath+"/"+DumpFile):
		for file in glob.glob(DumpPath+"/"+"dram_cs0_*.lst"): 
			if StartAddress in file:
				DumpFile = file.split("/")[-1]
	Command =  "d.load.binary "+DumpPath+"/"+DumpFile+" a:"+Paddress+"++"+size+" /skip "+skip+" /noclear"
	# print (Command)
	fileptr = open(OutputPath_temp+"/CommandToLoadDynamicAudioPD.cmm",'w')
	fileptr.writelines(Command)
	fileptr.close()
else:
	print ('Not able to get corresponding .bin file from load.cmm')
	sys.exit()

