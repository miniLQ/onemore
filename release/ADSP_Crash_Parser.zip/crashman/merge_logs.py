# ------------------------------------------------------------------
#
# Copyright (c) 2019-2020 Qualcomm Technologies, Inc.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
# ------------------------------------------------------------------


#!/usr/bin/env python
# ============================================================================
# ------------
# Mergelogs.py
# ------------
# Merges different DMESG, TZ, RPM logs with same time stamp in a single file.

import os
import sys
import argparse
import ast
import re

# First file should be dmesg
files = [
            ["DMESG", "dmesg_TZ.txt", "\[ *(\d+\.\d+)\](.*)$"],
            ["QTIMER", "TZ\\Diag.txt", "\s*(\d+\.\d+):\s*(.*)$"],
            ["QTIMER_CYC", "TZ\\Diag.txt", "\s*\[([0-9a-fA-F]+)\]\s*(.*)$"],
            ["QTIMER_CYC", "AOP\\ULOG_Reports\\AOP_DDR_Log.txt", "(0x[0-9a-fA-F]+):\s*(.*)$"],
            ["QTIMER_CYC", "AOP\\ULOG_Reports\\AOP_External_Log.txt", "(0x[0-9a-fA-F]+):\s*(.*)$"],
            ["QTIMER_CYC","RPM\\RPM_External_Log.txt","(0x[0-9a-fA-F]+):\s*(.*)$"],
            ["QTIMER_CYC", "MODEM\\Diag.txt", "(0x[0-9a-fA-F]+):\s*(.*)$"],
            ["QTIMER_CYC", "ADSP\\Diag.txt", "(0x[0-9a-fA-F]+):\s*(.*)$"],
            ["QTIMER_CYC", "ADSP\\Kernel_trace.txt", "(0x[0-9a-fA-F]+):\s*(.*)$"],
            ["QTIMER_CYC", "ADSP\\ULOG_Reports\\uSleep_Normal.txt", "(0x[0-9a-fA-F]+):\s*(.*)$"],
            ["HLOS","msm_rtb0.txt","[0-9a-fA-F]+ \[(\d+\.\d+)\] (.*)$"],
            ["HLOS","msm_rtb1.txt","[0-9a-fA-F]+ \[(\d+\.\d+)\] (.*)$"],
            ["HLOS","msm_rtb2.txt","[0-9a-fA-F]+ \[(\d+\.\d+)\] (.*)$"],
            ["HLOS","msm_rtb3.txt","[0-9a-fA-F]+ \[(\d+\.\d+)\] (.*)$"],
            ["HLOS","msm_rtb4.txt","[0-9a-fA-F]+ \[(\d+\.\d+)\] (.*)$"],
            ["HLOS","msm_rtb5.txt","[0-9a-fA-F]+ \[(\d+\.\d+)\] (.*)$"],
            ["HLOS","msm_rtb6.txt","[0-9a-fA-F]+ \[(\d+\.\d+)\] (.*)$"],
            ["HLOS","msm_rtb7.txt","[0-9a-fA-F]+ \[(\d+\.\d+)\] (.*)$"]
        ]

#         ["QTIMER_CYC","RPM_External_Log.txt","(0x[0-9a-fA-F]+):\s*(.*)$"],
#         ["QTIMER_CYC","ADSPPM_Log.txt","(0x[0-9a-fA-F]+):\s*(.*)$"],

files_chrome = [
            ["DMESG", "dmesg_TZ.txt", "\[\s*(\d+\.\d+)\](.*)$"],
            ["QTIMER_CYC", "AOP\\ULOG_Reports\\AOP_DDR_Log.txt", "(0x[0-9a-fA-F]+):\s*(.*)$"],
            ["QTIMER_CYC", "AOP\\ULOG_Reports\\AOP_External_Log.txt", "(0x[0-9a-fA-F]+):\s*(.*)$"],
            ["QTIMER_CYC", "MODEM\\Diag.txt", "(0x[0-9a-fA-F]+):\s*(.*)$"],
            ["HLOS","msm_rtb0.txt","\[\s*(\d+\.\d+)\](.*)$"],
            ["QTIMER_CYC", "ADSP\\Kernel_trace.txt", "(0x[0-9a-fA-F]+):\s*(.*)$"],
            ["HLOS","msm_rtb1.txt","\[\s*(\d+\.\d+)\](.*)$"],
            ["HLOS","msm_rtb2.txt","\[\s*(\d+\.\d+)\](.*)$"],
            ["HLOS","msm_rtb3.txt","\[\s*(\d+\.\d+)\](.*)$"],
            ["HLOS","msm_rtb4.txt","\[\s*(\d+\.\d+)\](.*)$"],
            ["HLOS","msm_rtb5.txt","\[\s*(\d+\.\d+)\](.*)$"],
            ["HLOS","msm_rtb6.txt","\[\s*(\d+\.\d+)\](.*)$"],
            ["HLOS","msm_rtb7.txt","\[\s*(\d+\.\d+)\](.*)$"]
        ]

suspend_list = []
epoch_ns = None
epoch_cyc = None


def cyc_to_sec(cycles):
    return cycles / 19200000.0


def sec_to_cyc(sec):
    return sec * 19200000


def ns_to_sec(ns):
    return ns / 1000000000.0


def sec_to_ns(sec):
    return sec * 1000000000.0


def ns_to_cyc(ns):
    return sec_to_cyc(ns_to_sec(ns))


def cyc_to_ns(cycles):
    return sec_to_ns(cyc_to_sec(cycles))


def HLOSts_to_qtimer(ts):
    if ts == 0:
        return 0
    tsns = sec_to_ns(ts)
    if suspend_list:
        for suspend_ns, suspend_cyc, resume_cyc in suspend_list:
            if tsns <= suspend_ns:
                ts_qtimer_cyc = suspend_cyc - ns_to_cyc(suspend_ns - tsns)
                return cyc_to_sec(ts_qtimer_cyc)
    ts_qtimer_cyc = epoch_cyc + ns_to_cyc(tsns - epoch_ns)
    return cyc_to_sec(ts_qtimer_cyc)


def qtimer_to_HLOSts(qtimer_ts):
    qtimer_cyc = sec_to_cyc(qtimer_ts)
    if suspend_list:
        for suspend_ns, suspend_cyc, resume_cyc in suspend_list:
            if qtimer_cyc < suspend_cyc:
                hlos_ns = suspend_ns - cyc_to_ns(suspend_cyc - qtimer_cyc)
                return ns_to_sec(hlos_ns)
            if qtimer_cyc >= suspend_cyc and qtimer_cyc <= resume_cyc:
                return ns_to_sec(suspend_ns)
    return ns_to_sec(epoch_ns + cyc_to_ns(qtimer_cyc - epoch_cyc))


def extract_epoch_info(file_path):
    epoch_ns = None
    epoch_cyc = None
    fin = open(file_path, 'r')
    for line in fin:
        if "epoch_ns: " in line:
            epoch_re = re.search(r"epoch_ns:\s*(\d+).*epoch_cyc:\s*(\d+).*", line)
            if epoch_re:
                epoch_ns = int(epoch_re.group(1))
                epoch_cyc = int(epoch_re.group(2))
            break
    fin.close()
    return epoch_ns, epoch_cyc


def is_chrome():
    is_chrome = False
    # Check if epoch_info.txt exists and has Chromium OS
    file_name = 'epoch_info.txt'
    file_path = os.path.join(args.log_location, file_name)
    if os.path.exists(file_path):
        with open(file_path, 'r') as fin:
            for line in fin:
                regex = re.search(r'^Linux Banner :(.*)', line)
                if regex:
                    if "Chromium OS" in regex.group(1):
                        is_chrome = True
                        break
        return is_chrome
    return is_chrome

# Parsing the arguments
parser = argparse.ArgumentParser()
parser.add_argument("log_location", type=str, help="Crash logs location")
parser.add_argument('-o','--output',
                      help='Absolute Location of output file')
args = parser.parse_args()

file_list = list()
# print (is_chrome())
if not is_chrome():
    # Process the file dmesz_TZ.txt
    file_name = 'dmesg_TZ.txt'
    file_path = os.path.join(args.log_location, file_name)
    file_list = files
else:
    file_name = 'epoch_info.txt'
    file_path = os.path.join(args.log_location, file_name)
    file_list = files_chrome

all_logs = []
if os.path.isfile(file_path) is True:
    epoch_ns, epoch_cyc = extract_epoch_info(file_path)
    if epoch_ns == None or epoch_cyc == None:
        pass
    else:
        # print (epoch_ns,'\n',epoch_cyc)

        for type, log_file, regex in file_list:
            for root, dirnames, filenames in os.walk(args.log_location):
                if "txtReports\\SDX" in root:
                    continue
                log_file_name = log_file.split('\\')[-1]
                if log_file_name in filenames:
                    file_path = os.path.join(root, log_file_name)
                    if log_file in file_path:
                        print (file_path)
                        break
                else:
                    file_path = None
            if file_path is None:
                continue
            fin = open(file_path, 'r')
            if fin is None:
                # print ("Unable to open file ", file_path)
                continue
            if type == "DMESG":
                read_flag = False
                reverse = reversed(fin.readlines())
                all_logs.append([])
                for line in reverse:
                    if read_flag is True:
                        if "begin Dmesg" in line:
                            read_flag = False
                        else:
                            dmesg_re = re.search(regex, line)
                            if dmesg_re is not None:
                                ts = float(dmesg_re.group(1))
                                log = dmesg_re.group(2)
                                ts_qtimer = HLOSts_to_qtimer(ts)
                                all_logs[-1].insert(0, [ts_qtimer, ts, log_file, log])
                        if "resume cycles:  " in line:
                            resume_cyc = int(line.split()[-1])
                            next = reverse.next()
                            while "suspend ns:  " not in next and next is not None:
                                next = reverse.next()
                            if next is None:
                                break
                            suspend_cyc = float(next.split()[-1])
                            suspend_ns = float(next.split()[-4])
                            suspend_list.insert(0, [suspend_ns,suspend_cyc,resume_cyc])

                    else:
                        if "end Dmesg" in line:
                            read_flag = True
            elif type == "QTIMER":
                for line in fin:
                    qtimer_re = re.search(regex, line)
                    if qtimer_re is not None:
                        ts_qtimer = float(qtimer_re.group(1))
                        log = qtimer_re.group(2)
                        ts_hlos = qtimer_to_HLOSts(ts_qtimer)
                        all_logs[-1].append([ts_qtimer, ts_hlos, log_file, log])
            elif type == "QTIMER_CYC":
                for line in fin:
                    qtimer_re = re.search(regex, line)
                    if qtimer_re is not None:
                        #if "ADSP" in log_file:
                            #print (line)
                        ts_qtimer_cyc = int(qtimer_re.group(1), 16)
                        ts_qtimer = cyc_to_sec(ts_qtimer_cyc)
                        log = qtimer_re.group(2)
                        ts_hlos = qtimer_to_HLOSts(ts_qtimer)
                        all_logs[-1].append([ts_qtimer, ts_hlos, log_file, log])
            elif type == "HLOS":
                for line in fin:
                    hlos_re = re.search(regex, line)
                    if hlos_re is not None:
                        ts_hlos = float(hlos_re.group(1))
                        ts_qtimer = HLOSts_to_qtimer(ts_hlos)
                        log = hlos_re.group(2)
                        all_logs[-1].append([ts_qtimer, ts_hlos, log_file, log])

            fin.close()
        logs = []
        for each_log in all_logs:
            logs += each_log
        logs = sorted(logs, key=lambda x: x[0], reverse=False)
        # Open output file
        file_name = 'merge_logs.txt'
        file_path = os.path.join(args.output, file_name)
        fop = open(file_path, 'w')
        if fop is None:
            print ("Unable to create output file")
        else:
            for each_row in logs:
                fop.write("[{0:.6f}][{1:.6f}][{2}]:{3}\n".format(
                    each_row[0], each_row[1], each_row[2], each_row[3]))

