
import os
import sys
import argparse

CurrentDirectory=os.path.dirname(os.path.abspath(__file__))

#Dump_path=sys.argv[1]
#build=sys.argv[2]
#target=sys.argv[3]

parser = argparse.ArgumentParser(description='SDC dump loading method')
parser.add_argument("-d", "--dump", help="Provide the SDC data & code + PRAM binary path")
parser.add_argument("-b", "--build",  help="Provide the ADSP build path")
parser.add_argument("-t", "--target",  help="provide target name")
parser.add_argument("-e", "--elf",  help="provide elf path")
parser.add_argument("-use_t32", "--use_t32",  help="Pick T32 from user provided path")

args = parser.parse_args()

if (args.dump):
	Dump_path=args.dump
	if not os.access(Dump_path,os.R_OK):
		print ("Dump path not accessible, please get the access & retry")
else:
	print("Dump argument not provided")
	exit()
	
if (args.build):
	build=args.build
	if not os.access(build,os.R_OK):
		print ("Build path not accessible, please get the access & retry")
else:
	print("Build argument not provided")

elf_path = ""
if (args.elf):
	elf_path=args.elf
	if not os.access(elf_path,os.R_OK):
		print ("ELF path not accessible, please get the access & retry")
if (args.target):
	target=args.target
	
if (args.use_t32):
	T32_path=args.use_t32+"/bin/windows64"
	if not os.access(T32_path,os.R_OK):
		print ("T32 path not accessible, please get the access & retry")
else:
	T32_path= "C:/t32/bin/windows64"

#print (T32_path)
if os.path.exists(T32_path):
	#print ("i'm here")
	command = '''start %s/t32marm64.exe -c %s, %s %s %s %s %s'''%(T32_path,CurrentDirectory+"/t32_config.t32",CurrentDirectory+"/SDC_dump_load.cmm",Dump_path,build,target,elf_path)
	#command = '''start %s/t32marm64.exe -c %s, %s %s %s %s'''%(T32_path,Dump_path+"/temp/config_sim_usb.t32",CurrentDirectory+"/SDC_dump_load.cmm",Dump_path,build,target)
	#print (command)
	os.system(command)