import sys

#num of 4-byte words to compare at PC
num_cmp = 4


def main():
    hex_= sys.argv[1]
    int_ = int(hex_,16)

    l = []
    for i in range(num_cmp):
        l.append((int((int_%16)/4), hex(int_ - int_%16)))
        int_ += 4

    folder = sys.argv[2]
    
    log_file = open(folder + "/icache_logs.txt",'a')
    
    try:
        file1 = open(folder+"/icache_dump.txt",'r') #dump file
    except:
        log_file.write("Can't find the file icache_dump.txt\n")
        log_file.close()
        return

    try:
        file2 = open(folder+"/icache_mem.txt",'r') #mem file
    except:
        log_file.write("Can't find the file icache_mem.txt\n")
        log_file.close()
        return


    
    comp1 = {}
    comp2 = {}

    #skipping the first line in both the files
    next(file1)
    next(file2)


    #collecting the contents of the files into a dict, each entry has four 4-byte words
    for l_f1 in file1:
        l_f1 = l_f1.strip()
        if l_f1 == "": break

        for l_f2 in file2:
            l_f2 = l_f2.strip()
            if l_f2 == "": break

            temp1 = l_f1.split()
            temp2 = l_f2.split()
            comp1[hex(int(temp1[2][:-1],16))] = temp1[-8:-4]
            comp1[hex(int(temp1[2][:-1],16)+16)] = temp1[-4:]

            comp2[hex(int(temp2[2][:-1],16))] = temp2[-8:-4]
            comp2[hex(int(temp2[2][:-1],16)+16)] = temp2[-4:]
            break


        

    if len(temp1)<8+5 or len(temp2)<8+5:
        log_file.write("Result mignt not be reliable, please check if icache_dump.txt and icache_mem.txt are parsed properly\n")
        
        
    is_pc_present = False
    #comparing contents of files
    contents = ()
    check = False
    for index, key in l:
        if key in comp1:
            if key in comp2:
                is_pc_present = True

                if comp1[key][index] == comp2[key][index]:
                    continue
                else:
                    check = True
                    contents = (comp1[key][index],comp2[key][index])
                    break
                    
                    
                    

    
    if(check):
        log_file.write("Icache error detected at PC:"+hex_+", contents from dump:"+contents[0]+" and mem:"+contents[1]+"\n")
    else:
        if is_pc_present:
            log_file.write("No icache error detected at PC:"+hex_+"\n")
        else:    
            log_file.write("PC:"+hex_+" not found\n")
    log_file.close()

if __name__ == "__main__":
    main()