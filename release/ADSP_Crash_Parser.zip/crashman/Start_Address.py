# ------------------------------------------------------------------
#
# Copyright (c) 2019-2020 Qualcomm Technologies, Inc.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
# ------------------------------------------------------------------

# Start_Address.py  \\range\kernel\tushar\adsp_cdsp\Fulldump\SOC\Port_COM10_20200825123828459\DDRCS0_0.BIN C:\Temp\Crashman_08_28_12h45m24s\Logs saipan False False False True
# Start_Address.py  \\range\kernel\tushar\adsp_cdsp\Fulldump\SOC\Port_COM10_20200825123828459\DDRCS0_0.BIN C:\Temp\Crashman_08_28_12h46m58s\Logs saipan False True False True

# Start_Address.py  \\lab7455\MemoryDumps\DB433D08\20200827-204439\md_CDSP_MINIDUM.BIN C:\Temp\Crashman_08_28_10h16m29s\Logs cedros False True False True
# Start_Address.py  \\lab7455\MemoryDumps\DB433D08\20200827-204439\md_ADSP_MINIDUM.BIN C:\Temp\Crashman_08_28_10h39m10s\Logs cedros False False False True

# Start_Address.py  \\lab5385\Dropbox\c_pravka\mannar_minidump\md_CDSP_MINIDUM.BIN C:\Temp\Crashman_08_28_10h16m29s\Logs mannar False True False True
# Start_Address.py  \\lab5385\Dropbox\c_pravka\mannar_minidump\md_ADSP_MINIDUM.BIN C:\Temp\Crashman_08_28_10h39m10s\Logs mannar False False False True

# Start_Address.py  \\range\kernel\tushar\adsp_cdsp\Fulldump\SSR\fulldump_ramdump_md_adsp_2020-08-12_17-35-49.elf C:\Temp\Crashman_08_28_12h58m20s\Logs saipan False False False True
# Start_Address.py  \\range\kernel\tushar\adsp_cdsp\Fulldump\SSR\fulldump_ramdump_md_cdsp_2020-08-12_17-36-26.elf C:\Temp\Crashman_08_28_12h58m49s\Logs saipan False True False True

# Start_Address.py  \\range\kernel\tushar\adsp_cdsp\Minidump\SOC\Port_COM10_20200825124404223\md_ADSP_MINIDUM.BIN C:\Temp\Crashman_08_28_12h51m41s\Logs saipan False False False True
# Start_Address.py  \\range\kernel\tushar\adsp_cdsp\Minidump\SOC\Port_COM10_20200825124404223\md_CDSP_MINIDUM.BIN C:\Temp\Crashman_08_28_12h54m47s\Logs saipan False True False True

# Start_Address.py  \\range\kernel\tushar\adsp_cdsp\Minidump\SSR\ramdump_md_adsp_2020-08-12_17-27-32.elf C:\Temp\Crashman_08_28_12h56m22s\Logs saipan False False False True
# Start_Address.py  \\range\kernel\tushar\adsp_cdsp\Minidump\SSR\ramdump_md_cdsp_2020-08-12_17-28-35.elf C:\Temp\Crashman_08_28_12h57m34s\Logs saipan False True False True

# Start_Address.py  C:\Jira_Automation_Tool\Database\dram_cs0_0x80000000--0xffffffff.lst C:\Temp\Crashman_09_02_17h14m1s\Logs lahaina False False True True

import sys
import re
import os.path
import binascii
import datetime
import glob

input=str(sys.argv[1])
outputpath=str(sys.argv[2])
TargetName=str(sys.argv[3])
sensor = str(sys.argv[4])
cdsp_flag = str(sys.argv[5])
slpi_target_flag = str(sys.argv[6])
new_target_flag = str(sys.argv[7])
start_address_file = outputpath+"\\temp\\adspstartaddr.txt"
alignment_address_file = outputpath+"\\temp\\alignment.txt"

print "\nDump File :", input
print "Target    :", TargetName
print "CDSP_Flag :", cdsp_flag
print "SLPI_Flag :", sensor

if os.path.isfile(start_address_file): os.remove(start_address_file)

def DetectStartAddress_From_Provided_DumpFile(inputdump,outputpath,extension,TargetName,cdsp_flag):

	def is_adsp_start_string(file,index,string,outputpath,input,seek_offset,TargetName,cdsp_flag):
		print "Looking for :",string,seek_offset
		StartAddress = False
		VirtualAddress = False
		if new_target_flag == "True":
			# if cdsp_flag == "True": len_30mb = 10485760 #10MB value
			# else: len_30mb = 31457280 #35MB value
			if cdsp_flag == "True":
				len_30mb = 10485760 #10MB value
				string_search = "IMAGE_VARIANT_STRING="+TargetName+".cdsp"
			else:
				len_30mb = 31457280 #35MB value
				string_search = "IMAGE_VARIANT_STRING="+TargetName+".adsp"
			file = open(input,'rb')
			file.seek(seek_offset)
			check_30mb = file.tell()
			cond_cdsp = False
			for line in file:
				offset = file.tell()
				if (offset-check_30mb)>=len_30mb: break
				if string_search in line: cond_cdsp = True
				if string in line and cond_cdsp:
				# if string in line:
					try:
						temp =  line.split(string)[1].split()[0].strip()
						if not "%x" in temp:
							StartAddress = temp
							temp1 = line.split('VA-')[1].split('\x00')[0]
							if not "%x" in temp1:
								VirtualAddress = temp1
								if "*" in VirtualAddress: VirtualAddress = VirtualAddress.split('*')[0]
					except:
						print "Error in Message!!"
					if VirtualAddress != False:
						VA = outputpath+"\\temp\\VA.txt"
						f2 = open(VA, 'w')
						f2.write(VirtualAddress)
						f2.close()
						break
			file.close()
		else:
			len_30mb = 36700160 #35MB value
			file = open(input,'rb')
			file.seek(seek_offset)
			check_30mb = file.tell()
			count = 0
			for line in file:
				count = count + 1
				offset = file.tell()
				if (offset-check_30mb)>=len_30mb:
					break
				if "*ADSP_START_ADDRESS: PA-" in line:
					try:
						temp =  line.split('*ADSP_START_ADDRESS: PA-')[1].split()[0]
						if not "%x" in temp:
							StartAddress = temp
							temp1 = line.split('VA-')[1].split('\x00')[0]
							if not "%x" in temp1:
								VirtualAddress = temp1
								if "*" in VirtualAddress:
									VirtualAddress = VirtualAddress.split('*')[0]
					except:
						print "Error in Message!!"
					print StartAddress
					print VirtualAddress
					if VirtualAddress != False:
						VA = outputpath+"\\temp\\VA.txt"
						f2 = open(VA, 'w')
						f2.write(VirtualAddress)
						f2.close()
						break
			file.close()
		return StartAddress
	
	list1=[0x00,0xC0,0x00,0x78,0x06,0x40,0x00,0x67]
	list2=[0x0E,0xC0,0x00,0x58,0x00,0xC0,0x00,0x58]
	string1,string2 = ["",""]
	for item in list1: string1=string1+chr(item)
	for item in list2: string2=string2+chr(item)
	inputfile = open(inputdump, 'rb')
	align_1mb = 0
	key=inputfile.read(8)
	first_time_skip = 0
	address = None
	while(key):
		if key == string1 or key == string2 or extension == ".elf" or extension == ".ELF":
			if first_time_skip == 0:
				first_time_skip = 1
				address = inputfile.tell()
			else:
				start_addr = is_adsp_start_string(inputfile,0,"ADSP_START_ADDRESS: PA-",outputpath,inputdump,inputfile.tell(),TargetName,cdsp_flag)
				if start_addr != False:
					print 'Start_Addr',start_addr
					f2 = open(start_address_file, 'w')
					f2.write(start_addr)
					f2.close()
					f2 = open(alignment_address_file, 'w')
					if (TargetName == "nicobar") or (TargetName == "6018") or (TargetName == "kamorta"):
						i = int(start_addr,16) & 0x3FFFFFFF
					else:
						i = int(start_addr,16) & 0x7FFFFFFF
					if hex(i).replace('L','') == hex(align_1mb):
						f2.write(str(hex(align_1mb)))
						print 'Alignment_Address:',str(hex(align_1mb))
					else:    
						f2.write(str(hex(i).replace('L','')))
						print 'Alignment_Address:',str(hex(i).replace('L',''))
					f2.close()
					break
		align_1mb = align_1mb+(0x100000)
		inputfile.seek(align_1mb)
		key=inputfile.read(8)
	
	if first_time_skip == 1 and address != None and not os.path.isfile(start_address_file):
		inputfile.seek(address)
		start_addr = is_adsp_start_string(inputfile,0,"ADSP_START_ADDRESS: PA-",outputpath,inputdump,inputfile.tell(),TargetName,cdsp_flag) 
		if start_addr != False:
			print 'Start_Addr',start_addr
			f2 = open(start_address_file, 'w')
			f2.write(start_addr)
			f2.close()
	
	if first_time_skip == 1 and address != None and not os.path.isfile(start_address_file):
		if cdsp_flag == "True": tempstr = "*CDSP_MINIDUMP - "
		else: tempstr = "*ADSP_MINIDUMP  - "
		start_addr = is_adsp_start_string(inputfile,0,tempstr,outputpath,inputdump,inputfile.tell(),TargetName,cdsp_flag)
		if start_addr != False:
			if '0X' not in start_addr: start_addr = '0X'+start_addr
			print 'Start_Addr :',start_addr
			f2 = open(start_address_file, 'w')
			f2.write(start_addr)
			f2.close()
	
	inputfile.close()

def DetectStartAddress_From_Ocimem_File(input,outputpath,slpi_flag,cdsp_flag):
	
	while True:  ## Extracting Ocimem file from dump location
		ocimem_check = ''
		for file in glob.glob(os.path.dirname(input)+'\\ocimem*.BIN'): ocimem_check = file
		if ocimem_check == '':
			for file in glob.glob(os.path.dirname(input)+'\\ocimem*.lst'): ocimem_check = file
		if ocimem_check == '':
			print "Ocimem file not present at Dump location"
			return False
		# if os.path.isfile(os.path.dirname(input)+'\\OCIMEM.BIN'): ocimem_check = os.path.dirname(input)+'\\OCIMEM.BIN'
		# elif os.path.isfile(os.path.dirname(input)+'\\ocimem.BIN'): ocimem_check = os.path.dirname(input)+'\\ocimem.BIN'
		break
	
	while True:  ## Extract Start Address from Ocimem File
		print "Checking @",ocimem_check
		adsp_1, adsp_2= ["",""]
		if slpi_flag == "True":
			adsp_string_1 = [0x73,0x6C,0x70,0x69]
			adsp_string_2 = [0x53,0x4C,0x50,0x49]
		elif cdsp_flag == "True":
			adsp_string_1 = [0x63,0x64,0x73,0x70]  # \x63\x64\x73\x70
			adsp_string_2 = [0x43,0x44,0x53,0x50]
		else:
			adsp_string_1 = [0x61,0x64,0x73,0x70]  # \x61\x64\x73\x70
			adsp_string_2 = [0x41,0x44,0x53,0x50]
		# adsp_string_1 = [0x6D,0x6F,0x64,0x65]  ## for Modem
		# adsp_string_2 = [0x4D,0x4F,0x44,0x45]
		for item in adsp_string_1: adsp_1 = adsp_1 + chr(item)
		for item in adsp_string_2: adsp_2 = adsp_2 + chr(item)
		found = False
		address = False
		file = open(ocimem_check,'rb')
		while (not found):
			key = file.read(4)
			if not key:
				file.close()
				return
			if key == adsp_1 or key == adsp_2:
				key = file.read(4)
				s1=binascii.hexlify(file.read(1))
				s2=binascii.hexlify(file.read(1))
				s3=binascii.hexlify(file.read(1))
				s4=binascii.hexlify(file.read(1))
				address = "0x"+s4+s3+s2+s1
				print "address ",address
				if (s1=="00")&(s2=="00")&(s3!="00")&(s4!="00"):
					print "Start_Address :",address
					f2 = open(start_address_file, 'w')
					f2.write(address)
					f2.close()
					found = True
		file.close()
		break
	
	while True:  ## Extract Aligment Address from provided dump file
		list1=[0x00,0xC0,0x00,0x78,0x06,0x40,0x00,0x67]  # \x00\xC0\x00\x78\x06\x40\x00\x67
		list2=[0x0E,0xC0,0x00,0x58,0x00,0xC0,0x00,0x58]  # \x0E\xC0\x00\x58\x00\xC0\x00\x58
		string, string1 = ["",""]
		for item in list1: string=string+chr(item)
		for item in list2: string1=string1+chr(item)

		f = open(input, 'rb')
		address_offset = "0x"+address[3:]
		offset = int(address_offset,16)
		for check in range(0,8):
			f.seek(offset)
			# print str(hex(offset))
			key=f.read(8)
			if key == string or key == string1:
				f2 = open(alignment_address_file, 'w')
				f2.write(str(hex(offset)))
				print 'Alignment_Address:',str(hex(offset))
				f2.close()
				break
			offset = offset + 0x10000000  ##256 MB
		f.close()
		break
	
	return True

while True:   ## Type of dump file
	extension = os.path.splitext(input)[1]
	f1 = open(outputpath+"\\temp\\dumpformant.txt", 'w')
	if (extension == ".elf" or extension == ".ELF"):
		f1.write("2")
		f4 = open(input,"r")
		data = f4.read(4)
		f4.seek(60)
		s1=binascii.hexlify(f4.read(1))
		s2=binascii.hexlify(f4.read(1))
		s3=binascii.hexlify(f4.read(1))
		s4=binascii.hexlify(f4.read(1))
		address = "0x"+s4+s3+s2+s1
		f4.close()
	else:
		f1.write("1")
	f1.close()
	break

while False:  ## Get Total Dump size
	possible_dump_name=["DDRCS0.BIN","DDRCS1.BIN","DDRCS0_0.BIN","DDRCS0_1.BIN","DDRCS0_2.BIN","DDRCS1_0.BIN","DDRCS1_1.BIN","DDRCS1_2.BIN","ADSP0.bin","EBICS0.RAM","dram_0x80000000--0xffffffff.lst","dram1_0x100000000--0x17fffffff.lst","dram_0x40000000--0xffffffff.lst","dram1_0x100000000--0x1bfffffff.lst","dram_cs1_0x100000000--0x17fffffff.lst","dram_cs1_0x180000000--0x1ffffffff.lst","dram_cs0_0x80000000--0xffffffff.lst","dram_cs0_0x100000000--0x17fffffff.lst","slpi_dump.bin","adsp_dump.bin",'rennell_dump.bin','EBICS0.bin']
	s1 =  os.path.getsize(input)
	DumpSize = 0
	for file in possible_dump_name:
		dump_file = os.path.dirname(input)+"\\"+file
		if os.path.isfile(dump_file):
			DumpSize = DumpSize + os.path.getsize(dump_file)
	Enable_6GB = False
	if DumpSize > 4294967296: Enable_6GB = True 
	print "Dump Size :",hex(DumpSize),':',DumpSize
	break

try:          ## Get Dump file Start Address of dump file from load.cmm file
	if os.path.isfile(os.path.dirname(input)+"\\load.cmm"):
		fileptr = open(os.path.dirname(input)+"\\load.cmm",'r')
		linelist = fileptr.readlines()
		fileptr.close()
		linelist = list(filter(lambda x: x if ('binary' in x and not 'OCIMEM' in x.upper() ) else '', linelist ))
		DumpFileList =  [i.split()[1] for i in linelist]
		DumpFileStartAddressList =  [i.split()[2] for i in linelist]
		load_cmm_file_dict = dict (zip(DumpFileList,DumpFileStartAddressList))
		offset_from_ocimem = load_cmm_file_dict[os.path.basename(input)]
		print "Dump File Start_Addrs :",offset_from_ocimem
except:
	pass

print "\nPlease wait, finding start address..."

return_flag = DetectStartAddress_From_Ocimem_File(input,outputpath,sensor,cdsp_flag)
if os.path.isfile(start_address_file): sys.exit(0)
if return_flag!=False: print "Start Address not detected from Ocimem file."

print "\nTrying to extract address from ",input
DetectStartAddress_From_Provided_DumpFile(input,outputpath,extension,TargetName,cdsp_flag)
if os.path.isfile(start_address_file): sys.exit(0)
print '\nNot able to extract Start Address fro Ocimem file and from Dump file'

if 'minidum' in input.split("\\")[-1].lower():
	print 'Start_Addr :',offset_from_ocimem
	f2 = open(start_address_file, 'w')
	f2.write(offset_from_ocimem)
	f2.close()