# ------------------------------------------------------------------
#
# Copyright (c) 2019-2020 Qualcomm Technologies, Inc.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
# ------------------------------------------------------------------

import sys

possible_SID = {"22":"HLOS_AUDIO1" , "23":"HLOS_ADSP2" , "24":"HLOS_ADSP3" , "25":"HLOS_ADSP4", "30":"HLOS_CDSP1", "31":"HLOS_CDSP2", "32":"HLOS_CDSP3", "33":"HLOS_CDSP4", "34":"HLOS_CDSP5", "35":"HLOS_CDSP6", "36":"HLOS_CDSP7", "37":"HLOS_CDSP8", "59":"HLOS_CDSP9"}

possible_CB = {"STCU(22)":"HLOS_AUDIO1" , "STCU(23)":"msm_fastrpc_compute_cb10" , "STCU(24)":"msm_fastrpc_compute_cb11" , "STCU(25)":"msm_fastrpc_compute_cb12", "STCU(30)":"msm_fastrpc_compute_cb1", "STCU(31)":"msm_fastrpc_compute_cb2", "STCU(32)":"msm_fastrpc_compute_cb3", "STCU(33)":"msm_fastrpc_compute_cb4", "STCU(34)":"msm_fastrpc_compute_cb5", "STCU(35)":"msm_fastrpc_compute_cb6", "STCU(36)":"msm_fastrpc_compute_cb7", "STCU(37)":"msm_fastrpc_compute_cb8", "STCU(59)":"msm_fastrpc_compute_cb9"}

possible_CB_1 = {"STCU(22)":"23" , "STCU(23)":"20" , "STCU(24)":"21" , "STCU(25)":"22", "STCU(40)":"11", "STCU(31)":"12", "STCU(32)":"13", "STCU(33)":"14", "STCU(34)":"15", "STCU(35)":"16", "STCU(36)":"17", "STCU(37)":"18", "STCU(59)":"19"}
#IOMMU Context: None attached. Domain: soc:qcom,msm_fastrpc:qcom,msm_fastrpc_compute_cb6[L2 cache redirect for page tables is OFF]
#IOMMU Context: None attached. Domain: soc:qcom,msm-audio-apr:qcom,msm-audio-ion[L2 cache redirect for page tables is OFF]


def main():

	qnx_smmu_path = sys.argv[1]
	output_path = sys.argv[2]
	#print (output_path)
	for CB_number in range(11,24,1):
		file_name = "arm_iommu_domain_"+str(CB_number)
		#print (output_path+file_name)
		pgt_info= open (output_path+file_name+".txt", 'w')
		if CB_number!=23:
			pgt_info.write("IOMMU Context: None attached. Domain: soc:qcom,msm_fastrpc:qcom,msm_fastrpc_compute_cb"+str(CB_number-10)+"[L2 cache redirect for page tables is OFF]\n")
		else:
			pgt_info.write("IOMMU Context: None attached. Domain: soc:qcom,msm-audio-apr:qcom,msm-audio-ion[L2 cache redirect for page tables is OFF]\n")

	pgt_info= open (qnx_smmu_path, 'r')
	for line_pgt in pgt_info:
		if "STCU" in line_pgt or "GPU" in line_pgt:
			list_pgt = line_pgt.split()
			#print (list_pgt)
			Size = list_pgt[-1]
			Size = hex(int(Size, 16)*4096)
			size_int=int(Size, 16)-1
			Size_original = hex(int(Size, 16))
			Size = hex(int(Size, 16)-1)
			VA = list_pgt[5]
			VA_first = hex(int(VA, 16)).rstrip("L")
			VA_end = hex(int(VA, 16)+size_int).rstrip("L")
			PA = list_pgt[6]
			PA_first = hex(int(PA, 16)).rstrip("L")
			PA_end = hex(int(PA, 16)+size_int).rstrip("L")
			#print (VA_first,VA_end, Size , PA_first , PA_end)
			CB_number=possible_CB_1.get(str(list_pgt[0]))
			#print (possible_CB_1.get(str(list_pgt[0])))
			file_name = "arm_iommu_domain_"+str(CB_number)
			pgt_info= open (output_path+file_name+".txt", 'a')
			pgt_info.write(VA_first+"--"+VA_end+" ["+Size_original+"] A:"+PA_first+"--"+PA_end+" ["+Size_original+"]\n")

	#pgt_info= open ('smmu_rb_clean.txt', 'rU')
	#for line_pgt in pgt_info:
		#if "STCU" in line_pgt:
			#list_pgt = line_pgt.split()
			#CB=list_pgt[0].split('(')[1].split(")")[0]
			#print (CB)
			#print (possible_CB.get(str(CB)))
			#print (list_pgt )
			#print ("\n"	)
		
#0xf7ff9000--0xf7ff9fff [0x1000] A:0xa92c9000--0xa92c9fff [0x1000]
		
if __name__ == '__main__':
  main()