# ------------------------------------------------------------------
#
# Copyright (c) 2019-2020 Qualcomm Technologies, Inc.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
# ------------------------------------------------------------------

import sys
import re
import os

if (len(sys.argv) < 3):
	exit()

writefile = open(sys.argv[2],"a")
if '.elf' in sys.argv[1]:
	try:
		file_ptr = open(sys.argv[2],"r")
		linelist = file_ptr.readlines()
		if 'prod2Q' in linelist[1] or 'prod2Q' in linelist[2]:
			file_ptr = open(os.path.dirname(sys.argv[2])+"//list_of_elf_file_need_to_load.txt","r")
			linelist = file_ptr.readlines()
			for cnt in range(len(linelist)):
				if 'prodQ' in  linelist[cnt]: linelist[cnt] = linelist[cnt].replace('prodQ','prod2Q')
				linelist[cnt] = linelist[cnt].split('\n')[0].strip()
			f_out = open(os.path.dirname(sys.argv[2])+"//list_of_elf_file_need_to_load.txt","w")
			print (linelist)
			for temp_elf in linelist: f_out.write(temp_elf+'\n')
			f_out.close()
			elf_file = (sys.argv[1]).replace('prodQ','prod2Q')
			readfile = open(elf_file,"rb")
	except:
		print ("\nTimeStamp not collected properly from Dump")
		
new_target_flag = False
if (len(sys.argv) == 4): 
	new_target_flag = sys.argv[3]

if '.elf' in sys.argv[1]: writefile.write("B::Analysis : TimeStamp from elf\n")
else: writefile.write("B::Analysis : TimeStamp from Dump\n")

start_addr = "0"
if len(sys.argv)>4:
	start_addr = sys.argv[3]

match1 = 0
match2 = 0
if "0x8" in start_addr or "0X8" in start_addr:
	start_addr = start_addr[0]+start_addr[1]+start_addr[3:]
index = int(start_addr,0)


with open(sys.argv[1], 'rb') as readfile:
	readfile.seek(index)
	for line in readfile:
		if "Q6_BUILD" in line.decode(errors='ignore'):
			line =line.decode(errors='ignore')
			match = re.search(r'(QCOM time:Q6_BUILD[^\x00]+)\x00',line)
			if match:
				if match1 == 0:
					if 'PST' in match.group(1):
						writefile.write(match.group(1)+"\n")
						match1 = 1
			match = re.search(r'(ENGG time:Q6_BUILD[^\x00]+)\x00',line)
			if match:
				if match2 == 0:
					if 'PST' in match.group(1):
						writefile.write(match.group(1)+"\n")
						match2 = 1
		if match1 == 1:
			if match2 == 1:
				break

readfile.close()
writefile.close()
