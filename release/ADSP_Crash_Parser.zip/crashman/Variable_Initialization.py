
POSSIBLE_TARGET_NAME = {
                        '8998':    [''],
                        '8996':    [''],
                        '8937':    ['8917', '8940', '8920'],
                        '439':     ['429', 'SDM439', 'SDM429'],
                        '8953':    ['450', '632', 'SDM632', 'SDM450'],
                        '9x35':    ['9x35', '9635'],
                        '405':     ['403', '404', 'QCS403', 'QCS404', 'QCS405', 'VT_NF', 'qcs405'],
                        '660':     ['630', 'SDM660', 'SDM630', 'Starlord_Starhawk', '660'],
                        '670':     ['710', 'SDM670', 'SDM710', 'WARLOCK', 'sdm710'],
                        '6150':    ['SM6150', 'TALOS', 'steppe'],
                        '7150':    ['SM7150', 'MOOREA', 'steppe'],
                        '845':     ['SDM845', 'NAPALI', 'sdm845'],
                        '855':     ['8150', 'SDM855', 'SM8150', 'HANA', 'msmnile'],
                        '8250':    ['SM8250', 'KONA', 'kona'],
                        '1000':    ['SDM1000', 'SC8180X', 'POIPU', 'sdmshrike'],
                        'nicobar': ['trinket'],
                        'saipan':  ['7250', 'lito'],
                        'rennell': ['SM7125', 'atoll'],
                        'kamorta': ['4250', '6115', 'SM6115', 'bengal'],
                        'lahaina': ['8350', 'lahaina'],
                        'bitra':   ['6350', 'SM7225', 'SD750', 'lagoon'],
                        'agatti':  ['4125', 'bengal'],
                        'mannar':  ['4350', 'SM4350', 'holi'],
                        'cedros':  ['7350', 'shima'],
                        '6018':    ['cypress', '8074'],
                        'makena':  ['SC8280X', 'sc8280x']
                        }

CPU_HEXAGON_VERSION = {
                        'HexagonV56': ['8994', '8992', '8952', '8953', '8937', '439', '8976'],
                        'HexagonV60': ['8996'],
                        'HexagonV62': ['8998', '660'],
                        'HexagonV65': ['670', '7150', '845'],
                        'HexagonV66': ['6150', 'nicobar', '855', '8250', '405', '1000', 'saipan', 'rennell', '6018',
                                       'kamorta', 'bitra', 'agatti', 'lahaina', 'mannar', 'cedros', 'makena'],
                       }

ADSP_BINARY_SIZE = {'0x01800000': ['8976', '8953', '8937', '439'],
                    '0x02300000': ['8952', '845', '855', '1000'],
                    '0x02800000': ['660', '670', '6150', '7150', 'nicobar', '6018', 'kamorta', 'agatti', 'mannar',
                                   'cedros', 'makena'],
                    '0x01A00000': ['405'],
                    '0x02c00000': ['8250'],
                    '0x03600000': ['saipan'],
                    '0x04000000': ['bitra', '7225', 'lahaina', 'rennell']
                    }
CDSP_BINARY_SIZE = {'0x02300000': ['855', '8250', 'saipan', 'rennell', '6018', 'bitra', 'agatti'],
                    '0x0A00000':  ['660', '405', '1000'],
                    '0x1e00000':  ['670', '6150', 'nicobar', '7150', '845', 'kamorta', 'lahaina', 'mannar', 'cedros',
                                   'makena']
                    }

SID_TO_CB_MAPPING = {
			  'adsp':{
					  'bitra':{
								'0x1':'msm-audio-ion',
								'0x3':'msm_fastrpc_compute_cb10',
								'0x4':'msm_fastrpc_compute_cb11',
								'0x5':'msm_fastrpc_compute_cb12'
							   },
					  'kamorta':{
							  '0x1':'msm-audio-ion',
							  '0x3':'msm_fastrpc_compute_cb10',
							  '0x4':'msm_fastrpc_compute_cb11',
							  '0x5':'msm_fastrpc_compute_cb12',
							  '0x6':'msm_fastrpc_compute_cb13',
							  '0x7':'msm_fastrpc_compute_cb14'
							 },
					  'mannar':{
							  '0x1':'msm-audio-ion',
							  '0x3':'msm_fastrpc_compute_cb10',
							  '0x4':'msm_fastrpc_compute_cb11',
							  '0x5':'msm_fastrpc_compute_cb12',
							  '0x6':'msm_fastrpc_compute_cb13',
							  '0x7':'msm_fastrpc_compute_cb14'
							 },
					  '6018':{
							'0x1':'msm-audio-ion',
							'0x4':'msm_fastrpc_compute_cb1',
							'0x5':'msm_fastrpc_compute_cb2',
							'0x6':'msm_fastrpc_compute_cb3',
							'0x7':'msm_fastrpc_compute_cb4',
							'0x8':'msm_fastrpc_compute_cb5',
							'0x9':'msm_fastrpc_compute_cb6',
							'0xA':'msm_fastrpc_compute_cb7',
							'0xB':'msm_fastrpc_compute_cb8'
							   },
					  'rennell':{
								'0x1':'msm-audio-ion',
								'0x3':'msm_fastrpc_compute_cb10',
								'0x4':'msm_fastrpc_compute_cb11',
								'0x5':'msm_fastrpc_compute_cb12'
							   },
					  'saipan':{
								'0x1':'msm-audio-ion',
								'0x3':'msm_fastrpc_compute_cb10',
								'0x4':'msm_fastrpc_compute_cb11',
								'0x5':'msm_fastrpc_compute_cb12'
							   },
					  '8250':{
								'0x1':'msm-audio-ion',
								'0x3':'msm_fastrpc_compute_cb10',
								'0x4':'msm_fastrpc_compute_cb11',
								'0x5':'msm_fastrpc_compute_cb12'
							   },
					  'nicobar':{
								'0x1':'msm-audio-ion',
								'0x3':'msm_fastrpc_compute_cb10',
								'0x4':'msm_fastrpc_compute_cb10',
								},
					  '7150':{
							  '0x1':'msm-audio-ion',
							  '0x3':'msm_fastrpc_compute_cb10',
							  '0x4':'msm_fastrpc_compute_cb11',
							  '0x5':'msm_fastrpc_compute_cb12',
							  '0x6':'msm_fastrpc_compute_cb13',
							  '0x7':'msm_fastrpc_compute_cb14',
							  '0x8':'msm_fastrpc_compute_cb15'
							 },
					  '6150':{
							  '0x1':'msm-audio-ion',
							  '0x3':'msm_fastrpc_compute_cb10',
							  '0x4':'msm_fastrpc_compute_cb11',
							  '0x5':'msm_fastrpc_compute_cb12',
							  '0x6':'msm_fastrpc_compute_cb13',
							  '0x7':'msm_fastrpc_compute_cb14',
							  '0x8':'msm_fastrpc_compute_cb15'
							 },
					  '855':{
							  '0x1':'msm-audio-ion',
							  '0x3':'msm_fastrpc_compute_cb10',
							  '0x4':'msm_fastrpc_compute_cb11',
							  '0x5':'msm_fastrpc_compute_cb12'
							 },
					  'lahaina':{
							  '0x1':'msm-audio-ion',
							  '0x3':'msm_fastrpc_compute_cb10',
							  '0x4':'msm_fastrpc_compute_cb11',
							  '0x5':'msm_fastrpc_compute_cb12'
							 },
					  'cedros':{
							  '0x1':'msm-audio-ion',
							  '0x3':'msm_fastrpc_compute_cb10',
							  '0x4':'msm_fastrpc_compute_cb11',
							  '0x5':'msm_fastrpc_compute_cb12'
							 },
					  'kodiak':{
							  '0x1':'msm-audio-ion',
							  '0x3':'msm_fastrpc_compute_cb10',
							  '0x4':'msm_fastrpc_compute_cb11',
							  '0x5':'msm_fastrpc_compute_cb12'
							 },
					  '670':{
							'0x1':'msm-audio-ion',
							'0x3':'msm_fastrpc_compute_cb9',
							'0x4':'msm_fastrpc_compute_cb10',
							'0x5':'msm_fastrpc_compute_cb11',
							'0x6':'msm_fastrpc_compute_cb12',
							 },
					  '845':{
							'0x3':'msm_fastrpc_compute_cb11',
							'0x4':'msm_fastrpc_compute_cb12',
							 },
					  '1000':{
							'0x3':'msm_fastrpc_compute_cb11',
							'0x4':'msm_fastrpc_compute_cb12',
							 },
					  '660':{
							'0x3':'msm_fastrpc_compute_cb1',
							'0x7':'msm_fastrpc_compute_cb2',
							'0x8':'msm_fastrpc_compute_cb3',
							'0x9':'msm_fastrpc_compute_cb4',
							'0xA':'msm_fastrpc_compute_cb5',
							'0xB':'msm_fastrpc_compute_cb6',
							'0xC':'msm_fastrpc_compute_cb7',
							'0xD':'msm_fastrpc_compute_cb8',
							 },
					  '8996':{
							'0x8':'msm_fastrpc_compute_cb1',
							'0x9':'msm_fastrpc_compute_cb2',
							'0xA':'msm_fastrpc_compute_cb3',
							'0xB':'msm_fastrpc_compute_cb4',
							'0xC':'msm_fastrpc_compute_cb5',
							'0xD':'msm_fastrpc_compute_cb6',
							'0xE':'msm_fastrpc_compute_cb7',
							'0xF':'msm_fastrpc_compute_cb8',
							 },
					  '8998':{
							'0x8':'msm_fastrpc_compute_cb1',
							'0x9':'msm_fastrpc_compute_cb2',
							'0xA':'msm_fastrpc_compute_cb3',
							'0xB':'msm_fastrpc_compute_cb4',
							'0xC':'msm_fastrpc_compute_cb5',
							'0xD':'msm_fastrpc_compute_cb6',
							'0xE':'msm_fastrpc_compute_cb7',
							'0xF':'msm_fastrpc_compute_cb8',
							 }
					 },
			  'cdsp':{
					  'makena':{
								'0x1':'0x17030000',
								'0x2':'0x17030004',
								'0x3':'0x17030008',
								'0x4':'0x1703000c',
								'0x5':'0x17030010',
								'0x6':'0x17030014',
								'0x7':'0x17030018',
								'0x8':'0x1703001c',
								'0xB':'0x17030020',
								'0xC':'0x17030024',
								'0xD':'0x17030028',
								'0xF':'0x17030030',
								'0xE':'0x1703002c',
								},
					  'bitra':{
								'0x1':'msm_fastrpc_compute_cb1',
								'0x2':'msm_fastrpc_compute_cb2',
								'0x3':'msm_fastrpc_compute_cb3',
								'0x4':'msm_fastrpc_compute_cb4',
								'0x5':'msm_fastrpc_compute_cb5',
								'0x6':'msm_fastrpc_compute_cb6',
								'0x7':'msm_fastrpc_compute_cb7',
								'0x8':'msm_fastrpc_compute_cb8',
								'0x9':'msm_fastrpc_compute_cb9'
								},
					  'kamorta':{
								'0x1':'msm_fastrpc_compute_cb1',
								'0x2':'msm_fastrpc_compute_cb2',
								'0x3':'msm_fastrpc_compute_cb3',
								'0x4':'msm_fastrpc_compute_cb4',
								'0x5':'msm_fastrpc_compute_cb5',
								'0x6':'msm_fastrpc_compute_cb6',
								'0x9':'msm_fastrpc_compute_cb9'
								},
					  'mannar':{
								'0x1':'msm_fastrpc_compute_cb1',
								'0x2':'msm_fastrpc_compute_cb2',
								'0x3':'msm_fastrpc_compute_cb3',
								'0x4':'msm_fastrpc_compute_cb4',
								'0x5':'msm_fastrpc_compute_cb5',
								'0x6':'msm_fastrpc_compute_cb6',
								'0x9':'msm_fastrpc_compute_cb9'
								},
					  '6018':{
								'0x1':'msm_fastrpc_compute_cb1',
								'0x2':'msm_fastrpc_compute_cb2',
								'0x3':'msm_fastrpc_compute_cb3',
								'0x4':'msm_fastrpc_compute_cb4',
								'0x5':'msm_fastrpc_compute_cb5'
							   },
					  'rennell':{
								'0x1':'msm_fastrpc_compute_cb1',
								'0x2':'msm_fastrpc_compute_cb2',
								'0x3':'msm_fastrpc_compute_cb3',
								'0x4':'msm_fastrpc_compute_cb4',
								'0x5':'msm_fastrpc_compute_cb5',
								'0x6':'msm_fastrpc_compute_cb6',
								'0x7':'msm_fastrpc_compute_cb7',
								'0x8':'msm_fastrpc_compute_cb8',
								'0x9':'msm_fastrpc_compute_cb9'
								},
					  'saipan':{
								'0x1':'msm_fastrpc_compute_cb1',
								'0x2':'msm_fastrpc_compute_cb2',
								'0x3':'msm_fastrpc_compute_cb3',
								'0x4':'msm_fastrpc_compute_cb4',
								'0x5':'msm_fastrpc_compute_cb5',
								'0x6':'msm_fastrpc_compute_cb6',
								'0x7':'msm_fastrpc_compute_cb7',
								'0x8':'msm_fastrpc_compute_cb8',
								'0x9':'msm_fastrpc_compute_cb9'
								},
					  '8250':{
								'0x1':'msm_fastrpc_compute_cb1',
								'0x2':'msm_fastrpc_compute_cb2',
								'0x3':'msm_fastrpc_compute_cb3',
								'0x4':'msm_fastrpc_compute_cb4',
								'0x5':'msm_fastrpc_compute_cb5',
								'0x6':'msm_fastrpc_compute_cb6',
								'0x7':'msm_fastrpc_compute_cb7',
								'0x8':'msm_fastrpc_compute_cb8',
								'0x9':'msm_fastrpc_compute_cb9'
							 },
					  'nicobar':{
								'0x1':'msm_fastrpc_compute_cb1',
								'0x2':'msm_fastrpc_compute_cb2',
								'0x3':'msm_fastrpc_compute_cb3',
								'0x4':'msm_fastrpc_compute_cb4',
								'0x5':'msm_fastrpc_compute_cb5',
								'0x6':'msm_fastrpc_compute_cb6',
								'0x9':'msm_fastrpc_compute_cb9'
								},
					  '7150':{
							  '0x1':'msm_fastrpc_compute_cb1',
							  '0x2':'msm_fastrpc_compute_cb2',
							  '0x3':'msm_fastrpc_compute_cb3',
							  '0x4':'msm_fastrpc_compute_cb4',
							  '0x5':'msm_fastrpc_compute_cb5',
							  '0x6':'msm_fastrpc_compute_cb6',
							  '0x9':'msm_fastrpc_compute_cb9'
							 },
					  '6150':{
							  '0x1':'msm_fastrpc_compute_cb1',
							  '0x2':'msm_fastrpc_compute_cb2',
							  '0x3':'msm_fastrpc_compute_cb3',
							  '0x4':'msm_fastrpc_compute_cb4',
							  '0x5':'msm_fastrpc_compute_cb5',
							  '0x6':'msm_fastrpc_compute_cb6',
							  '0x9':'msm_fastrpc_compute_cb9'
							 },
					  '855':{
							'0x1':'msm_fastrpc_compute_cb1',
							'0x2':'msm_fastrpc_compute_cb2',
							'0x3':'msm_fastrpc_compute_cb3',
							'0x4':'msm_fastrpc_compute_cb4',
							'0x5':'msm_fastrpc_compute_cb5',
							'0x6':'msm_fastrpc_compute_cb6',
							'0x7':'msm_fastrpc_compute_cb7',
							'0x8':'msm_fastrpc_compute_cb8',
							'0x9':'msm_fastrpc_compute_cb9'
							 },
					  'lahaina':{
							'0x1':'msm_fastrpc_compute_cb1',
							'0x2':'msm_fastrpc_compute_cb2',
							'0x3':'msm_fastrpc_compute_cb3',
							'0x4':'msm_fastrpc_compute_cb4',
							'0x5':'msm_fastrpc_compute_cb5',
							'0x6':'msm_fastrpc_compute_cb6',
							'0x7':'msm_fastrpc_compute_cb7',
							'0x8':'msm_fastrpc_compute_cb8',
							'0x9':'msm_fastrpc_compute_cb9',
							'0xB':'msm_fastrpc_compute_cb16',
							'0xC':'msm_fastrpc_compute_cb17',
							'0xD':'msm_fastrpc_compute_cb18',
							'0xE':'msm_fastrpc_compute_cb19'
							 },
					  'cedros':{
							'0x1':'msm_fastrpc_compute_cb1',
							'0x2':'msm_fastrpc_compute_cb2',
							'0x3':'msm_fastrpc_compute_cb3',
							'0x4':'msm_fastrpc_compute_cb4',
							'0x5':'msm_fastrpc_compute_cb5',
							'0x6':'msm_fastrpc_compute_cb6',
							'0x7':'msm_fastrpc_compute_cb7',
							'0x8':'msm_fastrpc_compute_cb8',
							'0x9':'msm_fastrpc_compute_cb9',
							'0xB':'msm_fastrpc_compute_cb16',
							'0xC':'msm_fastrpc_compute_cb17',
							'0xD':'msm_fastrpc_compute_cb18',
							'0xE':'msm_fastrpc_compute_cb19'
							 },
					  'kodiak':{
							'0x1':'msm_fastrpc_compute_cb1',
							'0x2':'msm_fastrpc_compute_cb2',
							'0x3':'msm_fastrpc_compute_cb3',
							'0x4':'msm_fastrpc_compute_cb4',
							'0x5':'msm_fastrpc_compute_cb5',
							'0x6':'msm_fastrpc_compute_cb6',
							'0x7':'msm_fastrpc_compute_cb7',
							'0x8':'msm_fastrpc_compute_cb8',
							'0x9':'msm_fastrpc_compute_cb9',
							'0xB':'msm_fastrpc_compute_cb16',
							'0xC':'msm_fastrpc_compute_cb17',
							'0xD':'msm_fastrpc_compute_cb18',
							'0xE':'msm_fastrpc_compute_cb19'
							 },
					  '670':{
							'0x1':'msm_fastrpc_compute_cb1',
							'0x2':'msm_fastrpc_compute_cb2',
							'0x3':'msm_fastrpc_compute_cb3',
							'0x4':'msm_fastrpc_compute_cb4',
							'0x5':'msm_fastrpc_compute_cb5',
							'0x6':'msm_fastrpc_compute_cb6',
							'0x9':'msm_fastrpc_compute_cb7',
							'0xA':'msm_fastrpc_compute_cb8',
							 },
					  '845':{
							'0x1':'msm_fastrpc_compute_cb1',
							'0x2':'msm_fastrpc_compute_cb2',
							'0x3':'msm_fastrpc_compute_cb3',
							'0x4':'msm_fastrpc_compute_cb4',
							'0x5':'msm_fastrpc_compute_cb5',
							'0x6':'msm_fastrpc_compute_cb6',
							'0x7':'msm_fastrpc_compute_cb7',
							'0x8':'msm_fastrpc_compute_cb8',
							'0x9':'msm_fastrpc_compute_cb9',
							'0xA':'msm_fastrpc_compute_cb10'
							 },
					  '1000':{
							'0x1':'msm_fastrpc_compute_cb1',
							'0x2':'msm_fastrpc_compute_cb2',
							'0x3':'msm_fastrpc_compute_cb3',
							'0x4':'msm_fastrpc_compute_cb4',
							'0x5':'msm_fastrpc_compute_cb5',
							'0x6':'msm_fastrpc_compute_cb6',
							'0x7':'msm_fastrpc_compute_cb7',
							'0x8':'msm_fastrpc_compute_cb8',
							'0x9':'msm_fastrpc_compute_cb9',
							'0xA':'msm_fastrpc_compute_cb10'
							 },
					  '660':{
							'0x3':'msm_fastrpc_compute_cb5',
							'0x4':'msm_fastrpc_compute_cb6',
							'0x5':'msm_fastrpc_compute_cb7',
							'0x6':'msm_fastrpc_compute_cb8',
							'0x7':'msm_fastrpc_compute_cb9',
							'0x8':'msm_fastrpc_compute_cb1',
							'0x9':'msm_fastrpc_compute_cb2',
							'0xA':'msm_fastrpc_compute_cb3',
							'0xB':'msm_fastrpc_compute_cb4',
							 },
					  '8996':{
							'0x8':'msm_fastrpc_compute_cb1',
							'0x9':'msm_fastrpc_compute_cb2',
							'0xA':'msm_fastrpc_compute_cb3',
							'0xB':'msm_fastrpc_compute_cb4',
							'0xC':'msm_fastrpc_compute_cb5',
							'0xD':'msm_fastrpc_compute_cb6',
							'0xE':'msm_fastrpc_compute_cb7',
							'0xF':'msm_fastrpc_compute_cb8',
							 },
					  '8998':{
							'0x8':'msm_fastrpc_compute_cb1',
							'0x9':'msm_fastrpc_compute_cb2',
							'0xA':'msm_fastrpc_compute_cb3',
							'0xB':'msm_fastrpc_compute_cb4',
							'0xC':'msm_fastrpc_compute_cb5',
							'0xD':'msm_fastrpc_compute_cb6',
							'0xE':'msm_fastrpc_compute_cb7',
							'0xF':'msm_fastrpc_compute_cb8',
							 }
					 },
			  'slpi':{
					  'bitra':{
								'0x1':'msm_fastrpc_compute_cb13',
								'0x2':'msm_fastrpc_compute_cb14',
								'0x3':'msm_fastrpc_compute_cb15'
								},
					  'saipan':{
								'0x1':'msm_fastrpc_compute_cb13',
								'0x2':'msm_fastrpc_compute_cb14',
								'0x3':'msm_fastrpc_compute_cb15'
								},
					  'rennell':{
								'0x1':'msm_fastrpc_compute_cb13',
								'0x2':'msm_fastrpc_compute_cb14',
								'0x3':'msm_fastrpc_compute_cb15'
								},
					  '8250':{
								'0x1':'msm_fastrpc_compute_cb13',
								'0x2':'msm_fastrpc_compute_cb14',
								'0x3':'msm_fastrpc_compute_cb15'
							 },
					  'nicobar':{
								'0x1':'msm_fastrpc_compute_cb13',
								'0x2':'msm_fastrpc_compute_cb14',
								'0x3':'msm_fastrpc_compute_cb15'
								},
					  '7150':{},
					  '6150':{},
					  '855':{
							'0x1':'msm_fastrpc_compute_cb13',
							'0x2':'msm_fastrpc_compute_cb14',
							'0x3':'msm_fastrpc_compute_cb15'
								},
					  'lahaina':{
							'0x1':'msm_fastrpc_compute_cb13',
							'0x2':'msm_fastrpc_compute_cb14',
							'0x3':'msm_fastrpc_compute_cb15'
								},
					  '670':{},
					  '845':{},
					  '1000':{},
					  '660':{},
					  '8996':{
							'0x8':'msm_fastrpc_compute_cb1',
							'0x9':'msm_fastrpc_compute_cb2',
							'0xA':'msm_fastrpc_compute_cb3',
							'0xB':'msm_fastrpc_compute_cb4',
							'0xC':'msm_fastrpc_compute_cb5',
							'0xD':'msm_fastrpc_compute_cb6',
							'0xE':'msm_fastrpc_compute_cb7',
							'0xF':'msm_fastrpc_compute_cb8',
							 },
					  '8998':{
							'0x8':'msm_fastrpc_compute_cb1',
							'0x9':'msm_fastrpc_compute_cb2',
							'0xA':'msm_fastrpc_compute_cb3',
							'0xB':'msm_fastrpc_compute_cb4',
							'0xC':'msm_fastrpc_compute_cb5',
							'0xD':'msm_fastrpc_compute_cb6',
							'0xE':'msm_fastrpc_compute_cb7',
							'0xF':'msm_fastrpc_compute_cb8',
							 }
					 }
			 }






