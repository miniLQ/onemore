# ------------------------------------------------------------------
#
# Copyright (c) 2019-2020 Qualcomm Technologies, Inc.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
# ------------------------------------------------------------------

import os
import re
import subprocess
import sys
import time
import datetime
import fnmatch
import shutil, errno
from os import walk


def CheckLoadCMM(DumpPath):
	file = DumpPath + "\\load.cmm"
	binary_list = []
	if os.path.isfile(file):
		f = open(file,'r')
		for line in f:
			if (('d.load' in line.lower()) and ('ddrc' in line.lower() or 'dram' in line.lower())):
				temp = line.split()
				# if os.path.isfile(DumpPath+"\\"+temp[1]):
				temp.append(hex(os.path.getsize(DumpPath+"\\"+temp[1])).replace('L',''))
				binary_list.append(temp)
		f.close()
	# for temp in binary_list: print (temp)
	return binary_list
	
def GetAddress(Output,address,size,address_1,size_1,DumpPath,binary_list,line_bsc):
	fil = Output + '\\6GB_BasicMapping_Ranges.txt'
	if os.path.isfile(fil):
		f_fil = open(fil,'r')
		if int(address,16) >= int('0xFFFFFFFF',16):
			start =  "0x"+address[3:]
			# print (start,size)
		else:
			start = address
		size_check = size
		start_end = hex(int(start,16) + int(size_check,16)).replace('L','')
		# print (start+':'+start_end) # 0x9800000:0x98fffff
		cond = False
		for line in f_fil:
			add = line.split()[3]
			siz = line.split()[5]
			srt_add = add
			srt_end = hex(int(add,16) + int(siz,16)).replace('L','')
			if (int(start,16) >= int(srt_add,16) and int(start,16) <= int(srt_end,16)) or (int(start_end,16) >= int(srt_add,16) and int(start_end,16) <= int(srt_end,16)):
				cond = True
				break
		if cond == False:
			f_fil.close()
			f_fil = open(fil,'a')
			f_fil.write(address_1+' -- '+size_1+'          '+start+' -- '+size_check+'\n')
			f_fil.close()
			value = None
			for name in binary_list:
				if int(address,16) >= int(name[2],16) and int(address,16) <= int(name[2],16)+int(name[4],16):
					value = name
					break
			if value != None:
				file_cmm = open(Output+'\\6GB_Binary_Loading.cmm','a')
				skip = hex( int(address,16) - int(name[2],16)).replace('L','')
				# file_cmm.write(';'+line_bsc)
				file_cmm.write('mmu.create '+address_1+'++'+size_1+' '+start+'++'+size_check+'\n')
				file_cmm.write('d.load.binary '+DumpPath+'\\'+value[1]+'  a:'+start+'++'+size_check+' /SKIP '+str(skip)+' /noclear\n\n')
				file_cmm.close()
				return
		
		f_fil = open(fil,'r')
		size_check = size
		start = '0x0'
		while(1):
			start_end = hex(int(start,16) + int(size_check,16)).replace('L','')
			cond = False
			for line in f_fil:
				add = line.split()[3]
				siz = line.split()[5]
				srt_add = add
				srt_end = hex(int(add,16) + int(siz,16)).replace('L','')
				if (int(start,16) >= int(srt_add,16) and int(start,16) <= int(start_end,16)) or (int(start_end,16) >= int(srt_add,16) and int(start_end,16) <= int(srt_end,16)):
					cond = True
					break
			if cond == False:
				f_fil.close()
				f_fil = open(fil,'a')
				f_fil.write(address_1+' -- '+size_1+'          '+start+' -- '+size_check+'\n')
				f_fil.close()
				value = None
				for name in binary_list:
					if int(address,16) >= int(name[2],16) and int(address,16) <= int(name[2],16)+int(name[4],16):
						value = name
						break
				if value != None:
					file_cmm = open(Output+'\\6GB_Binary_Loading.cmm','a')
					skip = hex( int(address,16) - int(name[2],16)).replace('L','')
					file_cmm.write(';'+line_bsc)
					file_cmm.write('mmu.create '+address_1+'++'+size_1+' '+start+'++'+size_check+'\n')
					file_cmm.write('d.load.binary '+DumpPath+'\\'+value[1]+'  a:'+start+'++'+size_check+' /SKIP '+str(skip)+' /noclear\n\n')
					file_cmm.close()
					return
				return
			start = hex(int(start,16)+int(size_check,16)+1).replace('L','')
	
def CreateCMM(Output,DumpPath,binary_list):
	file = Output + '\\DSP_smmu_pagetables_nonbasic.cmm'
	if os.path.isfile(file):
		f_file = open(file,'r')
		for line in f_file:
			if 'mmu.create' in line:  # line = mmu.create 0xe5500000++0xfffff 0x9800000++0xfffff
				address_1 = line.split( )[1].split('++')[0]
				size_1 = line.split( )[1].split('++')[1]
				address = line.split( )[2].split('++')[0]
				size = line.split( )[2].split('++')[1]
				# print (address_1,size_1,address,size) # 0xe5500000 0xfffff 0x9800000 0xfffff
				GetAddress(Output,address,size,address_1,size_1,DumpPath,binary_list,line)
		f_file.close()
	
	f_out = open(Output + '\\6GB.cmm','w')
	f_out.write('mmu.reset\n')
	f_check = Output + '\\DSP_smmu_pagetables_basic.cmm'
	if os.path.isfile(f_check):  # Copy data from DSP_smmu_pagetables_basic.cmm >> 6GB.cmm
		f_open = open(f_check,'r')
		for line in f_open:
			if 'mmu.create' in line:
				f_out.write(line)
		f_open.close()
	
	f_out1 = open(Output + '\\6GB_Dumps.cmm','w')
	f_check = Output + '\\6GB_Binary_Loading.cmm'
	if os.path.isfile(f_check):  # Copy Data from 6GB_Binary_Loading.cmm >> 6GB.cmm, 6GB_Dumps.cmm
		f_open = open(f_check,'r')
		for line in f_open:
			if 'd.load.binary' in line:
				f_out1.write(line)
				f_out.write(';'+line)
			else:
				f_out.write(line)
		f_open.close()
	
	# f_out.write('mmu.format QURT QURTK_pagetables\n')
	f_out.write('mmu.on\n')
	f_out.write('mmu.autoscan on\n')
	f_out.write('mmu.tablewalk on\n')
	f_out.close()
	f_out1.close()
	
def SortPGTTempXYZ(file):
	f_srt = open(file.replace('.txt','_sort.txt'),'w')
	list = []
	if os.path.isfile(file):
		f_file = open(file,'r')
		for line in f_file:
			list.append(line)
		f_file.close()
	a = []
	for i in range(0,len(list)):
		for j in range(i+1,len(list)):
			temp1 = list[i].split()[1].replace('*','')
			temp2 = list[j].split()[1].replace('*','')
			temp1 = int(temp1,16)
			temp2 = int(temp2,16)
			if temp2 <= temp1:
				a = list[i]
				list[i] = list[j]
				list[j] = a
	for i in range(0,len(list)):
		f_srt.write(str(list[i]))
	f_srt.close()
	
def CheckRangesandClub(file):    
	file_out = file.replace('.txt','_Ranges.txt')
	f_out = open(file_out,'w')
	if os.path.isfile(file):
		f_file = open(file,'r')
		va = None
		pa = None
		size = None
		size_add = None
		for line in f_file:
			list = line.split()
			if va == None and pa == None and size == None:
				va = list[0]+"000"
				pa = list[1].replace('*','')+"000"
				size = list[2].replace('*','')
				size_add = size
			else:
				va_temp = list[0]+"000"
				pa_temp = list[1].replace('*','')+"000"
				size_temp = list[2].replace('*','')
				if int(pa,16) + int(size_add,16) == int(pa_temp,16):
					size_add = str(hex(int(size_add,16) + int(size_temp,16))).replace('L','')
				else:
					f_out.write(va+' -- '+size_add+'          '+pa+' -- '+size_add+'\n')
					va = va_temp
					pa = pa_temp
					size_add = size_temp
		f_file.close()
	f_out.close()
	
def main():
	OutputPath  = sys.argv[1]
	DumpPath    = os.path.dirname(sys.argv[2])
	CurrentDirectory = sys.argv[3]
	targetid = sys.argv[4]
	subsystem = sys.argv[5]
	clara_op=sys.argv[6]
	pgt_file = OutputPath+"\\DSP_pgt_converted.txt"
	new_target_flag=sys.argv[7]
	use_asid_flag=sys.argv[8]
	
	if os.path.isfile(pgt_file):
		f_dsppgt = open(pgt_file,'rU')
		f_bsc = open(OutputPath+"\\6GB_BasicMapping.txt",'w')
		f_nonbsc = open(OutputPath+"\\6GB_NonBasicMapping.txt",'w')
		for line_dsppgt in f_dsppgt:
			if ( line_dsppgt[0:2] == '0x'):
				list_dsppgt = line_dsppgt.split()
				asid = None
				if len(list_dsppgt[1]) > 8:
					asid = str(list_dsppgt[1][1:4])
				if asid == "0x0":
					f_bsc.write(line_dsppgt)
				else:
					f_nonbsc.write(line_dsppgt)
		f_bsc.close()
		f_nonbsc.close()
		f_dsppgt.close()
		
		if use_asid_flag=="True":
			f_nonbsc1 = open(OutputPath+"\\asid_mappings.txt",'r')
			f_nonbsc2 = open(OutputPath+"\\6GB_NonBasicMapping.txt",'w')
			for line_dsppgt in f_nonbsc1:
				f_nonbsc2.write(line_dsppgt)
			f_nonbsc1.close()
			f_nonbsc2.close()
		
	CheckRangesandClub(OutputPath+"\\6GB_BasicMapping.txt")
	CheckRangesandClub(OutputPath+"\\6GB_NonBasicMapping.txt")
	if new_target_flag=="True":
		if clara_op=="False":
			if targetid=='1000':
				command_1 = '''python %s\\ADSP_SMMU_1000_6GB.py %s %s %s %s'''%(CurrentDirectory,OutputPath,'DSP_smmu_pagetables_basic.cmm','6GB_BasicMapping.txt',subsystem)
				os.system(command_1)
				command_2 = '''python %s\\ADSP_SMMU_1000_6GB.py %s %s %s %s'''%(CurrentDirectory,OutputPath,'DSP_smmu_pagetables_nonbasic.cmm','6GB_NonBasicMapping.txt',subsystem)
				os.system(command_2)
			else:
				command_1 = '''python %s\\ADSP_SMMU_Optimized_6GB.py %s %s %s %s %s %s %s'''%(CurrentDirectory,OutputPath,'DSP_smmu_pagetables_basic.cmm','6GB_BasicMapping.txt',subsystem,targetid,new_target_flag)
				os.system(command_1)
				command_2 = '''python %s\\ADSP_SMMU_Optimized_6GB.py %s %s %s %s %s %s %s'''%(CurrentDirectory,OutputPath,'DSP_smmu_pagetables_nonbasic.cmm','6GB_NonBasicMapping.txt',subsystem,targetid,new_target_flag)
				os.system(command_2)
		else:
			command_1 = '''python %s\\clara_SMMU_6GB.py %s %s %s %s %s %s'''%(CurrentDirectory,OutputPath,'DSP_smmu_pagetables_basic.cmm','6GB_BasicMapping.txt',subsystem,targetid)
			os.system(command_1)
			command_2 = '''python %s\\clara_SMMU_6GB.py %s %s %s %s %s %s'''%(CurrentDirectory,OutputPath,'DSP_smmu_pagetables_nonbasic.cmm','6GB_NonBasicMapping.txt',subsystem,targetid)
			os.system(command_2)
	else:
		command_1 = '''python %s\\ADSP_SMMU_8996_6GB.py %s %s %s'''%(CurrentDirectory,OutputPath,'DSP_smmu_pagetables_basic.cmm','6GB_BasicMapping.txt')
		os.system(command_1)
		command_2 = '''python %s\\ADSP_SMMU_8996_6GB.py %s %s %s'''%(CurrentDirectory,OutputPath,'DSP_smmu_pagetables_nonbasic.cmm','6GB_NonBasicMapping.txt')
		os.system(command_2)
	f_bin = open(OutputPath+"\\ProcessingCommands.txt",'a')
	f_bin.write(str(command_1)+'\n')
	f_bin.write(str(command_2)+'\n')
	f_bin.close()
	binary_list = CheckLoadCMM(DumpPath)
	CreateCMM(OutputPath,DumpPath,binary_list)
	
	while True:
		if os.path.isfile(OutputPath + '\\6GB_Dumps.cmm'):
			try:
				f_out1 = open(OutputPath + '\\6GB_Dumps.cmm','r')
				line_list = f_out1.readlines()
				final_line = []
				final_line.append("area.create SMMU_Loading")
				final_line.append("area.view SMMU_Loading")
				final_line.append("area.select SMMU_Loading")
				final_line.append('print "Total # of Binary need to load : '+str(len(line_list))+'"')
				temp_var = 1
				for temp_line in line_list:
					final_line.append('print "Loading '+str(temp_var)+'/'+str(len(line_list))+'"')
					final_line.append(temp_line.split('\n')[0])
					temp_var += 1
				final_line.append("WINClear TOP")
				outfile = open(OutputPath + '\\6GB_Dumps.cmm', 'w')
				outfile.write("\n".join(final_line))
				outfile.close()
			except:
				break
		break
	
if __name__ == '__main__':
	main()
