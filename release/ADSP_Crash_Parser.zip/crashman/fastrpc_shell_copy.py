# ------------------------------------------------------------------
#
# Copyright (c) 2019-2020 Qualcomm Technologies, Inc.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
# ------------------------------------------------------------------

import os
import re
import shutil
import sys

src_file= sys.argv[1]
name= sys.argv[2]
res = sys.argv[3]
#print (name.split('0x')[0])
#print (name.split('0x')[1])
# src_file= "\\\\chronicle\\zipbuild236\\PROD\\ADSP.8996.2.7.1.c3-00011-00121-1\\adsp_proc\\build\\bsp\\fastrpc_shell_img\\build\\AAAAAAAA\\fastrpc_shell_0.unstripped"
# name="ASID"
# res= "C:\\Temp\\Crashman_09_06_13h3m1s\\Logs\\temp"

def main():
    if os.path.exists(src_file):
        shutil.copy2(src_file, res)

    if os.path.exists(res+"/fastrpc_shell_0.unstripped"):
        #os.rename(res+"/fastrpc_shell_0.unstripped", res+"/fastrpc_shell_0"+name.split('0x')[1]+".unstripped")
        os.rename(res+"/fastrpc_shell_0.unstripped", res+"/fastrpc_shell_0_"+name+".unstripped")

    if os.path.exists(res+"/fastrpc_shell_3.unstripped"):
        #os.rename(res+"/fastrpc_shell_3.unstripped", res+"/fastrpc_shell_3"+name.split('0x')[1]+".unstripped")
        os.rename(res+"/fastrpc_shell_3.unstripped", res+"/fastrpc_shell_3_"+name+".unstripped")

    if os.path.exists(res+"/fastrpc_shell_2.unstripped"):
        #os.rename(res+"/fastrpc_shell_3.unstripped", res+"/fastrpc_shell_3"+name.split('0x')[1]+".unstripped")
        os.rename(res+"/fastrpc_shell_2.unstripped", res+"/fastrpc_shell_2_"+name+".unstripped")

    if os.path.exists(res+"/fastrpc_shell_0.unstripped"):
        #os.rename(res+"/fastrpc_shell_0.unstripped", res+"/fastrpc_shell_0"+name.split('0x')[1]+".unstripped")
        os.rename(res+"/fastrpc_shell_0.unstripped", res+"/fastrpc_shell_0_"+name+".unstripped")

    if os.path.exists(res+"/fastrpc_shell_unsigned_3.unstripped"):
        #os.rename(res+"/fastrpc_shell_3.unstripped", res+"/fastrpc_shell_3"+name.split('0x')[1]+".unstripped")
        os.rename(res+"/fastrpc_shell_unsigned_3.unstripped", res+"/fastrpc_shell_unsigned_3_"+name+".unstripped")

    if os.path.exists(res+"/fastrpc_shell_unsigned_0.unstripped"):
        os.rename(res+"/fastrpc_shell_unsigned_0.unstripped", res+"/fastrpc_shell_unsigned_0_"+name+".unstripped")
    if os.path.exists(res+"/fastrpc_shell_2.unstripped"):
        #os.rename(res+"/fastrpc_shell_3.unstripped", res+"/fastrpc_shell_3"+name.split('0x')[1]+".unstripped")
        os.rename(res+"/fastrpc_shell_2.unstripped", res+"/fastrpc_shell_2_"+name+".unstripped")
    
if __name__ == '__main__':
  main()

