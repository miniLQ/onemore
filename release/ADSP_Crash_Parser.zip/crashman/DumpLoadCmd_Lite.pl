# ------------------------------------------------------------------
#
# Copyright (c) 2019-2020 Qualcomm Technologies, Inc.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
# ------------------------------------------------------------------

#!perl.exe 

$oppath=$ARGV[0];
print"\n$oppath\n";
$target=$ARGV[1];
$ramdump=$ARGV[2];
$crmbuild=$ARGV[3];
$customerelf=$ARGV[4];
$BinaryLength=$ARGV[5];
$adspstartadd=$ARGV[6];
$choice=$ARGV[7];
$DumpCheckFlag=$ARGV[8];
$Check=$ARGV[9];
$subsystem=$ARGV[10];
$guest_os=$ARGV[11];
$align=$ARGV[12];
$title=$ARGV[13];
$selected_cpu_version=$ARGV[14];
$d_load_binary_file_block_size_cdsp_flag=$ARGV[15];
$new_target_flag=$ARGV[16];
$crashman_logs_path=$ARGV[17];
$qurt_model_t32_path=$ARGV[18];
$CurrentDirectory=$ARGV[19];
$Qube_va_guestos_initialize=$ARGV[20];
$add_mmu_create_initialize=$ARGV[21];

open (OUTFILE, ">$oppath\\..\\adspcrashman_click\.bat") or die " cant open output file: $!\n";
print OUTFILE ("\@echo off\n");
print OUTFILE ("if not exist $CurrentDirectory\\adspcrashman_dumps.bat (\n");
print OUTFILE ("if not exist $crmbuild\\qdsp6\\scripts\\Crashman\\adspcrashman_dumps.bat (\n");
print OUTFILE ("    echo \"Please update crashman scripts\"\n");
print OUTFILE ("    pause\n");
print OUTFILE (") else (\n");
print OUTFILE ("    pushd $crmbuild\\qdsp6\\scripts\\Crashman\n");
if($Check=="0")
{
print OUTFILE ("    adspcrashman_dumps.bat $target $ramdump C\:\\Crashman_Temp $crmbuild $crmbuild\\build\\ms $BinaryLength $adspstartadd $choice $DumpCheckFlag $subsystem $guest_os $align $title $selected_cpu_version $d_load_binary_file_block_size_cdsp_flag $new_target_flag $crashman_logs_path $qurt_model_t32_path $Qube_va_guestos_initialize $add_mmu_create_initialize\n");
}
else
{
print OUTFILE ("    adspcrashman_dumps.bat $target $ramdump C\:\\Crashman_Temp $crmbuild $customerelf $BinaryLength $adspstartadd $choice $DumpCheckFlag $subsystem $guest_os $align $title $selected_cpu_version $d_load_binary_file_block_size_cdsp_flag $new_target_flag $crashman_logs_path $qurt_model_t32_path $Qube_va_guestos_initialize $add_mmu_create_initialize\n");
}
print OUTFILE ("    pause\n");
print OUTFILE (")\n");
print OUTFILE (") else (\n");
print OUTFILE ("    pushd $CurrentDirectory \n");
if($Check=="0")
{
print OUTFILE ("    adspcrashman_dumps.bat $target $ramdump C\:\\Crashman_Temp $crmbuild $crmbuild\\build\\ms $BinaryLength $adspstartadd $choice $DumpCheckFlag $subsystem $guest_os $align $title $selected_cpu_version $d_load_binary_file_block_size_cdsp_flag $new_target_flag $crashman_logs_path $qurt_model_t32_path $Qube_va_guestos_initialize $add_mmu_create_initialize\n");
}
else
{
print OUTFILE ("    adspcrashman_dumps.bat $target $ramdump C\:\\Crashman_Temp $crmbuild $customerelf $BinaryLength $adspstartadd $choice $DumpCheckFlag $subsystem $guest_os $align $title $selected_cpu_version $d_load_binary_file_block_size_cdsp_flag $new_target_flag $crashman_logs_path $qurt_model_t32_path $Qube_va_guestos_initialize $add_mmu_create_initialize\n");
}
print OUTFILE ("    pause\n");
print OUTFILE (")\n");
close(OUTFILE);