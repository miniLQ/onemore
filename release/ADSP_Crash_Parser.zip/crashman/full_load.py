# ------------------------------------------------------------------
#
# Copyright (c) 2019-2020 Qualcomm Technologies, Inc.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
# ------------------------------------------------------------------

import sys
import os
import re
filename=sys.argv[1]
current_dir=sys.argv[2]
file = open(filename,'rb')
file_1= open (current_dir+"\\load_new.cmm",'a')
for line in file:
    if "d.load.binary" in line:
         size=line.split(' ')[4]
         size=int(size,16)
         print (size)
         if size<4294967296:
             file_1.write("if OS.FILE("+line.split(' ')[3]+")")
             file_1.write("\n(\n")
             file_1.write(line)
             file_1.write(")\n")