import os
import sys
import re


unique_file_id = 0 #using this to append to html object ids
                    #to differentiate any file with same name


files_to_display = ["all_thread_callstack.txt","servreg.txt","ProcessingCommands.txt","AudioPDDynnamicLoading.txt","icache_dump.txt","icache_logs.txt","soaddress.txt","ukernel_tstmp.txt",
"SWFatal_Error.txt","NOCInfo.txt","dsp_pgt.txt","dsp_pgt_converted.txt","err_fatal_params.txt","err_qdi_internal.txt","TimestampExtractedData.txt","TimestampResult.txt","pagetables.cmm",
"memheap_section.txt","dsp_DB.txt","dsp_FT.txt","dsp_IN.txt","dsp_MB.txt","dsp_MB_formatted.txt","dsp_MM.txt","dsp_mmu.txt","dsp_QT.txt","dsp_qurt_status.txt","dsp_ST.txt","island_debug.txt",
"qurtos_gen_heap_ptr_MemBlkList.txt","qurtos_gen_heap_ptr_MemCost.txt","qurtos_heap_stat.txt","qurtos_heap_struct_MemBlkList.txt","Qurt_Error_Info.txt","APPS.txt","APPS_ROOT.txt","modem.txt",
"modem_root.txt","Crashman_Log.txt","DSPAnalysis.txt","DynamicSoLoaded.txt","DynSoFile.txt","fprc_shell_names.txt","Heap_Analysis_GuestOS.txt","Heap_stat.txt","Heap_Analysis_Sensors.txt",
"Heap_Analysis_Audio.txt","Heap_Analysis_Charger.txt","Heap_Analysis_Audio_Island.txt","_f3log.txt","adsppm_agg.","adsppm_dump","dcvs_client_dump.txt"] 

dirs_to_display = [] #we will build a list in build_dir_list for folders needed to be displayed
files_list = []#we traverse through all files across folder and have a list handy with IDs created
                #IDs are imperative so these can be later used to control visibility of div blocks

def unique_id():
    global unique_file_id
    unique_file_id = unique_file_id + 1
    return unique_file_id

def update_header():
    
    f_html.write(
        '''
        <!DOCTYPE html>
    <html>
    <head>
        <meta charset='utf-8'>
        <meta http-equiv='X-UA-Compatible' content='IE=edge'>
        <title>Crashman Report</title>
        <meta name='viewport' content='width=device-width, initial-scale=1'>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <script src="https://code.jquery.com/jquery-3.6.1.js" integrity="sha256-3zlB5s2uwoUzrXK3BT7AX3FyvojsraNFxCc2vC/7pNI=" crossorigin="anonymous">
        </script>
        

    <style>
        html,body{
            height:100%;
        }
        .inner {
            margin-left: 20px;
            overflow:auto;
            width:90%;
        }
        .file {
            color:white;
        }
        .folder {
            color:black;
        }
        #complete_report{
            height:100%;
            width:100%;
            display:flex;
        }
        #folder_display{
            height:100%;
            width:max(15%,350px);
            position:relative;
            overflow:auto;
            background-color: #4474c2;
        }
        #file_display{
            width:100%;
            height:97%;
            background-color: #ECF0F1;
            overflow:auto;
            padding: 10px;
            
        }
        .fa.fa-plus-circle,.fa.fa-minus-circle{
            font-size:12px;
            padding-right:2px;
            float:left;
        }
        #file_heading{
            display: flex;
            justify-content: center;
            align-content: center;
            flex-direction: column;
            width:100%;
            height:3%;
           overflow:hidden;
           position:relative;
           text-align:center;
           background-color:#c9c7c1;
        }
        #content_display{
            display:flex;
            flex-direction:column;
            width:100%;
        }
        h6{
            cursor: pointer;
        }

    </style>
    </head>
    <body>'''
    )

def get_js_control():
    return '''<script>
                    //jquery doesn't support id with periods, so escaping them
                    function escape_id(_id){
                        _id = _id.replace(/\./g,'\\\\.');
                        _id = _id.replace(/\ /g,'\\\\ ');
                        return _id;
                    }
                    function toggle_visibility(_id){
                        _id = escape_id(_id); 
                        console.log("after calling"+_id);
                        if ($("#"+_id).css('display') == 'none'){
                            $("#"+_id).css('display','block');
                            console.log("enter show()");
                        }else{
                            $("#"+_id).css('display','none');
                            console.log("enter hide()");
                        }
                    }

                    function folder_handling(object){
                        _id = object.text()+"_"+object.attr('id');
                        console.log('clicked on '+_id);
                        toggle_visibility(_id)
                    }

                    $(".folder").on('dblclick',function(){
                        console.log("clicked on folder");
                        _i = $(this).closest('div').find('i')
                        _h = $(this)
                        folder_handling(_h);
                        _i.toggleClass('fa fa-plus-circle')
                        _i.toggleClass('fa fa-minus-circle')

                    })

                    //folder handling for when + icon is pressed
                    $("#folder_display").on('click','i',function(){
                        console.log("clicked on folder");
                        _i = $(this)
                        _h = $(this).closest('div').find('h6')
                        folder_handling(_h);
                        _i.toggleClass('fa fa-plus-circle')
                        _i.toggleClass('fa fa-minus-circle')
                    })

                    $(".file").on('click',function(){
                        console.log("clicked on file");
                        $("#file_heading").find('h6').html($(this).text())
                        _id = $(this).text()+"_"+$(this).attr('id');
                        console.log('clicked on '+_id);
                        $("#file_display").children('div').hide();
                        toggle_visibility(_id);
                    })

                    $("#collapse").on('click',function(){
                        console.log("collapsing");
                        _span = $(this).find('span')
                        _span.toggleClass('glyphicon glyphicon-menu-left')
                        _span.toggleClass('glyphicon glyphicon-menu-right')
                        $("#folder_display").toggle()

                    })

                
        </script>'''
     
def update_footer():
    _js = get_js_control()

    f_html.write(_js)
    f_html.write('''
    </body>
    </html>
    ''')

def display_file(file_path):
    for f in files_to_display:
        if f.lower() in file_path.lower():
            return True
    return False

def is_ulog(file):
    return ".ulog" in file

def recursive_folder_building(folder,num):
    if folder.name.lower() not in dirs_to_display:
        return

    _id = str(unique_id())
    #f_html.write('<div style="display:flex;flex-direction:column">')
    if folder.name.lower()=="logs":
        f_html.write('<div ><span ><i class="fa fa-minus-circle"></i><h6 class="folder" id ='+_id+' >'+folder.name+'</h6></span></div>')
        f_html.write('<div class="inner" id="'+folder.name+"_"+_id+'" >')
    else:
        f_html.write('<div  ><span ><i class="fa fa-plus-circle"></i><h6 class="folder" id ='+_id+' >'+folder.name+'</h6></span></div>')
        f_html.write('<div class="inner" id="'+folder.name+"_"+_id+'" style="display:none">')

    dirs, files  = [], []
    for _f in os.scandir(folder.path):
        if _f.is_file():
            files.append(_f.name)
        if _f.is_dir():
            dirs.append(_f)
    
    for dir in dirs:
        recursive_folder_building(dir,num+2)
    
    for file in files:

        if not display_file(file) and not is_ulog((file)):
            continue
        if ".bin" in file:
            continue
        _name = file.split(".txt")[0]
        _name = _name.split(".ulog")[0]
        _id = str(unique_id())
        f_html.write('<h6 class="file" id ='+_id+' >'+_name+'</h6>')
        files_list.append([os.path.join(*[folder.path,file]),_name,_id]) #mapping file name with IDs of h6 tag so these
                                                                             #can be used later for control visibility of files

    f_html.write('</div>')
    #f_html.write('</div>')



def file_building():

    for [file_path,name,id] in files_list:
        id = name+"_"+id
        if "dspanalysis.txt" in file_path.lower():
            f_html.write('<div id="'+id+'" style="display:block;height:100%" >')
        else:
            f_html.write('<div id="'+id+'" style="display:none;height:100%" >')
        #f_html.write('<object  data='+file_path+'></object>')
        f = open(file_path,'r',errors = "ignore")
        f_html.write('<pre style="word-wrap: break-word; white-space: pre-wrap;">'+f.read()+'</prev>')
        # for line in f.readlines():
        #     is_line_writable = False
        #     for each_char in line:
        #         if each_char!=" " and each_char!='\n':
        #             is_line_writable = True
        #     if is_line_writable:
        #         f_html.write('<p  >'+line.replace('&','&amp;').replace('<','&lt;').replace('>','&gt;').replace('"','&quot;').replace("'",'&apos;')+'</p>\n')

        f_html.write('</div>')
    
def build_dir_list(folder):
    
    _file_count = 0
    for _f in os.scandir(folder):
        if _f.is_file() and (display_file(_f.name) or is_ulog(_f.name)):
            _file_count = _file_count + 1
        if _f.is_dir():
            if build_dir_list(_f.path):
                dirs_to_display.append(_f.name.lower())

    return _file_count


if __name__ =="__main__":
    global f_html
    asha_folder = ""
    
    try:
        asha_folder = sys.argv[1]
    except:
        print("Please provide asha folder\n")
        sys.exit()

    title = ""
    try:
        title = sys.argv[2]
    except:
        pass

    if not title:
        for jira_id in asha_folder.split('\\'):
            if 'QSTABILITY' in jira_id or 'ADSPIMAGE' in jira_id:
                title = jira_id.split('/')[0]


    f_html = open(os.path.join(*[asha_folder,'Logs',title+"crashman_report.html"]),'w')
    
    
    build_dir_list(asha_folder)
    #print(dirs_to_display)
    update_header()

    f_html.write('<div id = "complete_report" >')
    if True: # folder structure
        f_html.write('<div id="folder_display" >')
        for dir in os.scandir(asha_folder):
            if "logs" in (dir.name).lower():
                recursive_folder_building(dir,0)
        f_html.write('</div>')

    if True: #bulding collapsible option for above display
        f_html.write('<div id="collapse" style="background-color:#8aaceb;display:flex;align-items:center;justify-content:center;width:max(1%,15px);height:100%">')
        f_html.write('<div>')
        f_html.write('<span class="glyphicon glyphicon-menu-left"></span>')
        f_html.write('</div>')
        f_html.write('</div>')


    if True: #file heading and display
        f_html.write('<div  id="content_display" >')
        f_html.write('<div id="file_heading" >')
        f_html.write('<h6>DSPAnalysis</h6>')
        f_html.write('</div>')



        f_html.write('<div  id="file_display" >')
        file_building()
        f_html.write('</div>')
        f_html.write('</div>')
    f_html.write('</div>')




    update_footer()



                    

