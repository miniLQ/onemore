# ------------------------------------------------------------------
#
# Copyright (c) 2019-2020 Qualcomm Technologies, Inc.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
# ------------------------------------------------------------------

import os
import sys


try:
	OutputPath_temp  = sys.argv[1]
	current_dir  = sys.argv[2]
	callstack_flag  = sys.argv[3]
	subsys = sys.argv[4]
	cmm=OutputPath_temp+"/thread_callstack/collect_thread_callstack.cmm"
	f_cmm = open(cmm,'w+')
	f_cmm.write("printer.file "+OutputPath_temp+"/thread_callstack/thread000_callstack.txt\n")
	f_cmm.write("printer.filetype ascii\n")
	f_cmm.write("printer.size 0xfa,0xfa\n")
	if callstack_flag=='0x1': f_cmm.write("ON TIME 1.0s GOTO timeout1\n")
	f_cmm.write("wp.v.f /CORE 0\n")
	if callstack_flag=='0x1': f_cmm.write("timeout1:\n")
	if callstack_flag=='0x1': f_cmm.write("ON TIME 1.0s GOTO timeout2\n")
	f_cmm.write("wp.v.f /CORE 1\n")
	if callstack_flag=='0x1': f_cmm.write("timeout2:\n")
	if callstack_flag=='0x1': f_cmm.write("ON TIME 1.0s GOTO timeout3\n")	
	f_cmm.write("wp.v.f /CORE 2\n")
	if callstack_flag=='0x1': f_cmm.write("timeout3:\n")
	if callstack_flag=='0x1': f_cmm.write("ON TIME 1.0s GOTO timeout4\n")	
	f_cmm.write("wp.v.f /CORE 3\n")
	if callstack_flag=='0x1': f_cmm.write("timeout4:\n")
	qurt_file = OutputPath_temp.split('temp')[0]+'Qurt_logs/dsp_QT.txt'
	if os.path.exists(qurt_file): 
		file_ptr = open(qurt_file,'r')
		line_list = file_ptr.readlines()
		address_list = []
		for cnt in range(2,len(line_list)):
			if line_list[cnt].split(' ')[0].strip() == '': continue
			address_list.append(line_list[cnt].split(' ')[0].strip())
			if callstack_flag=='0x1': f_cmm.write("ON TIME 1.0s GOTO "+line_list[cnt].split(' ')[0].strip()+"\n")
			f_cmm.write("Area.Clear q6_sw\n")
			if subsys == "slpi" or subsys == "adsp":
				f_cmm.write("do "+current_dir+"/q6_stack_walker_restore_to_original_LR_from_framekey.cmm 0x"+line_list[cnt].split(' ')[0].strip()+"\n")
			else:
				f_cmm.write("do "+current_dir+"/q6_stack_walker.cmm 0x"+line_list[cnt].split(' ')[0].strip()+"\n")
			f_cmm.write("wp.Area q6_sw\n")
			# f_cmm.write("Area.Clear q6_sw\n")
			f_cmm.write("winclear TOP\n")
			if callstack_flag=='0x1': f_cmm.write(line_list[cnt].split(' ')[0].strip()+":\n")
	f_cmm.write("printer.file.close\n")
	f_cmm.close()
except:
	print ('Error arised')

