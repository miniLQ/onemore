import sys
import binascii
import glob
import os
import datetime

arg1 = sys.argv[1]
arg2 = sys.argv[2]



_range = 45 #the timestamp for pd dump can't be more than this offset
            #compared to image dump to be considered for pd dump loading

headers = []

log_file = open(arg2+r"/ssr.txt",'w')

elf = {
    "32":{
        "e_phoff"     :{"offset":"0x1C","size":4},
        "e_shoff"     :{"offset":"0x20","size":4},
        "e_ehsize"    :{"offset":"0x28","size":2},
        "e_phentsize" :{"offset":"0x2A","size":2},
        "e_phnum"     :{"offset":"0x2C","size":2},
        "e_shentsize" :{"offset":"0x2E","size":2},
        "e_shnum"     :{"offset":"0x30","size":2},
        "e_shstrndx"  :{"offset":"0x32","size":2}    
    },
    "64":{
        "e_phoff"     :{"offset":"0x20","size":8},
        "e_shoff"     :{"offset":"0x28","size":8},
        "e_ehsize"    :{"offset":"0x34","size":2},
        "e_phentsize" :{"offset":"0x36","size":2},
        "e_phnum"     :{"offset":"0x38","size":2},
        "e_shentsize" :{"offset":"0x3A","size":2},
        "e_shnum"     :{"offset":"0x3C","size":2},
        "e_shstrndx"  :{"offset":"0x3E","size":2}
    }
}
ph = {
    "elf32":{
        "p_type"     :{"offset":"0x00","size":4},
        "p_offset"   :{"offset":"0x04","size":4},
        "p_vaddr"    :{"offset":"0x08","size":4},
        "p_paddr"    :{"offset":"0x0C","size":4},
        "p_filesz"   :{"offset":"0x10","size":4},
        "pmemsz"     :{"offset":"0x14","size":4},
        "p_flags"    :{"offset":"0x18","size":4},
        "p_align"    :{"offset":"0x1C","size":4}
    },
    "elf64":{
        "p_type"     :{"offset":"0x00","size":4},
        "p_flag"     :{"offset":"0x04","size":4},
        "p_offset"   :{"offset":"0x08","size":8},
        "p_vaddr"    :{"offset":"0x10","size":8},
        "p_paddr"    :{"offset":"0x18","size":8},
        "p_filesz"   :{"offset":"0x20","size":8},
        "pmemsz"     :{"offset":"0x28","size":8},
        "p_align"    :{"offset":"0x30","size":8}
    }
}

sh = {
    "elf32":{
        "sh_name"    :{"offset":"0x00","size":4},
        "sh_type"    :{"offset":"0x04","size":4},
        "sh_flags"   :{"offset":"0x08","size":4},
        "sh_addr"    :{"offset":"0x0C","size":4},
        "sh_offset"  :{"offset":"0x10","size":4},
        "sh_size"    :{"offset":"0x14","size":4},
        "sh_link"    :{"offset":"0x18","size":4},
        "sh_info"    :{"offset":"0x1C","size":4},
        "sh_addalign":{"offset":"0x20","size":4},
        "sh_entsize" :{"offset":"0x24","size":4},
    },
    "elf64":{
        "sh_name"    :{"offset":"0x00","size":4},
        "sh_type"    :{"offset":"0x04","size":4},
        "sh_flags"   :{"offset":"0x08","size":8},
        "sh_addr"    :{"offset":"0x10","size":8},
        "sh_offset"  :{"offset":"0x18","size":8},
        "sh_size"    :{"offset":"0x20","size":8},
        "sh_link"    :{"offset":"0x28","size":4},
        "sh_info"    :{"offset":"0x2C","size":4},
        "sh_addalign":{"offset":"0x30","size":8},
        "sh_entsize" :{"offset":"0x38","size":8},
    }
}

def time_in_range(start,end,req):
    return start <= req <= end

def _find(_dict,_list,num_bytes):

    start_index = int(int(_dict["offset"],16)/num_bytes)
    start_offset = int(_dict["offset"],16)%num_bytes
    size = _dict["size"]
    end_index = int((int(_dict["offset"],16)+size-1)/num_bytes)
    end_offset = (int(_dict["offset"],16)+size-1)%num_bytes

    if end_index >= len(_list):
        print("offset out of range")
        return ""

    string = ""
    for i in range(start_index,end_index+1,1):
        if start_index == end_index:
            return _list[i][2*start_offset:2*(end_offset+1)]
        if i==start_index:
            string = string + _list[i][2*start_offset:]
        if i==end_index:
            string = string + _list[i][:2*(end_offset+1)]

    return string


def order(s):
    string = ""
    for i in range(0,len(s),2):
        string = s[i:i+2] + string 
    return string


def get_hex(temp):
    return binascii.hexlify(temp).decode('utf-8')

def readelf(file):

    offset_elf_class = 4
    raw_elf_header = []
    raw_section_headers = []
    raw_program_headers = []

    try:
        _file = open(file,'rb') #elf file
    except:
        headers.append("ELF file opening failed")
        return


    _file.seek(offset_elf_class)
    elf_class = order(get_hex(_file.read(1)))
    size_elf32 = 52
    size_elf64 = 64


    if elf_class == '01': #decide other offsets based on elf class

        _file.seek(0)
        table_entries = binascii.hexlify(_file.read(size_elf32)).decode('utf-8')
        for s in range(len(table_entries)):
            if s%8 == 0:
                raw_elf_header.append(table_entries[s:s+8])
        offset_ph = order(_find(elf["32"]["e_phoff"],raw_elf_header,4)) 	#Points to the start of the program header table. It usually follows the file header immediately, making the offset 0x34 or 0x40 for 32- and 64-bit ELF executables, respectively.
        offset_sh = order(_find(elf["32"]["e_shoff"],raw_elf_header,4)) 	#Points to the start of the section header table.
        size_ph =  order(_find(elf["32"]["e_phentsize"],raw_elf_header,4))	#Contains the size of a program header table entry.
        num_ph  =  order(_find(elf["32"]["e_phnum"],raw_elf_header,4))		#Contains the number of entries in the program header table.
        size_sh =  order(_find(elf["32"]["e_shentsize"],raw_elf_header,4))	#Contains the size of a section header table entry.
        num_sh  =  order(_find(elf["32"]["e_shnum"],raw_elf_header,4))	

        if not len(headers):headers.append("0\n")
        _file.seek(int(offset_ph,16))

        for i in range(int(num_ph,16)):
            table_entries = binascii.hexlify(_file.read(int(size_ph,16))).decode('utf-8')
            temp = []
            for s in range(len(table_entries)):
                if s%16 == 0:
                    temp.append(table_entries[s:s+16])
            raw_program_headers.append(temp)
            headers.append(order(_find(ph["elf32"]["p_vaddr"],temp,8))+";"+order(_find(ph["elf32"]["p_filesz"],temp,8))+";"+order(_find(ph["elf32"]["p_offset"],temp,8))+";"+file+"\n") 
            #print(temp)
        

    elif elf_class == '02':

        _file.seek(0)
        table_entries = binascii.hexlify(_file.read(size_elf64)).decode('utf-8')
        for s in range(len(table_entries)):
            if s%8 == 0:
                raw_elf_header.append(table_entries[s:s+8])
        
        offset_ph = order(_find(elf["64"]["e_phoff"],raw_elf_header,4)) 	#Points to the start of the program header table. It usually follows the file header immediately, making the offset 0x34 or 0x40 for 32- and 64-bit ELF executables, respectively.
        offset_sh = order(_find(elf["64"]["e_shoff"],raw_elf_header,4))	    #Points to the start of the section header table.
        size_ph =  order(_find(elf["64"]["e_phentsize"],raw_elf_header,4))	#Contains the size of a program header table entry.
        num_ph  =  order(_find(elf["64"]["e_phnum"],raw_elf_header,4))		#Contains the number of entries in the program header table.
        size_sh =  order(_find(elf["64"]["e_shentsize"],raw_elf_header,4))	#Contains the size of a section header table entry.
        num_sh  =  order(_find(elf["64"]["e_shnum"],raw_elf_header,4))	


        if(int(num_ph,16)!= 0):
            if not len(headers):headers.append("0\n")
            _file.seek(int(offset_ph,16))

            for i in range(int(num_ph,16)):
                table_entries = binascii.hexlify(_file.read(int(size_ph,16))).decode('utf-8')

                temp = []
                for s in range(len(table_entries)):
                    if s%16 == 0:
                        temp.append(table_entries[s:s+16])
                raw_program_headers.append(temp)
                headers.append(order(_find(ph["elf64"]["p_vaddr"],temp,8))+";"+order(_find(ph["elf64"]["p_filesz"],temp,8))+";"+order(_find(ph["elf64"]["p_offset"],temp,8))+";"+file+"\n") 
                #print(temp)

        elif(int(num_sh,16)!=0):
            if not len(headers):headers.append("1\n")
            _file.seek(int(offset_sh,16))
            for i in range(int(num_sh,16)):
                table_entries = binascii.hexlify(_file.read(int(size_sh,16))).decode('utf-8')
                temp = []
                for s in range(len(table_entries)):
                    if s%16 == 0:
                        temp.append(table_entries[s:s+16])
                raw_section_headers.append(temp)

            #index of string table
            str_table_index = int(order(_find(elf["64"]["e_shstrndx"],raw_elf_header,4)),16)
            #contents from string table
            size_string_table = int(order(_find(sh["elf64"]["sh_size"],raw_section_headers[str_table_index],8)),16)
            section_names = (_file.read(size_string_table)).decode('ascii').split("\x00")
             
            for i in range(len(raw_section_headers)):
                headers.append(order(_find(sh["elf64"]["sh_addr"],raw_section_headers[i],8))+";"+order(_find(sh["elf64"]["sh_size"],raw_section_headers[i],8))+";"+order(_find(sh["elf64"]["sh_offset"],raw_section_headers[i],8))+";"+file+";") 
                headers.append(section_names[i]+"\n")
                #print(temp)


        else:
            headers.append("Something wrong with dump, num(section_headers)==0 & num(program_headers)==0")


def main():
    readelf(arg1)
    #sys.exit() #ignore pd dumps loading issue with elf format
    #pd dump loading
    try:
        look_up = "msm_fastrpc_compute_cb"
        directory = os.path.dirname(arg1)
        #print(directory)
        start_time = datetime.datetime.strptime(" ".join(os.path.splitext(os.path.basename(arg1))[0].split("_")[-2:]),"%Y-%m-%d %H-%M-%S")
        end_time = start_time + datetime.timedelta(seconds=_range)
        list_of_pd_dumps = [file for file in glob.glob(directory+"\*.elf") if look_up in file] 
        #print(list_of_pd_dumps)       
        for file in list_of_pd_dumps:
            pd_file_timestamp = datetime.datetime.strptime(" ".join(os.path.splitext(os.path.basename(file))[0].split("_")[-2:]),"%Y-%m-%d %H-%M-%S")
            if time_in_range(start_time,end_time,pd_file_timestamp):
                readelf(file)
    except:
        pass

    log_file.writelines(headers)
    

    
if __name__ == "__main__":
    main()