from __future__ import print_function

# ------------------------------------------------------------------
#
# Copyright (c) 2019-2020 Qualcomm Technologies, Inc.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
# ------------------------------------------------------------------

def write_command_into_file(rcvd_cmd):
	bin = OUTDumpPath+"/temp/ProcessingCommands.txt"
	f_bin = open(bin,'a')
	f_bin.write(str(rcvd_cmd)+'\n')
	f_bin.close()
	
while True:  ## Importing require Module
	import convert
	import socket
	import os
	import sys
	import subprocess
	import datetime
	import time
	import re
	import fnmatch
	import shutil, errno
	import binascii
	import threading
	from os import walk
	import glob
	import platform
	import argparse
	from argparse import RawTextHelpFormatter
	break
	
while True:  ## Initializing all Variable
	possible_dump_name=["DDRCS0.BIN","DDRCS1.BIN","DDRCS0_0.BIN","DDRCS0_1.BIN","DDRCS0_2.BIN","DDRCS0_3.BIN","DDRCS0_4.BIN","DDRCS0_5.BIN","DDRCS0_6.BIN","DDRCS1_0.BIN","DDRCS1_1.BIN","DDRCS1_2.BIN","DDRCS2_0.BIN","DDRCS2_1.BIN","ADSP0.bin","EBICS0.RAM","dram_cs0_0x80000000--0xffffffff.lst","dram_cs0_0x080000000--0x0ffffffff.lst","dram_0x80000000--0xffffffff.lst","dram_cs1_0x140000000--0x1bfffffff.lst","dram_cs0_0x100000000--0x13fffffff.lst","dram_cs1_0x1c0000000--0x1ffffffff.lst","dram1_0x100000000--0x17fffffff.lst","dram_0x40000000--0xffffffff.lst","dram1_0x100000000--0x1bfffffff.lst","dram_cs0_0x100000000--0x17fffffff.lst","dram_cs0_0x100000000--0x17fffffff.lst","dram_cs0_0x180000000--0x1ffffffff.lst","dram_cs1_0x180000000--0x1ffffffff.lst","dram_cs1_0x200000000--0x27fffffff.lst","adsp_dump.bin","dram_cs1_0x100000000--0x17fffffff.lst","dram_cs1_0x800000000--0x87fffffff.lst","dram_cs1_0x880000000--0x8ffffffff.lst","dram_cs2_0x880000000--0x8ffffffff.lst","dram_cs2_0x900000000--0x97fffffff.lst","dram_cs1_0x900000000--0x97fffffff.lst"]
	
	possible_elf_names = {
		"adsp"  : { 
					"adsp" : [		'ROOT_Target_ID.adsp.VARIANTQ.elf',
									'UKERNEL_Target_ID.adsp.VARIANTQ.elf',
									'AUDIO_Target_ID.adsp.VARIANTQ.elf',
									'SENSOR_Target_ID.adsp.VARIANTQ.elf',
									'CHARGER_Target_ID.adsp.VARIANTQ.elf'],
					"adsp_au" : [
									'ROOT_Target_ID.adsp_au.VARIANTQ.elf',
									'AUDIO_Target_ID.adsp_au.VARIANTQ.elf',
									'UKERNEL_Target_ID.adsp_au.VARIANTQ.elf',
									'SENSOR_Target_ID.adsp_au.VARIANTQ.elf'],
					"adsp2"  : [
									'ROOT_Target_ID.adsp2.VARIANTQ.elf',
									'AUDIO_Target_ID.adsp2.VARIANTQ.elf',
									'SENSOR_Target_ID.adsp2.VARIANTQ.elf',
									'UKERNEL_Target_ID.adsp2.VARIANTQ.elf',
									'CHARGER_Target_ID.adsp2.VARIANTQ.elf'],
					"adsp_iot"  : [
									'ROOT_Target_ID.adsp_iot.VARIANTQ.elf',
									'AUDIO_Target_ID.adsp_iot.VARIANTQ.elf',
									'SENSOR_Target_ID.adsp_iot.VARIANTQ.elf',
									'UKERNEL_Target_ID.adsp_iot.VARIANTQ.elf',
									'CHARGER_Target_ID.adsp_iot.VARIANTQ.elf'],
					"adsp_slate" : [
									'ROOT_Target_ID.adsp_slate.VARIANTQ.elf',
									'SENSOR_Target_ID.adsp_slate.VARIANTQ.elf',
									'AUDIO_Target_ID.adsp_slate.VARIANTQ.elf'],
					"adsp_la" : [
									'ROOT_Target_ID.adsp_la.VARIANTQ.elf',
									'UKERNEL_Target_ID.adsp_la.VARIANTQ.elf',
									'AUDIO_Target_ID.adsp_la.VARIANTQ.elf',
									'SENSOR_Target_ID.adsp_la.VARIANTQ.elf',
									'CHARGER_Target_ID.adsp_la.VARIANTQ.elf'],
					"adsp_la2" : [
									'ROOT_Target_ID.adsp_la2.VARIANTQ.elf',
									'UKERNEL_Target_ID.adsp_la2.VARIANTQ.elf',
									'AUDIO_Target_ID.adsp_la2.VARIANTQ.elf',
									'SENSOR_Target_ID.adsp_la2.VARIANTQ.elf',
									'CHARGER_Target_ID.adsp_la2.VARIANTQ.elf'],
					"rennell_adsp" : [
									'ROOT_rennell.adsp.isvQ.elf',
									'AUDIO_rennell.adsp.isvQ.elf',
									'SENSOR_rennell.adsp.isvQ.elf'],
					"old_adsp" : [
									'MTarget_IDAAAAAAAAQ1234.elf',
									'MTarget_IDAAAAAAAAQ1234_SENSOR.elf',
									'MTarget_IDAAAAAAAAQ1234_AUDIO.elf'
								]
		},
		"cdsp"  : {
					"cdsp" : [	'ROOT_Target_ID.cdsp.VARIANTQ.elf',
								'UKERNEL_Target_ID.cdsp.VARIANTQ.elf',
								'SECURE_PD_USER_Target_ID.cdsp.VARIANTQ.elf',
								'FACE_CDSP_USER_Target_ID.cdsp.prodQ_FACE.elf',
								'SRM_IMG_Target_ID.cdsp.VARIANTQ.elf',
								'USER_MDF_Target_ID.cdsp.VARIANTQ.elf']
		},
		"slpi"  : {
					"slpi":[
								'ROOT_Target_ID.slpi.VARIANTQ.elf',
								'SENSOR_Target_ID.slpi.VARIANTQ.elf',
								'UKERNEL_Target_ID.slpi.VARIANTQ.elf',
								'USER_MDF_Target_ID.slpi.VARIANTQ.elf'],
					"old0_slpi" : ['MTarget_IDAAAAAAAAQ.elf',
									'MTarget_IDAAAAAAAAQ_SENSOR.elf'],
					"old1_slpi" : ['MTarget_IDAAAAAAAAQ1234.elf',
									'MTarget_IDAAAAAAAAQ1234_SENSOR.elf',],
					"old2_slpi" : [
								'MTarget_IDAAAAAAAAQBuild_ID.elf',
								'MTarget_IDAAAAAAAAQBuild_ID_SENSOR.elf']
		},
		"gpdsp0": {
					"gpdsp0" :['ROOT_Target_ID.gpdsp0.VARIANTQ.elf',
					'UKERNEL_Target_ID.gpdsp0.VARIANTQ.elf',
					'AUDIO_Target_ID.gpdsp0.VARIANTQ.elf']
					},
		"gpdsp1": { "gpdsp1" :['ROOT_Target_ID.gpdsp1.VARIANTQ.elf',
								'UKERNEL_Target_ID.gpdsp1.VARIANTQ.elf',
								'AUDIO_Target_ID.gpdsp1.VARIANTQ.elf']
					},
		"cdsp0"  : {
					"cdsp0" :[	'ROOT_Target_ID.cdsp0.VARIANTQ.elf',
								'UKERNEL_Target_ID.cdsp0.VARIANTQ.elf',
								'SECURE_PD_USER_Target_ID.cdsp0.VARIANTQ.elf',
								'FACE_CDSP_USER_Target_ID.cdsp0.prodQ_FACE.elf',
								'SRM_IMG_Target_ID.cdsp0.VARIANTQ.elf',
								'USER_MDF_Target_ID.cdsp0.VARIANTQ.elf'],
					"cdsp0_adas":[
							'ROOT_Target_ID.cdsp0_adas.VARIANTQ.elf',
							'UKERNEL_Target_ID.cdsp0_adas.VARIANTQ.elf',
							'SECURE_PD_USER_Target_ID.cdsp0_adas.VARIANTQ.elf']
		},
		"cdsp1"  : {
					"cdsp1":
							['ROOT_Target_ID.cdsp1.VARIANTQ.elf',
							'UKERNEL_Target_ID.cdsp1.VARIANTQ.elf',
							'SECURE_PD_USER_Target_ID.cdsp1.VARIANTQ.elf',
							'FACE_CDSP_USER_Target_ID.cdsp1.prodQ_FACE.elf',
							'SRM_IMG_Target_ID.cdsp1.VARIANTQ.elf',
							'USER_MDF_Target_ID.cdsp1.VARIANTQ.elf']
		}
	}
	possible_elf_file_name_prod_adsp = ['ROOT_Target_ID.adsp.prodQ.elf',
										'UKERNEL_Target_ID.adsp.prodQ.elf',
										'AUDIO_Target_ID.adsp.prodQ.elf',
										'SENSOR_Target_ID.adsp.prodQ.elf',
										'CHARGER_Target_ID.adsp.prodQ.elf',
										'ROOT_Target_ID.adsp_au.prodQ.elf',
										'AUDIO_Target_ID.adsp_au.prodQ.elf',
										'UKERNEL_Target_ID.adsp_au.prodQ.elf',
										'SENSOR_Target_ID.adsp_au.prodQ.elf',
										'ROOT_rennell.adsp.isvQ.elf',
										'AUDIO_rennell.adsp.isvQ.elf',
										'SENSOR_rennell.adsp.isvQ.elf',
										'ROOT_Target_ID.adsp.prod3Q.elf',
										'AUDIO_Target_ID.adsp.prod3Q.elf']
	possible_elf_file_name_prod2_adsp = ['ROOT_Target_ID.adsp.prod2Q.elf',
										'UKERNEL_Target_ID.adsp.prod2Q.elf',
										'SENSOR_Target_ID.adsp.prod2Q.elf',
										'AUDIO_Target_ID.adsp.prod2Q.elf',
										'ROOT_Target_ID.adsp_slate.prodQ.elf',
										'SENSOR_Target_ID.adsp_slate.prodQ.elf',
										'AUDIO_Target_ID.adsp_slate.prodQ.elf',
										'ROOT_Target_ID.adsp2.prodQ.elf',
										'AUDIO_Target_ID.adsp2.prodQ.elf',
										'SENSOR_Target_ID.adsp2.prodQ.elf',
										'UKERNEL_Target_ID.adsp2.prodQ.elf',
										'ROOT_Target_ID.adsp_au.prod2Q.elf',
										'UKERNEL_Target_ID.adsp_au.prod2Q.elf',
										'SENSOR_Target_ID.adsp_au.prod2Q.elf',
										'AUDIO_Target_ID.adsp_au.prod2Q.elf']
	possible_elf_file_name_prod2_cdsp = ['ROOT_Target_ID.cdsp.prod2Q.elf']
	possible_elf_file_name_prod_cdsp = ['ROOT_Target_ID.cdsp.prodQ.elf','UKERNEL_Target_ID.cdsp.prodQ.elf','SECURE_PD_USER_Target_ID.cdsp.prodQ.elf',
										'FACE_CDSP_USER_Target_ID.cdsp.prodQ_FACE.elf','SRM_IMG_Target_ID.cdsp.prodQ.elf','USER_MDF_Target_ID.cdsp.prodQ.elf'
										]
	possible_elf_file_name_prod_slpi = ['MTarget_IDAAAAAAAAQ.elf','MTarget_IDAAAAAAAAQ_SENSOR.elf','ROOT_Target_ID.slpi.prodQ.elf','SENSOR_Target_ID.slpi.prodQ.elf','MTarget_IDAAAAAAAAQ1234.elf','MTarget_IDAAAAAAAAQ1234_SENSOR.elf','UKERNEL_Target_ID.slpi.prodQ.elf','MTarget_IDAAAAAAAAQBuild_ID.elf','MTarget_IDAAAAAAAAQBuild_ID_SENSOR.elf']
	possible_elf_file_name_prod2_slpi = ['ROOT_Target_ID.slpi.prod2Q.elf','AUDIO_Target_ID.slpi.prod2Q.elf','UKERNEL_Target_ID.slpi.prod2Q.elf','USER_MDF_Target_ID.slpi.prod2Q.elf']
	possible_elf_file_name_core_adsp = ['ROOT_Target_ID.adsp.coreQ.elf','UKERNEL_Target_ID.adsp.coreQ.elf','CHARGER_Target_ID.adsp.coreQ.elf','SENSOR_Target_ID.adsp.coreQ.elf','AUDIO_Target_ID.adsp.coreQ.elf','UKERNEL_Target_ID.adsp.coreQ.elf']
	possible_elf_file_name_core_cdsp = ['ROOT_Target_ID.cdsp.coreQ.elf','UKERNEL_Target_ID.cdsp.coreQ.elf','SENSOR_Target_ID.cdsp.coreQ.elf','AUDIO_Target_ID.cdsp.coreQ.elf']
	old_elf_file_name = ['MTarget_IDAAAAAAAAQ1234.elf','MTarget_IDAAAAAAAAQ1234_SENSOR.elf','MTarget_IDAAAAAAAAQ1234_AUDIO.elf']
	
	target_name_posibility = {'8937':['8917','8940','8920','8937'],
							  '439' :['439','SDM439','SDM429','sdm439','sdm429','439ADSP','439adsp','439'],
							  '8953':['450','SDM450','sdm450','632','SDM632','sdm632','8953'],
							  '9x35':['9x35','9635'],
							  '405':['405','QCS405','qcs405','405ADSP','405CDSP','QCS404','Qcs404','qcs404','404','QCS404','QCS403','Qcs403','qcs403','403'],
							  '660':['sdm660','SDM660','660ADSP','660CDSP','sdm630','SDM630','630ADSP','630CDSP','660'],
							  '670':['sdm670','SDM670','670ADSP','670CDSP','710','SDM710','670','sdm710'],
							  '6150':['sm6150','SM6150','6150ADSP','6150CDSP','6150'],
							  '7150':['sm7150','SM7150','7150ADSP','7150CDSP','7150'],
							  '845':['sdm845','SDM845','845ADSP','845CDSP','845'],
							  '855':['sdm855','SDM855','855ADSP','855CDSP','sm8150','8150','855'],
							  '8250':['sm8250','8250ADSP','8250CDSP','8250','KONA','kona','Kona','SM8250'],
							  '1000':['sdm1000','SDM1000','1000ADSP','1000CDSP','1000','poipu','SC8180X','sc8180x'],
							  'nicobar':['nicobar','nicobarADSP','nicobarCDSP'],
							  '8998':['8998'],
							  '8996':['8996'],
							  'saipan':['saipan','saipanADSP','saipanCDSP','SAIPAN','7250'],
							  'rennell':['rennell','rennellADSP','rennellCDSP','SM7125'],
							  '6018':['6018','6018ADSP','6018CDSP','cypress'],
							  'kamorta':['kamorta','kamortaADSP','kamortaCDSP','4250','6115','SM6115'],
							  'mannar':['mannar','mannarADSP','mannarCDSP','4350','SM4350'],
							  'lahaina':['LAHAINA','lahaina','8350','Lahaina','lahainaADSP','lahainaCDSP'],
							  'bitra' : ['BITRA','bitra','6350','bitraADSP','bitraCDSP'],
							  'agatti':['agatti','AGATTI','agattiADSP','agattiCDSP','4125','QCM2290'],
							  'cedros':['cedros','7350'],
							  'makena':['makena','MAKENA','SC8280X','sc8280x'],
							  'waipio':['waipio','WAIPIO','Waipio','8450','SM8450'],
							  'fillmore':['fillmore','FILLMORE'],
							  'kailua':['kailua','KAILUA','8550','SM8550'],
							  'lanai':['lanai','LANAI','8650'],
							  'palawan':['palawan','PALAWAN'],
							  'hamoa':['hamoa',"HAMOA"],
							  'palima':['palima','PALIMA','8475','SM8475'],
							  'tofino':['tofino','TOFINO'],
							  'kodiak':['kodiak','KODIAK','Kodiak','7325','SM7325'],
							  'atherton':['atherton','ATHERTON','Atherton','SW5100','5100'],
							  'strait':['strait','STRAIT','Strait','6375'],
							  'lemans':['lemans','Lemans'],
							  'monaco':['monaco','Monaco'],
							  'halliday':['halliday','Halliday'],
							  'netrani':['netrani','Netrani','SM6450','6450','SM7435','7435'],
							  'clarence':['clarence','CLARENCE','Clarence'],
							  'aurora':['aurora','SXR1230','SX1230','sxr1230','sx1230','AURORA'],
							  'divar' : ['divar','SM6225','6225','Divar','DIVAR'],
							  'camano':['camano','Camano'],
							 }
	md_rodata_txt_removed = {'lanai','palawan'}
	new_target_list = ['670','camano','6150','nicobar','7150','845','405','855','8250','1000','saipan','rennell','6018','kamorta','lahaina','bitra','agatti','mannar','cedros','makena','waipio','fillmore','kailua','kodiak','atherton','strait','divar','palima','lemans','monaco','aurora','netrani','halliday','lanai','palawan','tofino','clarence','hamoa']
	targets_with_addr_sepr_enabled = ['camano','kailua','halliday','aurora','lanai','palawan']#halliday and aurora to be added
	target_with_slpi_flag = ['8996','8998','845','855','8250','1000','lahaina']
	list_of_target_for_which_slpi_flag_need_to_set_true = ['845','405','1000','855','8250','lahaina']
	list_of_target_with_old_elf_file_name = ['8996','9x35','9x25','8976','439','8937','8953','8952','8992','8994','8084','8x10','8x26','8974','8998']
	list_of_target_for_timestamp_matching = ['camano','8250','7150','6150','nicobar','1000','670','855','845','405','660','saipan','rennell','6018','kamorta','lahaina','bitra','kailua','agatti','mannar','cedros','makena','waipio','fillmore','kodiak','atherton','strait','divar','lemans','monaco','aurora','netrani','halliday','lanai','palawan','clarence','hamoa']
	amss_mem_heap_target = ['8952','8976','8953','8937','660','670','439']
	ClockDriver_Script_target = ['670','845','855','nicobar','1000','6150','7150']
	ClockDriver_Script_target = []
	target_for_which_apr_logs_require = ['camano','1000','660', '670', '6150', '7150', 'nicobar', '845', '855', '8250','saipan','rennell','6018','kamorta','lahaina','bitra','agatti','mannar','cedros','makena','waipio','fillmore','kailua','kodiak','strait','divar','atherton','netrani','aurora','halliday','lanai','palawan','clarence','hamoa']
	unstip_fastrpc_module_target = ['camano','6150','7150','8250','saipan','rennell','nicobar','405','670','lahaina','kamorta','bitra','agatti','mannar','cedros','845','makena','660','waipio','fillmore','kailua','kodiak','atherton','strait','divar','lemans','monaco','aurora','netrani','halliday','lanai','palawan','clarence','hamoa']
	ukernel_elf_check = ['camano','lahaina','cedros','waipio','kailua','kodiak','fillmore','netrani','lanai','palawan','clarence','hamoa']
	cpu_version_dict = {'adsp':{'HexagonV56' : ['8994','8992','8952','8953','8937','439','8976'],
								'HexagonV60' : ['8996'],
								'HexagonV62' : ['8998','660','670'],
								'HexagonV65' : ['7150','845'],
								'HexagonV66' : ['6150','nicobar','halliday','855','8250','405','1000','saipan','rennell','6018','kamorta','bitra','agatti','lahaina','mannar','cedros','makena','fillmore','waipio','kodiak','atherton','strait','divar','lemans','monaco','netrani','clarence'],
								'HexagonV73M' : ['camano','kailua','aurora','lanai','palawan','hamoa']
								},
						'slpi':{'HexagonV56' : ['8994','8992','8952','8953','8937','439','8976'],
								'HexagonV60' : ['8996'],
								'HexagonV62' : ['8998','660'],
								'HexagonV65' : ['670','7150','845'],
								'HexagonV66' : ['6150','nicobar','halliday','855','8250','405','1000','saipan','rennell','6018','kamorta','bitra','agatti','lahaina','mannar','cedros','makena','fillmore','waipio','kodiak','atherton','strait','divar','lemans','monaco','netrani'],
								'HexagonV73M' : ['kailua','aurora','lanai','palawan','hamoa','camano']
								},
						'cdsp':{
								'HexagonV56' : ['8994','8992','8952','8953','8937','439','8976'],
								'HexagonV60' : ['8996'],
								'HexagonV62' : ['8998','660'],
								'HexagonV65' : ['670','7150','845'],
								'HexagonV66' : ['6150','nicobar','855','8250','405','1000','saipan','rennell','6018','kamorta','bitra','agatti','mannar','atherton','strait','divar'],
								'HexagonV69':['waipio','fillmore','halliday'],
								'HexagonV73NC_1':['aurora'],
								'HexagonV73ND':['netrani'],
								'HexagonV73NA_1':['camano','kailua','lanai','palawan','hamoa'],
								'HexagonV68':['lahaina','cedros','kodiak','makena']
								},
						'cdsp0':{
								'HexagonV73NA_1':['lemans','monaco'],
								'HexagonV68':['makena']
								},
						'cdsp1':{
								'HexagonV73NA_1':['lemans','monaco'],
								'HexagonV68':['makena']
								},
						'gpdsp0':{
								'HexagonV73GP_1':['lemans','monaco']
								},
						'gpdsp1':{
								'HexagonV73GP_1':['lemans','monaco']
								}
						}
	require_python_iii = ['camano','waipio','kodiak','divar','kailua','fillmore','aurora','netrani','lanai','palawan','clarence','hamoa']
	d_load_binary_file_block_size_adsp = {'0x01800000':['8976','8953','8937','439'],
										  '0x02300000':['8952','845','1000'],
										  '0x02800000':['660','670','6150','7150','855','nicobar','6018','kamorta','agatti','mannar','makena','divar'],
										  '0x01A00000':['405'],
										  '0x02c00000':['8250'],
										  '0x03800000':['saipan','kodiak'],
										  '0x04000000':['bitra','7225','lahaina','rennell','cedros','waipio','kailua','fillmore','lanai','palawan','hamoa','camano'],
										  '0x01C00000':['atherton'],
										  '0x01e00000':['lemans','monaco'],
										  '0x02400000':['netrani','halliday','clarence'],
										  '0x02000000':['strait']
										 }
	d_load_binary_file_block_size_cdsp = {'0x02300000':['855','8250','saipan','rennell','6018','bitra','agatti'],
										  '0x0A00000' :['660','405','1000'],
										  '0x0F00000' :['netrani'],
										  '0x1e00000' :['camano','670','6150','nicobar','7150','845','kamorta','lahaina','mannar','cedros','makena','waipio','fillmore','strait','divar','kailua','aurora','lanai','palawan','hamoa']
										 }
	pram_dump_list = {
		'0x03600000':['bitra','saipan','fillmore','clarence','netrani','aurora','halliday'],
		'0x07800000':['kailua','camano']
	}									
	qurt_model_Qube_va_guestos_dict = { '\\\\ROOT_target_id\\Global\\_start':['670','6150','nicobar','7150','845','405','855','8250','1000','saipan','rennell','6018','kamorta','bitra','agatti','mannar','atherton','strait','divar','lemans','monaco'],
										'start':['8994','8992','8952','8976','8937','439','8998'],
										'\\\\ROOT_target_id\\Global\\start':['660'],
										'\\\\UKERNEL_lahaina\\Global\\_start':['lahaina'],
										'\\\\UKERNEL_cedros\\Global\\_start':['cedros'],
										'\\\\UKERNEL_kodiak\\Global\\_start':['kodiak'],
										'\\\\UKERNEL_makena\\Global\\_start':['makena'],
										'\\\\UKERNEL_waipio\\Global\\_start':['waipio'],
										'\\\\UKERNEL_fillmore\\Global\\_start':['fillmore'],
										'\\\\UKERNEL_lemans\\Global\\_start':['lemans'],
										'\\\\UKERNEL_monaco\\Global\\_start':['monaco'],
										'\\\\UKERNEL_halliday\\Global\\_start':['halliday'],
										'\\\\UKERNEL_netrani\\Global\\_start':['netrani'],
										'\\\\UKERNEL_aurora\\Global\\_start':['aurora'],
										'\\\\UKERNEL_hamoa\\Global\\_start':['hamoa'],
										'\\\\UKERNEL_kailua\\Global\\_start':['kailua'],
										'\\\\UKERNEL_lanai\\Global\\_start':['lanai'],
										'\\\\UKERNEL_palawan\\Global\\_start':['palawan'],
										'\\\\UKERNEL_clarence\\Global\\_start':['clarence'],
										'\\\\UKERNEL_camano\\Global\\_start':['camano'],
									  }
	
	qurt_model_add_variable_dict = {'d.l(qurt_tcm_dump_size)':['670'],
									'0x40000':['6150','nicobar'],
									'0x80000':['7150'],
									'0x100000':['rennell','bitra','mannar','strait'],
									'0x180000':['cedros','kodiak'],
									'd.l(QURTK_tcm_dump_size)':['camano','405','8250','saipan','kamorta','lahaina','agatti','makena','waipio','fillmore','kailua','atherton','divar','netrani','halliday','aurora','lanai','palawan','clarence','hamoa']
									}
	pd_dump_supported = ['camano','waipio','fillmore','kailua','netrani','halliday','aurora','lanai','palawan','clarence','hamoa']
	target_ramparser_id_dict = {'8953': '8937',
								'8998': '8998',
								'8937': '8937',
								'845' : 'sdm845',
								'855' : 'msmnile',
								'6150': 'steppe',
								'1000': 'sdmshrike',
								'670' : 'sdm710',
								'660' : '660',
								'7150': 'steppe',
								'405': 'qcs405',
								'439': 'sdm439',
								'nicobar': 'trinket',
								'8250': 'kona',
								'lahaina': 'lahaina',
								'bitra': 'lagoon',
								'saipan': 'lito',
								'rennell': 'atoll',
								'kamorta': 'bengal',
								'agatti': 'bengal',
								'6018': '8074',
								'mannar':'holi',
								'cedros':'shima',
								'kodiak':'shima',
								'waipio':'taro',
								'kailua':'kalama',
								'fillmore':'diwali',
								'atherton':'monaco',
								'strait':'blair',
								'aurora':'neo',
								'camano':'crow',
								'halliday':'anorak',
								'clarence':'ravelin',
								'lanai':'pineapple',
								'netrani':'parrot',
								'divar':'khaje'
								}
	
	qurt_model_add_variable_dict_old= {'0x40000':['6150'],
									'0x80000':['7150','rennell','bitra'],
									'd.l(QURTK_tcm_dump_size)':['405','8250','saipan','agatti']
									}
	qurt_model_path = ['build/adsp_link/Target_id_temp/install/ADSPv56MP/debugger/T32',
					   'build/adsp_link/qdsp6/405.adsp.prod/install/ADSPv66MP/debugger/T32',
					   'build/adsp_link/qdsp6/kamorta.adsp.prod/install/ADSPv66K_1024/debugger/T32',
					   'build/cdsp_root/qdsp6/nicobar.cdsp.prod/install/computev66/debugger/T32',
					   'osam/build/T32/generic',
					   'build/core_libs/qdsp6/AAAAAAAA/install/ADSPv56MP/debugger/T32',
					   'build/adsp_link/qdsp6/AAAAAAAA/install/ADSPv62MP/debugger/T32',
					   'build/adsp_link/qdsp6/AAAAAAAA/install/ADSPv60MP/debugger/T32',
					   'build/adsp_link/qdsp6/AAAAAAAA/install/ADSPv56MP/debugger/T32',
					   'build/slpi_root/qdsp6/AAAAAAAA/install/sensorsv60_v1/debugger/T32',
					   'build/ssc_slpi_user/qdsp6/AAAAAAAA/install/sensorsv62/debugger/T32',
					   'build/ssc_slpi_user/qdsp6/AAAAAAAA/install/sensorsv60/debugger/T32',
					   'osam/bin/T32/generic',
					   'build/adsp_link/qdsp6/660.adsp.prod/install/ADSPv62MP_SL/debugger/T32',
					   'build/adsp_link/qdsp6/670.adsp.prod/install/ADSPv62MP_SL/debugger/T32',
					   'build/adsp_link/qdsp6/670.adsp.prod/install/ADSPv65MP/debugger/T32',
					   'build/adsp_link/qdsp6/6150.adsp.prod/install/ADSPv62MP_SL/debugger/T32','build/adsp_link/qdsp6/nicobar.adsp.prod/install/ADSPv66K_1024/debugger/T32','build/adsp_link/qdsp6/nicobar.adsp.prod/install/ADSPv66K_512/debugger/T32','build/adsp_link/qdsp6/7150.adsp.prod/install/ADSPv65MP/debugger/T32',
					   'build/cdsp_root/qdsp6/845.cdsp.prod/install/computev65/debugger/T32',
					   'build/cdsp_root/qdsp6/405.cdsp.prod/install/computev66/debugger/T32',
					   'build/cdsp_root/qdsp6/855.cdsp.prod/install/computev65/debugger/T32',
					   'build/cdsp_root/qdsp6/8250.cdsp.prod/install/computev66/debugger/T32']
	break
	
while True:  ## Checking Python and Perl Version

	Crashman_Version = "External_Release_1.53"
	print ("\n************************************")
	print ("*******Crashman Started*************")
	print ("************************************")
	print ("Crashman version          : "+Crashman_Version)

	try:
	   import argparse
	   from argparse import RawTextHelpFormatter
	except ImportError:
	   print ('Python Version is: ' + sys.version)
	   print ('Crashman requires Python version 2.7.6 and above.')
	   print ('If you have Python version 2.7.6 installed, please check the environment path.' )
	   sys.exit()
	if sys.version:
		print ("Python Version Installed  : "+ ((sys.version.rstrip('\n')).split('(default')[0]).split(' ')[0])
		pythonversion = ((sys.version.rstrip('\n')).split('(default')[0]).split(' ')[0]
		if sys.version_info[0] <= 2:
			print ("Python 3 is required for crashman loading..Exiting!!")
			sys.exit()
	else:
	   print ('\n\nERROR: Python not installed!!!')
	   print ('Recommended Python Installation v2.7.8')
	   print ('Crashman tested on Python versions- v2.7.6  v2.5.2  v2.6.2  v2.7.2  v3.0.1  v2.7.6')
	   print ('If installed already, please verify if respective path added to PATH environment variable!!!\n\n')
	   sys.exit()

	break
	
while True:  ## Checking all Input and Validation

	while True: ## Crashman Command flag initializqtion 
		if len(sys.argv) <= 1:
			print ('Enter Proper Command')
			sys.exit()
		usage = "python adspcrashman.py -t[arget] <TARGET> -d[ump] <DumpFile> -o[utput] <Output_Path> -b[uild] <CRM_Buildpath> -e[lf] <CustomerprovidedOBJPath[Optional]>"
		parser = argparse.ArgumentParser(description=usage, formatter_class=RawTextHelpFormatter)  
		parser.add_argument('-target','--target', help='TARGET: ', dest='TARGET', action='store')
		parser.add_argument('-dump','--dump', help="DUMPFILE: Please Provide Proper Dump File Location", dest='DUMPFILE', action='store')
		parser.add_argument('-autoframe','--autoframe',help="to auto frame crashman command", action='store')
		parser.add_argument('-output','--output', help="OUTPUT: Please Provide Proper Output Path Location", dest='OUTPUT', action='store')
		parser.add_argument('-build','--build', help="CRM: Please Provide Proper CRM Build Path Location", dest='BUILD', action='store')
		parser.add_argument('-elf','--elf', default="",help="ELF: Please Provide Proper ELF Path Location", dest='ELF', action='store')
		parser.add_argument('-lite','--lite',help="To Enbale Crashman Lite give -lite or --lite",action='store_true')
		parser.add_argument('-asha','--asha',help="To Enbale Crashman for ASHA give -a or -asha",action='store_true')
		parser.add_argument('-core_elf','--core_elf',help="To Pick core elf give -core_elf",action='store_true') 
		parser.add_argument('-auto_droid','--auto_droid',help="To create crashman folder witout timestamp use -auto_droid",action='store_true')
		parser.add_argument('-manual','--manual',help="To enable Crashman for manual dump loading give -manual",action='store_true')
		parser.add_argument('-use_title','--use_title',help="Give title that you want to display on T32 window",dest='title',action='store')
		parser.add_argument('-frameworktest','--frameworktest',help="for automated testing give -frameworktest or --frameworktest",action='store_true')
		parser.add_argument('-gdb','--gdb',help="To Enbale GDB Simulator give -g or -gdb",action='store_true')
		parser.add_argument('-slpi','--slpi',help="To Enable SLPI for 8996 give -s or -slpi",action='store_true')
		parser.add_argument('-cdsp','--cdsp',help="To Enable CDSP Dumps give -c or -cdsp",action='store_true')
		parser.add_argument('-sofile','--sofile', default="",help="ELF: Please Provide Dynamic so Path Location", dest='SOFILE', action='store')
		parser.add_argument('-fullload','--fullload', default="",help="Full Load: please provide full dump path", dest='FL',action='store')
		parser.add_argument('-smmu32','--smmu32', help="vmlinux 32 bit: Please Provide Proper 32 bit vmlinux Path Location", dest='SMMU32', action='store')
		parser.add_argument('-smmu64','--smmu64', help="vmlinux 64 bit: Please Provide Proper 64 bit vmlinux Path Location", dest='SMMU64', action='store')
		parser.add_argument('-use_t32','--use_t32', help="Please Provide T32 Path Location", dest='trace32', action='store')
		parser.add_argument('-force_hardware','--force_hardware', help="Please Provide target detail", dest='force_HW', action='store')
		parser.add_argument('-load_etm','--load_etm', help="To Enable ETM give -load_etm", action='store_true')
		parser.add_argument('-vmlinux32','--vmlinux32', help="vmlinux 32 bit: Please Provide Proper 32 bit vmlinux Path Location", dest='VMLINUX32', action='store')
		parser.add_argument('-vmlinux64','--vmlinux64', help="vmlinux 64 bit: Please Provide Proper 64 bit vmlinux Path Location", dest='VMLINUX64', action='store')
		parser.add_argument('-frpcshell','--frpcshell', default="",help="Full Load: please provide fast rpc shell name along with path", dest='FRPC',action='store')
		parser.add_argument('-linux_ramdump_parser','--linux_ramdump_parser', help="Linux Ram Dump Parser: Provide linux ram dump parser scripts path", dest='LINUX_RDP', action='store')
		parser.add_argument('-smmuoutput','--smmuoutput', help="Linux Ram Dump Parser: Please Provide extracted SMMU output path", dest='LINUX_SMMU', action='store')
		parser.add_argument('-claraoutput','--claraoutput', help="Linux Ram Dump Parser: Please Provide extracted clara output path", dest='CLARA_SMMU', action='store')
		parser.add_argument('-start_address','--start_address', help='Provide the Start Address', dest='STARTADDR', action='store')
		parser.add_argument('-kaslr-offset','--kaslr-offset', help='Provide the kaslr offset', dest='KASLR', action='store')
		parser.add_argument('-kimage-voffset','--kimage-voffset', help='Provide the kimage voffset', dest='KIMAGE', action='store')
		parser.add_argument('-phys-offset ','--phys-offset ', help='Provide the phys offset', dest='PHYS', action='store')
		parser.add_argument('-wp_smmu','--wp_smmu', help="WP SMMU pagetable path: Please Provide Proper WP SMMU pagetable Path Location", dest='WP_SMMU', action='store')
		parser.add_argument('-use_linux','--use_linux',help="use this to run T32 on linux machines", action='store_true')
		parser.add_argument('-use_cpz','--use_cpz',help="use this to CPZ dumps ", action='store_true')
		parser.add_argument('-audiopddump','--audiopddump',help="to load audio PD dumps", action='store_true')
		parser.add_argument('-sensorpddump','--sensorpddump',help="to load Sensor PD dumps", action='store_true')
		parser.add_argument('-autoscope','--autoscope',help="to parse QURT related logs", action='store_true')
		parser.add_argument('-au','--au',help="Loads auQ ELF's for nightfury target",action='store_true')
		parser.add_argument('-QNX_SMMU','--QNX_SMMU', help="Please provide complete file File Location for QNX SMMU info .txt", dest='QNX_SMMU', action='store')
		parser.add_argument('-ulog','--ulog',help="To not run Ulog script",action='store_true')
		parser.add_argument('-prod2q','--prod2q',help="To load pro2Q elf",action='store_true')
		parser.add_argument('-ssc','--ssc',help="To run ssc_parser",action='store_true')
		parser.add_argument('-sdc','--sdc',help="To load SDC dump",action='store_true')
		parser.add_argument('-nsp1','--nsp1',help="To run ssc_parser",action='store_true')
		parser.add_argument('-use_asids','--use_asids',help="Loads auQ ELF's for nightfury target",action='store_true')
		parser.add_argument('-ss','--ss', help='specify the subsystem needed to load', dest='SS', action='store',choices=['adsp', 'cdsp', 'slpi','cdsp0','cdsp1','gpdsp0','gpdsp1'])
		parser.add_argument('-v','--variant', help='specify the adsp image variant needed to load', dest='variant', action='store',choices=['prod', 'prod2', 'core','au','prod3','charger','dynloading','ois'])
		#parser.add_argument('-unsigned','--unsigned',help="Dumps with virtual address conflict across pds required this, (applicable for full dump loading)",action='store_true')
		parser.add_argument('-addr_sepr_enable','--addr_sepr_enable',help="Enable virtual address separation, for targets that supports",action='store_true')
		opts = parser.parse_args()
		break
	
	while True: ## Collect Input
		start_address = opts.STARTADDR
		if not start_address: start_address = False
		kaslr_offset = opts.KASLR
		if not kaslr_offset: kaslr_offset = False
		smmu_output = opts.LINUX_SMMU
		if not smmu_output: smmu_output = opts.QNX_SMMU
		if not smmu_output: smmu_output = False
		kimage_voffset = opts.KIMAGE
		if not kimage_voffset: kimage_voffset = False
		wp_smmu_enable = opts.WP_SMMU
		if not wp_smmu_enable: wp_smmu_enable = False
		smmu_32bt = opts.SMMU32
		if not smmu_32bt: smmu_32bt=False
		smmu_64bt = opts.SMMU64
		if not smmu_64bt: smmu_64bt=False
		vmlinux_32bt = opts.VMLINUX32
		if not vmlinux_32bt: vmlinux_32bt=False
		vmlinux_64bt = opts.VMLINUX64
		if not vmlinux_64bt: vmlinux_64bt=False
		clara_output = opts.CLARA_SMMU
		if not clara_output: clara_output = False
		force_HW = opts.force_HW
		if not force_HW: force_HW = False
		title = opts.title
		if not title: title = False
		UniqueNumber="NotGiven"
		linux_flag = opts.use_linux
		if platform.system() == 'Linux': linux_flag = True
		crashman_lite = opts.lite
		load_dump_full = opts.FL
		if not load_dump_full: load_dump_full=False
		frpcshell = opts.FRPC
		if not frpcshell: 
			frpcshell_name = False
			frpcshell=False
		if frpcshell:  frpcshell_name = frpcshell.split('/')[-1].split('.')[0]
		crashman_opt = opts.OUTPUT
		if not crashman_opt: 
			crashman_opt = r'C:/Temp'
			if linux_flag:
				if os.path.exists('/local/mnt/workspace'):
					crashman_opt = '/local/mnt/workspace'
				else:
					print ('Please Provide Crashman Output logs Path with Crashman command')
					sys.exit()
		asha_flag = opts.asha
		use_asid_flag = opts.use_asids
		autoscope = opts.autoscope
		quit_flag = opts.frameworktest
		gdb_flag  = opts.gdb
		etm_flag = opts.load_etm
		cpz_flag = opts.use_cpz
		linux_rdp = opts.LINUX_RDP
		smmu_enable=False
		#unsigned = opts.unsigned
		SOFILE = opts.SOFILE
		if not SOFILE: SOFILE=False
		ulog_flag = opts.ulog
		break
	
	while True: ## Set T32 path and ramparse_path
		if crashman_lite!=True:
			tool_version = ''.join(['perl -v'])
			proc = subprocess.Popen(tool_version, stdout=subprocess.PIPE, shell=True)
			(out, err) = proc.communicate()
			if out:
				try:
					if " (v" in str(out.decode()):
						perl_version =  str(out.decode()).split('(')[1].split(')')[0]
					elif "This is perl," in str(out.decode()): 
						perl_version =  str(out.decode()).split('This is perl,')[1].split('built')[0]
					else:
						perl_version = "Untested Perl Version"
					print ("Perl Version Installed    : "+ perl_version)
				except:
					print ("Perl Version Installed    :")
			else:
			   print ('\n\nERROR: Perl not installed!!!')
			   print ('Recommended perl Installation v5.6.1')
			   print ('Crashman tested on Perl versions- v5.10.1 , v5.6.1 , v5.8.7 , v5.12.4 , v5.14.2 ')
			   print ('If installed already, please verify if respective path added to PATH environment variable!!!\n\n')
			   sys.exit()
	
		
		CurrDirectory =  os.path.dirname(os.path.abspath(__file__))
		hostname = socket.getfqdn()
		# hostname = "V10-LV2P22314.na.qualcomm.com"
		if "ap.qualcomm.com" in hostname: hydserver = True
		else: hydserver = False
		t32_loc = opts.trace32
		if not t32_loc: t32_loc=False
		if t32_loc != False:
			if not os.path.exists(t32_loc):
				print (t32_loc+' path not accessible. Please provide valid T32 path')
				sys.exit()
			T32_path = t32_loc
		elif os.path.exists("C:/T32"): T32_path = "C:/T32"
		elif os.path.exists("/opt/t32"): T32_path = "/opt/t32"
		elif os.path.exists("/root/t32"): T32_path = "/root/t32"
		else:
			if hydserver==False and os.path.exists("\\\\hulk\\vocoder_appdsp5\\users\\Crashman\\T32"): T32_path = "\\\\hulk\\vocoder_appdsp5\\users\\Crashman\\T32"
			elif os.path.exists(r"\\hydmmdbld18\Jira_Automation_Tool\Crashman_script\T32_2020"): 
				T32_path = r"\\hydmmdbld18\Jira_Automation_Tool\Crashman_script\T32_2020"
			else:
				print ("\n***********************")
				print ("hydserver : ",hydserver)
				print ("\\\\hydmmdbld18\\Jira_Automation_Tool\\Crashman_script\\T32_2020 or \\\\hulk\\vocoder_appdsp5\\users\\Crashman\\T32 path is not accessible. Please have local T32 or provide T32 path with -use_t32 <T32_path> to crashman command." )
				sys.exit()
		if vmlinux_64bt or vmlinux_32bt or smmu_32bt or smmu_64bt or smmu_enable or etm_flag:
			if hydserver==False and os.path.exists("\\\\hulk\\vocoder_appdsp5\\users\\Crashman\\linux-ramdump-parser-v2"): 
				ramparse_path = "\\\\hulk\\vocoder_appdsp5\\users\\Crashman\\linux-ramdump-parser-v2"
			elif hydserver==False and os.path.exists("\\\\10.23.101.14\\vocoder_appdsp5\\users\\Crashman\\linux-ramdump-parser-v2"): 
				ramparse_path = "\\\\10.23.101.14\\vocoder_appdsp5\\users\\Crashman\\linux-ramdump-parser-v2"
			elif os.path.exists("\\\\rover\\hyd_dspfw\\ADSP_Tools\\linux-ramdump-parser-v2"): 
				ramparse_path = '\\\\rover\\hyd_dspfw\\ADSP_Tools\\linux-ramdump-parser-v2' 
			else:
				print ("\n***********************")
				print ("hydserver : ",hydserver)
				print ("\\\\10.23.101.14\\vocoder_appdsp5\\users\\Crashman\\linux-ramdump-parser-v2 path is not accessible." )
				sys.exit()
		break
	
	while True: ## Autoframe Crashman command
		if opts.autoframe:
			# print ('\n*******************************\n')
			# print (opts.DUMPFILE)
			INDumpPath = opts.autoframe
			if not os.access(INDumpPath,os.R_OK):
				print ("Dump File is not accessible/available. Please Check the File Path.")
				sys.exit(0)
			if not 'DDRCS' in INDumpPath:
				INDumpPath_temp = ''
				if os.path.isfile(INDumpPath+"\\DDRCS0_0.BIN"): INDumpPath_temp = INDumpPath+"\\DDRCS0_0.BIN"
				if os.path.isfile(INDumpPath+"\\8K\\DDRCS0_0.BIN"): INDumpPath_temp = INDumpPath+"\\8K\\DDRCS0_0.BIN"
				if INDumpPath_temp=='':
					print ('Not able to get dump file')
					sys.exit()
				INDumpPath = INDumpPath_temp
			# if not 'DDSCS' in INDumpPath:
				# for file in possible_dump_name:
					# if os.path.isfile(INDumpPath+"\\"+file): 
						# INDumpPath = INDumpPath+"\\"+file
						# break
					# if  os.path.isfile(INDumpPath+"\\8K\\"+file):
						# INDumpPath = INDumpPath+"\\8K\\"+file
						# break
			# print ('     Dump_path       :',INDumpPath)
			dump_dir = os.path.dirname(INDumpPath)
			if '8K' in dump_dir: dump_dir= dump_dir.split('\\8K')[0]
			crashscope_path = ''
			for subdir, dirs, files in os.walk(dump_dir):
				for sub_dic in dirs:
					if 'crashscope' in sub_dic.lower() or 'txtreports' in sub_dic.lower(): 
						crashscope_path = dump_dir+'\\'+sub_dic
						break
				break
			if crashscope_path == '':
				print ('Not able to Frame Crashman Command. May be Crashscope folder not present or not able to detect Crashscope folder')
				sys.exit()
			# print ('     crashscope_path :',crashscope_path)
			if os.path.isfile(crashscope_path+"\\txtReports\\Summary.txt"): crashscope_path = crashscope_path+"\\txtReports\\Summary.txt"
			elif os.path.isfile(crashscope_path+"\\Summary.txt"): crashscope_path = crashscope_path+"\\Summary.txt"
			else:
				print ("Not able to detect Summary.txt file from dump location")
				sys.exit()
			# print ('     Summary.txt     :',crashscope_path)
			fileptr = open(crashscope_path,'r')
			linelist = fileptr.readlines()
			processor = ''
			target = ''
			for cnt in range(len(linelist)):
				if 'Root Cause Info' in linelist[cnt]:
					target = linelist[cnt+2].split(":")[0].strip()
					if 'cdsp' in linelist[cnt+2].lower(): processor= 'CDSP'
					else: processor = 'ADSP'
					break
			target = linelist[15].split(':')[0].strip()
			if processor == '' or target == '':
				print ("Not able to detect target from Crashscope Summary.txt")
				continue
			# print ('     target :',target)
			# print ('     processor :',processor)
			build_list = []
			for cnt in range(4,len(linelist)):
				if processor in linelist[cnt]: build_list.append('\\\\'+linelist[cnt].split('\\\\')[1].strip())
			if len(build_list)==0:
				print ('Not able to detect ADSP/CDSP build from Summary.txt file')
				sys.exit()
			temp_build = ''
			nsid_build = ''
			if len(build_list) == 1 : temp_build = build_list[0]
			else:
				for temp in build_list:
					if 'nsid' in temp.lower(): nsid_build=temp
					else : temp_build = temp
			# print ('     build_1 :',temp_build)
			# print ('     build_2 :',nsid_build)
			opts.TARGET = target
			opts.DUMPFILE = INDumpPath
			opts.BUILD = temp_build
			if nsid_build != '': opts.ELF = nsid_build
			else: opts.ELF==temp_build
			if not processor.lower()+'_proc' in opts.ELF.lower(): opts.ELF += '\\'+processor.lower()+'_proc'
			if not 'build\\ms' in opts.ELF.lower(): opts.ELF += '\\build\\ms'
		break
	
	while True: ## Create Crashman Folder
		i = datetime.datetime.now()
		dateref = str("{0:0=2d}".format(i.month))+"_"+str("{0:0=2d}".format(i.day))+"_"+str(i.hour)+"h"+str(i.minute)+"m"+str(i.second)+"s"
		if not os.path.exists(crashman_opt): os.makedirs(crashman_opt)
		OUTDumpPath = crashman_opt+"/Crashman_"+dateref+"/Logs"
		if opts.auto_droid: 
			OUTDumpPath = crashman_opt+"\\Crashman\\Logs"
		# if not opts.auto_droid: 
			# if asha_flag == True: 
				# CurrDirectory = "\\\\rover\\hyd_dspfw\\ADSP_Tools\\TriageTeam\\Crashman\\Latest"
		# else: 
			# OUTDumpPath = crashman_opt+"\\Crashman\\Logs"
			# CurrDirectory = "\\\\rover\\hyd_dspfw\\ADSP_Tools\\TriageTeam\\Crashman\\Latest"
		if not os.path.exists(OUTDumpPath):
			try:    
				os.makedirs(OUTDumpPath) 
				os.makedirs(OUTDumpPath+"/temp") 
				os.makedirs(OUTDumpPath+"/temp/thread_callstack") 
				os.makedirs(OUTDumpPath+"/Qurt_logs") 
				os.makedirs(OUTDumpPath+"/ulog/ULOG_Reports") 
				os.makedirs(OUTDumpPath+"/ulog/ULOG_Audio_Reports") 
				os.makedirs(OUTDumpPath+"/ulog/ULOG_sensor_Reports") 
				os.makedirs(OUTDumpPath+"/ulog/ULOG_charger_Reports") 
				os.makedirs(OUTDumpPath+"/adsppm") 
				#os.makedirs(OUTDumpPath+"\\apr_logs")
			except:
				print ("Output Folder is not accessible. Please Give Proper Output path.")
				sys.exit(0)
		print ("Crashman Output Folder    : "+OUTDumpPath)
		
		break
	
	while True: ## Validate Target
		targetid = ''
		# print (target_name_posibility.values())
		# for temp_target in target_name_posibility.values():
			# if opts.TARGET in temp_target: targetid = target_name_posibility.keys()[target_name_posibility.values().index(temp_target)]
		for key, temp_target in target_name_posibility.items():
			if opts.TARGET in temp_target: targetid = key
		if targetid == '': 
			print ('\nTarget Type is missing or entered target is invalid. Enter Valid Target name are as per below (-t <target_type>).\n')
			for key in target_name_posibility.keys():
				print (key,':',target_name_posibility[key])
			sys.exit()
		print ('Target ID                 : '+targetid)
		if targetid in new_target_list: new_target_flag = True
		else: new_target_flag = False
		if targetid in target_with_slpi_flag: slpi_target_flag = True
		else: slpi_target_flag = False
		break
	
	while True: ## Validate Dump path
		INDumpPath = opts.DUMPFILE
		if not os.access(INDumpPath,os.R_OK):
			print ("Dump File is not accessible/available. Please Check the File Path.")
			sys.exit(0)
		print ('Dump Path                 : '+INDumpPath)
		#if ".bin" not in INDumpPath.lower() and ".elf" not in INDumpPath.lower() and ".lst" not in INDumpPath.lower():
		#	print("Please specify the bin/elf file within dump path")
		#	sys.exit()
		dump_path=None
		#if os.path.isfile(INDumpPath): 
		dump_path = os.path.dirname(INDumpPath)
		print("dump path = {}".format(dump_path))
		input1 = OUTDumpPath+"/temp/version_check.txt"
		f_out = open(input1,"w")
		Pythonversion = sys.version
		Pythonversion1 = Pythonversion.split() 
		f_out.write('Python Version Installed : v' + Pythonversion1[0] + '\n' )
		if crashman_lite!=True:
			f_out.write('Perl   Version Installed : ' + perl_version + '\n' )
		else:
			f_out.write('\n' )
		f_out.write('Crashman Version         : '+ Crashman_Version + '\n')
		#f_out.write('VersionFileEnd\n')
		f_out.close()
		bin = OUTDumpPath+"/temp/binarylength.txt"
		f_bin = open(bin,'w')
		size = os.path.getsize(INDumpPath)
		f_bin.write(str(size)+'\n')
		f_bin.close()
		break
	
	while True: ## Validate Build path
		CRM_buildpath = opts.BUILD
		if CRM_buildpath == None:
			print ("\n***********************\nLooks like Build detail is not present in Crashman Command.Please provide proper build.\n***********************")
			sys.exit()
		if not os.access(CRM_buildpath,os.R_OK):
			print (CRM_buildpath+' not accessible.')
			sys.exit()
		if not linux_flag:
			if CRM_buildpath[len(CRM_buildpath)-1]=='\\' or CRM_buildpath[len(CRM_buildpath)-1]=='//': CRM_buildpath = CRM_buildpath[ :len(CRM_buildpath)-1]
		if not ('adsp_proc' in CRM_buildpath or 'cdsp_proc' in CRM_buildpath or 'slpi_proc' in CRM_buildpath):
			if 'adsp' in CRM_buildpath.lower() or 'lpaidsp' in CRM_buildpath.lower() and not 'adsp_proc' in CRM_buildpath.lower(): CRM_buildpath = os.path.join(*[CRM_buildpath,"adsp_proc"])
			if 'cdsp' in CRM_buildpath.lower() and not 'cdsp_proc' in CRM_buildpath.lower(): CRM_buildpath = os.path.join(*[CRM_buildpath,"cdsp_proc"])
			if 'slpi' in CRM_buildpath.lower() and not 'slpi_proc' in CRM_buildpath.lower(): CRM_buildpath = os.path.join(*[CRM_buildpath,"slpi_proc"])
			if (targetid=='lemans' or targetid=='monaco' or targetid=='aurora' or targetid=='halliday'):
				if "dsp_proc" not in CRM_buildpath:
					CRM_buildpath = CRM_buildpath+'/dsp_proc'
			if not os.access(CRM_buildpath,os.R_OK):
				if os.path.exists(os.path.join(*[opts.BUILD,"adsp_proc"])): CRM_buildpath = os.path.join(*[opts.BUILD,"adsp_proc"])
				if os.path.exists(os.path.join(*[opts.BUILD,"cdsp_proc"])): CRM_buildpath = os.path.join(*[opts.BUILD,"cdsp_proc"])
				if os.path.exists(os.path.join(*[opts.BUILD,"slpi_proc"])): CRM_buildpath = os.path.join(*[opts.BUILD,"slpi_proc"])
				if os.path.exists(os.path.join(*[opts.BUILD,"dsp_proc"])): CRM_buildpath = os.path.join(*[opts.BUILD,"dsp_proc"])
		if not os.access(CRM_buildpath,os.R_OK):
			print ("Build Path is not accessible/available.Please Check and Provide the Proper Build Path.",CRM_buildpath)
			sys.exit(0)
		if not os.path.exists(CRM_buildpath+"/core"):
			print ("Core folder is not present in Build. Please provide proper CRM Build Path.",CRM_buildpath)
			sys.exit(0)
		if not os.path.exists(CRM_buildpath+"/core/kernel/qurt"):
			print ("\\core\\kernel\\qurt folder is not present in Build. Please provide proper CRM Build Path.")
			sys.exit(0)
		subsystem = "adsp"
		variant = "prod"
		if opts.variant:
			variant = opts.variant
		if "cdsp_proc" in CRM_buildpath.lower(): subsystem = "cdsp"
		if "slpi_proc" in CRM_buildpath.lower(): subsystem = "slpi"
		if opts.cdsp:
			subsystem = "cdsp"
		if opts.SS:
			subsystem = opts.SS.lower()
		if (targetid == "lemans" or targetid=="monaco" or targetid=="makena") and subsystem =="cdsp":
			subsystem ="cdsp0"
		addr_sepr_enable = False
		#if(((targetid in targets_with_addr_sepr_enabled and (subsystem=="cdsp"))) or (opts.addr_sepr_enable)):
		if((targetid in targets_with_addr_sepr_enabled) or (opts.addr_sepr_enable)):
			addr_sepr_enable = True
		# if slpi_flag == True and not "slpi_proc" in CRM_buildpath:
			# print ("slpi Build Path is not accessible/available. Please Provide the proper CDSP Build Path.")
		print ('Build Path                : '+CRM_buildpath)
		print ('Processor                 : '+subsystem)
		break
	
	while True: ## Validate elf path 
		if not opts.ELF:  
			if not os.access(CRM_buildpath+'/build/ms',os.R_OK):
				print (CRM_buildpath+'/build/ms '+' Path not Accessible')
				sys.exit()
			ELF_filepath = CRM_buildpath+'/build/ms'
		else:
			ELF_filepath = opts.ELF
			if not os.access(ELF_filepath,os.R_OK):
				print (ELF_filepath+' Path not Accessible')
				sys.exit()
			if ELF_filepath[len(ELF_filepath)-1]=='\\' or  ELF_filepath[len(ELF_filepath)-1]=='/'  : ELF_filepath = ELF_filepath[ :len(ELF_filepath)-1]
		print ('ELF Filepath              : '+ELF_filepath)
		break
	
	while True: ## Validate ramparse_path for given Target
		if vmlinux_64bt or vmlinux_32bt or smmu_32bt or smmu_64bt or smmu_enable or etm_flag:
			try:
				if targetid == "8937" or targetid == "8953" or targetid == "439":
					if hydserver==True: ramparse_path = "\\\\rover\\hyd_dspfw\\ADSP_Tools\\TriageTeam\\8937\\linux-ramdump-parser-v2"
					else:
						ramparse_path = "\\\\hulk\\vocoder_appdsp5\\users\\Crashman\\8937\\linux-ramdump-parser-v2"
						if not os.path.exists("\\\\hulk\\vocoder_appdsp5\\users\\Crashman\\8937\\linux-ramdump-parser-v2"): ramparse_path = "\\\\rover\\hyd_dspfw\\ADSP_Tools\\TriageTeam\\8937\\linux-ramdump-parser-v2"
				else:
					if targetid == '405': ramparse_path_temp = ramparse_path.replace('linux-ramdump-parser-v2','linux-ramdump-parser-v2_VT')
					elif targetid == '7150': ramparse_path_temp = ramparse_path+'_6150'
					else:  ramparse_path_temp = ramparse_path.replace('linux-ramdump-parser-v2','linux-ramdump-parser-v2_'+targetid)
					if os.path.exists(ramparse_path_temp): ramparse_path = ramparse_path_temp
				if linux_rdp: ramparse_path = linux_rdp
			except:
				print ("\n*****************")
				print ("Error arised while initializing ramparse_path. If you not loading full dump then you can ignore this error")
				print ("*****************\n")
				ramparse_path = ''
		break
	
	palima_flag=False
	if targetid == 'palima':
		targetid='waipio'
		palima_flag=True

	tofino_flag=False
	if targetid == 'tofino':
		targetid='waipio'
		tofino_flag=True
		
	fillmore_flag=False
	if (targetid == 'fillmore' and subsystem=="cdsp"):
		targetid='waipio'
		fillmore_flag=True
	
	while True: #bailing out in case of load.cmm miss for full dump loading
		print("dump_path={}".format(dump_path))
		if not os.path.isfile(os.path.join(dump_path, "load.cmm")) and (smmu_64bt or smmu_output or clara_output):
			print("load.cmm is needed for full dump loading...Exiting!!")
			sys.exit()
		break
	while True: ## ELF file list initialization 
		list_of_elf_need_to_load = []
		possible_elfs = possible_elf_names[subsystem]
		buildid = (re.search(r'-\d{5}', CRM_buildpath).group() if re.search(r'-\d{5}', ELF_filepath) else "").strip('-')
		for sub_variant, elfs in possible_elfs.items():
			for elf in elfs:
				if os.access(ELF_filepath+'/'+elf.replace('Target_ID',targetid).replace('VARIANT',variant).replace('Build_ID',buildid),os.R_OK):
					list_of_elf_need_to_load.append(ELF_filepath+'/'+elf.replace('Target_ID',targetid).replace('VARIANT',variant).replace('Build_ID',buildid))
			if len(list_of_elf_need_to_load):
				break
		if len(list_of_elf_need_to_load) == 0:
			print ('No ELF files present at '+ELF_filepath+' Location')
			sys.exit()
		if not any([True if 'root_' in (elf.split('/')[-1]).lower() else False for elf in list_of_elf_need_to_load]) and new_target_flag and subsystem!="slpi":
			print ("\nERROR : No any Root elf present at ELF files location.")
			sys.exit()
		f_out = open(OUTDumpPath+"/temp/list_of_elf_file_need_to_load.txt","w")
		for temp_elf in list_of_elf_need_to_load:
			if " " in temp_elf : temp_elf = "\""+temp_elf+"\"" 
			f_out.write(temp_elf+'\n')
		f_out.close()
		break
	while False: ## ELF file list initialization 
		if subsystem=="adsp" or subsystem=="gpdsp0" or subsystem=="gpdsp1": 
			if not opts.core_elf: 
				if not opts.prod2q : possible_elf_file_name = possible_elf_file_name_prod_adsp
				else: possible_elf_file_name = possible_elf_file_name_prod2_adsp
			else: possible_elf_file_name = possible_elf_file_name_core_adsp
		elif subsystem=="cdsp" or subsystem=="cdsp0" or subsystem=="cdsp1" :
			if not opts.core_elf: 
				if not opts.prod2q : possible_elf_file_name = possible_elf_file_name_prod_cdsp
				else: possible_elf_file_name = possible_elf_file_name_prod2_cdsp
			else: possible_elf_file_name = possible_elf_file_name_core_cdsp
		elif subsystem=="slpi": 
			if not opts.prod2q : possible_elf_file_name = possible_elf_file_name_prod_slpi
			else: possible_elf_file_name = possible_elf_file_name_prod2_slpi
 
		possible_elf_file_name = [elf.replace('cdsp',subsystem) for elf in possible_elf_file_name]
		possible_elf_file_name = [elf.replace('slpi',subsystem) for elf in possible_elf_file_name]
		possible_elf_file_name = [elf.replace('adsp',subsystem) for elf in possible_elf_file_name]
		list_of_elf_need_to_load = []
		if targetid not in list_of_target_with_old_elf_file_name: possible_elf_file_name_temp = possible_elf_file_name
		else: possible_elf_file_name_temp = old_elf_file_name
		if opts.ELF:
			buildid = (re.search(r'-\d{5}', ELF_filepath).group() if re.search(r'-\d{5}', ELF_filepath) else "").strip('-')
			for temp_elf in possible_elf_file_name_temp:
				if os.access(ELF_filepath+'/'+temp_elf.replace('Target_ID',targetid).replace('Build_ID',buildid),os.R_OK):
					list_of_elf_need_to_load.append(ELF_filepath+'/'+temp_elf.replace('Target_ID',targetid).replace('Build_ID',buildid))
			if len(list_of_elf_need_to_load) == 0:
				for temp_elf in possible_elf_file_name_prod2_adsp:
					if os.access(ELF_filepath+'/'+temp_elf.replace('Target_ID',targetid),os.R_OK):
						list_of_elf_need_to_load.append(ELF_filepath+'/'+temp_elf.replace('Target_ID',targetid))
		if not opts.ELF and len(list_of_elf_need_to_load) == 0:
			buildid = (re.search(r'-\d{5}', CRM_buildpath).group() if re.search(r'-\d{5}', CRM_buildpath) else "").strip('-')
			for temp_elf in possible_elf_file_name_temp:
				if os.access(CRM_buildpath+'/build/ms/'+temp_elf.replace('Target_ID',targetid).replace('Build_ID',buildid),os.R_OK):
					list_of_elf_need_to_load.append(CRM_buildpath+'/build/ms/'+temp_elf.replace('Target_ID',targetid).replace('Build_ID',buildid))
			if len(list_of_elf_need_to_load) == 0:
				for temp_elf in possible_elf_file_name_prod2_adsp:
					if os.access(CRM_buildpath+'/build/ms/'+temp_elf.replace('Target_ID',targetid),os.R_OK):
						list_of_elf_need_to_load.append(CRM_buildpath+'/build/ms/'+temp_elf.replace('Target_ID',targetid))
		if len(list_of_elf_need_to_load) == 0 and targetid in list_of_target_with_old_elf_file_name:
			if opts.ELF:
				for temp_target in list_of_target_with_old_elf_file_name:
					for temp_elf in old_elf_file_name:
						if os.access(ELF_filepath+'/'+temp_elf.replace('Target_ID',temp_target),os.R_OK):
							list_of_elf_need_to_load.append(ELF_filepath+'/'+temp_elf.replace('Target_ID',temp_target))
					if len(list_of_elf_need_to_load)!=0: break
			if not opts.ELF or len(list_of_elf_need_to_load) == 0:
				for temp_target in list_of_target_with_old_elf_file_name:
					for temp_elf in old_elf_file_name:
						if os.access(CRM_buildpath+'/build/ms/'+temp_elf.replace('Target_ID',temp_target),os.R_OK):
							list_of_elf_need_to_load.append(CRM_buildpath+'/build/ms/'+temp_elf.replace('Target_ID',temp_target))
					if len(list_of_elf_need_to_load)!=0: break
		if (targetid == '6150' or targetid == '405') and opts.au == True:
			list_of_elf_need_to_load = []
			if opts.ELF:
				for temp_elf in possible_elf_file_name:
					if os.access(ELF_filepath+'/'+temp_elf.replace('Target_ID',targetid).replace('prodQ','auQ'),os.R_OK):
						list_of_elf_need_to_load.append(ELF_filepath+'/'+temp_elf.replace('Target_ID',targetid).replace('prodQ','auQ'))
			if not opts.ELF or len(list_of_elf_need_to_load) == 0:
				for temp_elf in possible_elf_file_name:
					if os.access(CRM_buildpath+'/build/ms/'+'/'+temp_elf.replace('Target_ID',targetid).replace('prodQ','auQ'),os.R_OK):
						list_of_elf_need_to_load.append(CRM_buildpath+'/build/ms'+'/'+temp_elf.replace('Target_ID',targetid).replace('prodQ','auQ'))
		if len(list_of_elf_need_to_load) == 0 and targetid == 'makena':
			for temp_elf in possible_elf_file_name_temp:
				if os.access(ELF_filepath+'/'+temp_elf.replace('Target_ID',targetid).replace('cdsp0','cdsp0_adas'),os.R_OK):
					list_of_elf_need_to_load.append(ELF_filepath+'/'+temp_elf.replace('Target_ID',targetid).replace('cdsp0','cdsp0_adas'))
		if len(list_of_elf_need_to_load) == 0 and targetid == 'aurora':
			for temp_elf in possible_elf_file_name_temp:
				if os.access(ELF_filepath+'/'+temp_elf.replace('Target_ID',targetid).replace('adsp','adsp_la'),os.R_OK):
					list_of_elf_need_to_load.append(ELF_filepath+'/'+temp_elf.replace('Target_ID',targetid).replace('adsp','adsp_la'))
		if len(list_of_elf_need_to_load) == 0:
			print ('No any ELF file present at '+ELF_filepath+' Location')
			sys.exit()
		if not any([True if 'root_' in (elf.split('/')[-1]).lower() else False for elf in list_of_elf_need_to_load]) and new_target_flag and subsystem!="slpi":
			print ("\nERROR : No any Root elf present at ELF files location.")
			sys.exit()
		if targetid in ukernel_elf_check:
			if not any([True if 'ukernel_' in (elf.split('/')[-1]).lower() else False for elf in list_of_elf_need_to_load]):
				print ("\nERROR : No any Ukernel elf present at ELF files location.")
				sys.exit()
		f_out = open(OUTDumpPath+"/temp/list_of_elf_file_need_to_load.txt","w")
		for temp_elf in list_of_elf_need_to_load:
			if " " in temp_elf : temp_elf = "\""+temp_elf+"\"" 
			f_out.write(temp_elf+'\n')
		f_out.close()
		break
	
	while True: ## ELF file symbol initialization
		if not targetid in list_of_target_with_old_elf_file_name:
			elf_symbol = 'ROOT_'+targetid
			sensor_elf_symbol = 'ROOT_'+targetid
			audio_elf_symbol = 'ROOT_'+targetid
			charger_elf_symbol = 'CHARGER_'+targetid
			for temp_elf in list_of_elf_need_to_load:
				if 'SENSOR' in temp_elf: sensor_elf_symbol = 'SENSOR_'+targetid
			for temp_elf in list_of_elf_need_to_load:
				if 'AUDIO' in temp_elf: audio_elf_symbol = 'AUDIO_'+targetid
			for temp_elf in list_of_elf_need_to_load:
				if 'CHARGER' in temp_elf: charger_elf_symbol = 'CHARGER_'+targetid
		else:
			elf_symbol = 'M'+targetid+'AAAAAAAAQ1234'
			sensor_elf_symbol = 'M'+targetid+'AAAAAAAAQ1234'
			audio_elf_symbol = 'M'+targetid+'AAAAAAAAQ1234'
			charger_elf_symbol = 'M'+targetid+'AAAAAAAAQ1234'
			for temp_elf in list_of_elf_need_to_load:
				if 'SENSOR' in temp_elf: sensor_elf_symbol = 'M'+targetid+'AAAAAAAAQ1234_SENSOR_'+targetid
			for temp_elf in list_of_elf_need_to_load:
				if 'AUDIO' in temp_elf: audio_elf_symbol = 'M'+targetid+'AAAAAAAAQ1234_AUDIO_'+targetid
		break
	
	while True: ## selected_cpu_version Initilization 
		selected_cpu_version = 'HexagonV5'
		if subsystem in cpu_version_dict.keys():
			for hex_version, sup_targets in cpu_version_dict[subsystem].items():
				if(targetid in sup_targets):
					selected_cpu_version = hex_version
		#print(selected_cpu_version)
		#sys.exit()
		break
	
	while True: ## Random Things
		if load_dump_full!=False:
			if not os.path.isfile(os.path.dirname(INDumpPath)+"/load.cmm"):
				print ("**************************************************************")
				print ("If you are using -smmu32/smmu64 crahman option , the dump argument given in crashman must point to complete ramdump.\n")
				print ("Mandatory contents to be present in dump path - load.cmm, dumps etc")
				print ("**************************************************************")
				sys.exit(0)
		if crashman_lite==True and gdb_flag==True:
			print ("Crashman Lite and GDB are not concurrently supported. Please select any one option")
			sys.exit(0)
		break
	
	break
	
while True:  ## Load only audiopddump
	if ((opts.audiopddump == True)or(opts.sensorpddump == True)):
		import TimeStampExtractionCompare
		targetid = opts.TARGET
		elf_file_path = opts.BUILD
		if "adsp_proc" in elf_file_path: elf_file = os.path.join(*[elf_file_path,"build","ms"])
		else: elf_file = os.path.join(*[elf_file_path,"adsp_proc","build","ms"])
		
		if opts.ELF : elf_file = opts.ELF
		
		if targetid in pd_dump_supported:
			elfname = elf_file+"/AUDIO_"+targetid+".adsp.prodQ.elf"

		if not os.path.isfile(elfname):
			if os.path.isfile (elf_file+"/AUDIO_"+targetid+".adsp.dynloadingQ.elf"):
				elfname = elf_file+"/AUDIO_"+targetid+".adsp.dynloadingQ.elf"

		if not os.path.isfile(elfname):
			print ("ELF file is not accessible/available @ "+ elfname)
			sys.exit(0)
			
		f_out = open(OUTDumpPath+"/temp/list_of_elf_file_need_to_load.txt","w")
		f_out.write(elfname+'\n')
		f_out.close()
		if (opts.sensorpddump == True):
			elfname=elfname.replace('AUDIO','SENSOR')

		INDumpPath=opts.DUMPFILE
		if not os.path.exists(INDumpPath):
			print ("Dump file or path does not exist, please provide proper path")
			sys.exit(0)


		if (opts.audiopddump == True):
			if "pd_dump_audio_process" in INDumpPath: dumpfile = INDumpPath
			elif "pd_dump_audio_process.00.elf" in INDumpPath: dumpfile = INDumpPath
			elif os.path.isfile(os.path.dirname(INDumpPath)+"/pd_dump_audio_process.02.elf"): dumpfile = os.path.dirname(INDumpPath)+"/pd_dump_audio_process.02.elf"

		if (opts.sensorpddump == True):
			if "pd_dump_sensor_process" in INDumpPath or "pd_dump_qsh_process" in INDumpPath: dumpfile = INDumpPath
			elif "pd_dump_sensor_process.00.elf" in INDumpPath: dumpfile = INDumpPath
			elif os.path.isfile(os.path.dirname(INDumpPath)+"/pd_dump_asensor_process.02.elf"): dumpfile = os.path.dirname(INDumpPath)+"/pd_dump_sensor_process.02.elf"
		pd_dump = ""
		if opts.audiopddump:
			pd_dump = "audiopddump"
		else:
			pd_dump = "sensorpddump"
		subprocess.run(["python","TimeStampExtractionCompare.py",dumpfile,elfname,OUTDumpPath,"adsp",pd_dump],stdout=subprocess.DEVNULL) 

		f_in = open(OUTDumpPath+"/temp/list_of_elf_file_need_to_load.txt","r")
		elfname = f_in.readline().strip()
		f_in.close()

		print ("\nStarted loading PD dumps")
		print ("*************************************")
		t32_file = OUTDumpPath+"/temp/config_sim_usb.t32"	
		f_t32 = open(t32_file,'w+')
		f_t32.write("OS=\n")
		f_t32.write("ID=SIM_${4}            ; unique ID needed for temporary file name uniqueness\n")
		f_t32.write("TMP="+OUTDumpPath+"/temp"+"           ; T32 temp file names are prepended with the unique ID above\n")
		f_t32.write("SYS="+T32_path+"                ; make system directory the same as the executable directory\n\n")
		f_t32.write("SCREEN=\n")
		f_t32.write("HEADER=${4}\n\n")
		f_t32.write("; Ethernet on Host information \n")
		f_t32.write("PBI=SIM\n")
		f_t32.write("\n")
		f_t32.write("; Printer settings\n")
		f_t32.write("PRINTER=WINDOWS\n\n")
		f_t32.write("; Screen fonts\n")
		f_t32.write("SCREEN=\n")
		f_t32.write("FONT=SMALL\n\n")
		f_t32.close()
		

		Path = T32_path+"/bin/windows64"
		if os.path.exists(Path):
			command = '''start %s/bin/windows64/t32mqdsp6.exe -c %s, %s %s %s %s %s %s %s'''%(T32_path,OUTDumpPath+"/temp/config_sim_usb.t32",CurrDirectory+"/audio_mappings_670.cmm",elfname,dumpfile,targetid, OUTDumpPath,selected_cpu_version,CurrDirectory)
			os.system(command)
		else:    
			command = '''start %s/t32mqdsp6.exe -c %s, %s %s %s %s %s %s %s'''%(T32_path,OUTDumpPath+"/temp/config_sim_usb.t32",CurrDirectory+"/audio_mappings_670.cmm",elfname,dumpfile,targetid, OUTDumpPath,selected_cpu_version,CurrDirectory)
			os.system(command)
		sys.exit(0)
	break
	
while True:  ## Creating ExtractAddress.txt
	if os.path.isfile(dump_path+"/load.cmm"):
		f_info = open(dump_path+"/load.cmm",'r')
		f_store = open(OUTDumpPath+"/temp/ExtractAddress.txt",'w')
		for line in f_info:
			if "d.load.binary" in line:
				input_file = dump_path + "/" + line.split()[1]
				if os.path.isfile(input_file):
					input_file_size = str(os.path.getsize(input_file))
					val1 = line.split()[2]
					val2 = input_file_size
					val_add = int(val2,10)+int(val1,16)
					f_store.write(line.split()[2]+" "+hex(val_add).replace('L','')+" "+str(input_file_size)+" "+hex(int(input_file_size,10)).replace('L','')+" "+line.split()[1]+"\n")
		f_info.close()
		f_store.close()
	elif os.path.isfile(dump_path+"/dump_info.txt"):
		f_info = open(dump_path+"/dump_info.txt",'r')
		f_store = open(OUTDumpPath+"/temp/ExtractAddress.txt",'w')
		for line in f_info:
			try:
				if ".BIN" in line:
					val1 = line.split()[1]
					val2 = line.split()[2]
					val_add = int(val2,10)+int(val1,16)
					f_store.write(val1+" "+hex(val_add).replace('L','')+" "+val2+" "+hex(int(val2,10)).replace('L','')+" "+line.split()[-1]+"\n")
			except:
				continue
		f_info.close()
		f_store.close()
	break
	
while True:  ## Checking for smmu_32bt,smmu_64bt,vmlinux_32bt,vmlinux_64bt,etm_flag,smmu_output,clara_output,smmu_enable
	if opts.QNX_SMMU: 
		QNX_SMMU_PATH = opts.QNX_SMMU
		command = '''python %s/QNX_parser.py  %s %s'''%(CurrDirectory,QNX_SMMU_PATH,OUTDumpPath+"/temp"+"/")
		write_command_into_file(command)
		os.system(command)
	if smmu_32bt!=False or smmu_64bt!=False:
		ddrcs0_offset = None
		ddrcs1_offset = None
		ocimem_offset = None
		ddrcs0_filename = "DDRCS0.BIN"
		ddrcs1_filename = "DDRCS1.BIN"
		
		dram_filename = None
		dram_offset1 = None
		dram_offset2 = None
		
		dram1_filename = None
		dram1_offset1 = None
		dram1_offset2 = None
		
		ocimem_filename = None
		ocimem_offset1 = None
		ocimem_offset2 = None
		kaslr_address = None
		
		try:
			if os.path.isfile(dump_path+"/dump_info.txt"):
				f_dump = open(dump_path+"/dump_info.txt",'r')
				for line in f_dump:
					if "DDRCS0.BIN" in line:
						offset = line.split()
						ddrcs0_offset = offset[1]
						ddrcs0_size = offset[2]
						ddrcs0_filename = "DDRCS0.BIN"
					if "DDRCS0_0.BIN" in line:
						offset = line.split()
						ddrcs0_offset = offset[1]
						ddrcs0_size = offset[2]
						ddrcs0_filename = "DDRCS0_0.BIN"
					if "DDRCS1.BIN" in line :
						offset = line.split()
						ddrcs1_offset = offset[1]
						ddrcs1_size = offset[2]
						ddrcs1_filename = "DDRCS1.BIN"
					if "DDRCS1_0.BIN" in line:
						offset = line.split()
						ddrcs1_offset = offset[1]
						ddrcs1_size = offset[2]
						ddrcs1_filename = "DDRCS1_0.BIN"
					if "OCIMEM.BIN" in line:
						offset = line.split()
						ocimem_offset = offset[1]
						ocimem_size = offset[2]
				f_dump.close()
			else:
				for r,d,f in os.walk(dump_path):
					for file in f:
						win_dump  = os.path.join(r,file)
						# print (win_dump)
						if "dram_" in win_dump:
							dram_filename = win_dump.split('/')[-1]
							dram_offset1 = win_dump.split('dram_')[1].split('--')[0]
							dram_offset2 = win_dump.split('dram_')[1].split('--')[1].split('.')[0]
							load = OUTDumpPath+"/temp/load.cmm"
							f_load = open(load,'a')
							f_load.write('d.load.binary '+win_dump+' a:'+dram_offset1+' /noclear\n')
							f_load.close()
						if "dram1_" in win_dump:
							dram1_filename = win_dump.split('/')[-1]
							dram1_offset1 = win_dump.split('dram1_')[1].split('--')[0]
							dram1_offset2 = win_dump.split('dram1_')[1].split('--')[1].split('.')[0]
							load = OUTDumpPath+"/temp/load.cmm"
							f_load = open(load,'a')
							f_load.write('d.load.binary '+win_dump+' a:'+dram1_offset1+' /noclear\n')
							f_load.close()
						if "ocimem_" in win_dump:
							ocimem_filename = win_dump.split('/')[-1]
							ocimem_offset1 = win_dump.split('ocimem_')[1].split('--')[0]
							ocimem_offset2 = win_dump.split('ocimem_')[1].split('--')[1].split('.')[0]
						if "kaslr_" in win_dump:
							if os.path.isfile(win_dump) and kaslr_offset == False:
								file_kaslr = open(win_dump,"rb")
								data = file_kaslr.read(4)
								s1=binascii.hexlify(file_kaslr.read(1))
								s2=binascii.hexlify(file_kaslr.read(1))
								s3=binascii.hexlify(file_kaslr.read(1))
								s4=binascii.hexlify(file_kaslr.read(1))
								kaslr_address = "0x"+s4+s3+s2+s1
								file_kaslr.close()
				
		except:
			print ("dump_info.txt not exists!!")
			
		offset = " "
		if dram_filename!=None and dram1_filename!=None and ocimem_filename!=None:
			phy_offset  = dram_offset1
			if int(dram1_offset1,16) < int(dram_offset1,16):
				phy_offset = dram1_offset1
			if opts.PHYS:
				phy_offset = opts.PHYS
			if kaslr_offset != False:
				if kimage_voffset != False:
					offset = '''--ram-file %s//%s %s %s --ram-file %s//%s %s %s --ram-file %s//%s %s %s --phys-offset %s --kaslr-offset %s --kimage-voffset %s'''%(dump_path,dram_filename,dram_offset1,dram_offset2,dump_path,dram1_filename,dram1_offset1,dram1_offset2,dump_path,ocimem_filename,ocimem_offset1,ocimem_offset2,phy_offset,kaslr_offset,kimage_voffset)
				else:
					offset = '''--ram-file %s//%s %s %s --ram-file %s//%s %s %s --ram-file %s//%s %s %s --phys-offset %s --kaslr-offset %s'''%(dump_path,dram_filename,dram_offset1,dram_offset2,dump_path,dram1_filename,dram1_offset1,dram1_offset2,dump_path,ocimem_filename,ocimem_offset1,ocimem_offset2,phy_offset,kaslr_offset)
			else:
				if kaslr_address != None:
					offset = '''--ram-file %s//%s %s %s --ram-file %s//%s %s %s --ram-file %s//%s %s %s --phys-offset %s --kaslr-offset %s'''%(dump_path,dram_filename,dram_offset1,dram_offset2,dump_path,dram1_filename,dram1_offset1,dram1_offset2,dump_path,ocimem_filename,ocimem_offset1,ocimem_offset2,phy_offset,kaslr_address)
				else:
					offset = '''--ram-file %s//%s %s %s --ram-file %s//%s %s %s --ram-file %s//%s %s %s --phys-offset %s '''%(dump_path,dram_filename,dram_offset1,dram_offset2,dump_path,dram1_filename,dram1_offset1,dram1_offset2,dump_path,ocimem_filename,ocimem_offset1,ocimem_offset2,phy_offset)
	if vmlinux_32bt!=False or vmlinux_64bt!=False:
		if vmlinux_64bt!=False:
			if not os.path.exists(ramparse_path):
				print ("**************************************************************")
				print ("Linux ram dump parser path is not accessible/available. Please Check the Path")
				print ("Expecting aarch64-linux-gnu-gdb.exe/aarch64-linux-gnu-nm.exe in linux ram dump parser path location!!!")
				print ("**************************************************************")
				sys.exit(0)
			if os.path.isfile(vmlinux_64bt):
				command = '''python %s//ramparse.py --64-bit -a %s  -o %s   -v %s  --parse-debug-image --nm-path %s//aarch64-linux-gnu-nm.exe --gdb-path %s//aarch64-linux-gnu-gdb.exe'''%(ramparse_path,dump_path,OUTDumpPath+"//temp",vmlinux_64bt,ramparse_path,ramparse_path)
			else:
				print ("**************************************************************")
				print ("vmlinux path is not accessible/available. Please Check the Path ")
				print ("**************************************************************")
				sys.exit(0)
		if vmlinux_32bt!=False:
			if not os.path.exists(ramparse_path):
				print ("**************************************************************")
				print ("Linux ram dump parser path is not accessible/available. Please Check the Path ")
				print ("Expecting aarch64-linux-gnu-gdb.exe/aarch64-linux-gnu-nm.exe in linux ram dump parser path location!!!")
				print ("**************************************************************")
				sys.exit(0)
			if os.path.isfile(vmlinux_32bt):
				command = '''python %s//ramparse.py --32-bit -a %s  -o %s   -v %s  --parse-debug-image --nm-path %s//aarch64-linux-gnu-nm.exe --gdb-path %s//aarch64-linux-gnu-gdb.exe '''%(ramparse_path,dump_path,OUTDumpPath+"//temp",vmlinux_32bt,ramparse_path,ramparse_path)
			else:
				print ("**************************************************************")
				print ("vmlinux path is not accessible/available. Please Check the Path ")
				print ("**************************************************************")
				sys.exit(0)
		
		print ("Processing ETM Dump... it might take 4-5 minutes. Please wait...")
		os.system(command)
	if etm_flag == True and (smmu_32bt!=False or smmu_64bt!=False or smmu_output!=False or clara_output!=False):
		etm_flag = True
	elif etm_flag == True:
		dumpfile = None
		if "tmc-etr.bin" in INDumpPath:
			dumpfile = INDumpPath
		elif "etr.bin" in INDumpPath:
			dumpfile = INDumpPath
		elif os.path.isfile(os.path.dirname(INDumpPath)+"/tmc-etr.bin"):
			dumpfile = os.path.dirname(INDumpPath)+"/tmc-etr.bin"
		elif os.path.isfile(os.path.dirname(INDumpPath)+"/etb.bin"):
			dumpfile = os.path.dirname(INDumpPath)+"/etb.bin"
		elif os.path.isfile(os.path.dirname(INDumpPath)+"/etr.bin"):
			dumpfile = os.path.dirname(INDumpPath)+"/etr.bin"
		elif os.path.isfile(OUTDumpPath+"/temp/tmc-etr.bin"):
			dumpfile = OUTDumpPath+"/temp/tmc-etr.bin"
		elif os.path.isfile(OUTDumpPath+"/temp/etr.bin"):
			dumpfile = OUTDumpPath+"/temp/etr.bin"
		elif os.path.isfile(OUTDumpPath+"/temp/etb.bin"):
			dumpfile = OUTDumpPath+"/temp/etb.bin"
		if dumpfile == None:
			print ("ETM Dump File is not accessible/available. Please Check the File Path.")
			sys.exit(0)

		if ELF_filepath==False:
			ELF_filepath = os.path.join(*[CRM_buildpath,"build","ms"])
			
		elfname = ELF_filepath+"/M"+targetid+"AAAAAAAAQ1234.elf"
		elfname1 = ""
		if new_target_flag:
			elfname = ELF_filepath+"/ROOT_"+targetid+"."+subsystem+".prodQ.elf"
			elfname1 = ELF_filepath+"/UKERNEL_"+targetid+"."+subsystem+".prodQ.elf"
			
		if not os.path.isfile(elfname):
			print ("ELF file is not accessible/available @ "+ elfname)
			sys.exit(0)
			
		if not os.path.isfile(elfname1):
			print ("ELF file is not accessible/available @ "+ elfname1)

		print ("\nStarting T32 for ETM Dump.")
		print ("************************************")
		t32_file = OUTDumpPath+"/temp/config_sim_usb.t32"
		f_t32 = open(t32_file,'w+')
		f_t32.write("OS=\n")
		f_t32.write("ID=SIM_${4}            ; unique ID needed for temporary file name uniqueness\n")
		f_t32.write("TMP="+OUTDumpPath+"/temp"+"           ; T32 temp file names are prepended with the unique ID above\n")
		f_t32.write("SYS="+T32_path+"                ; make system directory the same as the executable directory\n\n")
		f_t32.write("SCREEN=\n")
		f_t32.write("HEADER=${4}\n\n")
		f_t32.write("; Ethernet on Host information \n")
		f_t32.write("PBI=SIM\n")
		f_t32.write("\n")
		f_t32.write("; Printer settings\n")
		f_t32.write("PRINTER=WINDOWS\n\n")
		f_t32.write("; Screen fonts\n")
		f_t32.write("SCREEN=\n")
		f_t32.write("FONT=SMALL\n\n")
		f_t32.close()
		
		Path = T32_path+"/bin/windows64"
		
		if os.path.exists(Path):
			if (selected_cpu_version == 'HexagonV68' or selected_cpu_version == 'HexagonV69' or selected_cpu_version == 'HexagonV73NC_1' or selected_cpu_version == 'HexagonV73NA_1'):
				command = '''start %s\\bin\\windows64\\t32mqdsp6.exe -c %s, %s %s %s %s'''%(T32_path,OUTDumpPath+"\\temp\\config_sim_usb.t32",CurrDirectory+"\\v68_loading_etm_CDSP.cmm", dumpfile, OUTDumpPath+"\\temp", selected_cpu_version)
			else:
				command = '''start %s//bin//windows64//t32mqdsp6.exe -c %s, %s %s %s %s %s %s %s %s'''%(T32_path,OUTDumpPath+"//temp//config_sim_usb.t32",CurrDirectory+"/load_adsp_etm_dump.cmm",elfname,elfname1,dumpfile,targetid,subsystem,selected_cpu_version,new_target_flag)
			os.system(command)
		else:    
			command = '''start %s//t32mqdsp6.exe -c %s, %s %s %s %s %s %s %s %s'''%(T32_path,OUTDumpPath+"//temp//config_sim_usb.t32",CurrDirectory+"/load_adsp_etm_dump.cmm",elfname,elfname1,dumpfile,targetid,subsystem,selected_cpu_version,new_target_flag)
			os.system(command)
		sys.exit(0)
	flag = 0
	
	if (smmu_32bt!=False and smmu_output== False and clara_output==False) or (smmu_64bt!=False and smmu_output== False and clara_output==False):
		if not '3' in Pythonversion[:2] and targetid in require_python_iii:
			print()
			print("SMMU pagetable parser requires python3 version, current version:",Pythonversion[:6])
			sys.exit()
		
		ramparse_path = r'//rover/hyd_dspfw/ADSP_Tools/TriageTeam/linux-ramdump-parser-v2_all_Target/tools/linux-ramdump-parser-v2'
		if '3' in Pythonversion[:2]: 
			ramparse_path = r'//rover/hyd_dspfw/ADSP_Tools/TriageTeam/linux-ramdump-parser-v2_latest/tools/linux-ramdump-parser-v2'
		if hydserver!=True:
			sd_ramparse_path = r"//hulk/vocoder_appdsp5/users/Crashman/linux-ramdump-parser-v2_all_Target/tools/linux-ramdump-parser-v2"
			if '3' in Pythonversion[:2]: 
				sd_ramparse_path = r'//hulk/vocoder_appdsp5/users/Crashman/linux-ramdump-parser-v2_latest/tools/linux-ramdump-parser-v2'
			if os.path.exists(sd_ramparse_path):
				ramparse_path = sd_ramparse_path
		if not os.path.exists(ramparse_path):
			print ("**************************************************************")
			print ("Linux ram dump parser path is not accessible/available. Please Check the Path ")
			print ("Expecting aarch64-linux-gnu-gdb.exe/aarch64-linux-gnu-nm.exe in linux ram dump parser path location!!!")
			print ("ramparse_path :",ramparse_path)
			print ("**************************************************************")
			sys.exit(0)
	if smmu_32bt!=False and smmu_output== False and clara_output==False:  ##add here
		if os.path.isfile(smmu_32bt):
			target_ramparser_id = target_ramparser_id_dict[targetid]
			command = '''python %s//ramparse.py  --32-bit -a %s  -o %s   -v %s  --print-iommu-pg-tables --force-hardware %s %s'''%(ramparse_path,dump_path,OUTDumpPath+"//temp",smmu_32bt,target_ramparser_id,offset)
			print ("Processing SMMU pagetable parsing... it might take 4-5 minutes. Please wait...")
			print ("/n",command)
			bin = OUTDumpPath+"//temp//ProcessingCommands.txt"
			f_bin = open(bin,'a')
			f_bin.write(str(command)+'\n')
			f_bin.close()
			os.system(command)
			smmu_enable=True
		else:
			print ("**************************************************************")
			print ("vmlinux path is not accessible/available. Please Check the Path ")
			print ("**************************************************************")
		load_dump_full=dump_path
		flag = 1
	if smmu_64bt!=False and smmu_output== False and clara_output==False:  ##add here
		if os.path.isfile(smmu_64bt):
			target_ramparser_id = target_ramparser_id_dict[targetid]
			mod_path=os.path.dirname(smmu_64bt)
			if (targetid=="aurora" or targetid=="waipio" or targetid=="kailua"):
				if not os.path.isfile(os.path.join(mod_path,"iommu-logger.ko")):
					mod_path=os.path.dirname(os.path.join(mod_path, "kernel_modules"))
			if (targetid=="waipio" or targetid=="fillmore" or targetid=="kailua" or targetid=="aurora" or targetid=="camano" or targetid=="netrani" or targetid=="clarence" or targetid=="lanai" or targetid=="halliday" or targetid=="divar"):
				if (palima_flag==True):
					target_ramparser_id="cape"
				if (tofino_flag==True):
					target_ramparser_id="ukee"
				if (fillmore_flag==True):
					target_ramparser_id="diwali"
				#print (mod_path)
				if os.path.isfile(os.path.join(mod_path, "iommu-logger.ko")):
					command = '''python %s//ramparse.py -a %s  -o %s -v %s  --print-iommu-pg-tables --mod_path %s --force-hardware %s'''%(ramparse_path,dump_path,OUTDumpPath+"//temp",smmu_64bt,mod_path,target_ramparser_id)
				else:
					print (" \n For SMMU pagetable parsing iommu-logger.ko is required. please get it & copy it to the same folder where vmlinux kept")
					sys.exit()
			else:
				command = '''python %s//ramparse.py --64-bit -a %s  -o %s   -v %s  --print-iommu-pg-tables --force-hardware %s %s'''%(ramparse_path,dump_path,OUTDumpPath+"//temp",smmu_64bt,target_ramparser_id,offset)
			print ('\n'+command)
			bin = OUTDumpPath+"//temp//ProcessingCommands.txt"
			f_bin = open(bin,'a')
			f_bin.write(str(command)+'\n')
			f_bin.close()
			print ("\nProcessing SMMU pagetable parsing... it might take 4-5 minutes. Please wait...")
			os.system(command)
			if False:
				for file in glob.glob(OUTDumpPath+"//temp"+'//arm_iommu_domain_*_*.txt'):
					try:
						newfilename =  os.path.dirname(file)+'//arm_iommu_domain_'+file.split("//")[-1].split("_")[3]+'.txt'
						os.rename(file,newfilename)
					except:
						continue
		else:
			print ("**************************************************************")
			print ("vmlinux path is not accessible/available. Please Check the Path ")
			print ("**************************************************************")
		smmu_enable=True
		load_dump_full=dump_path
		flag = 1
	if smmu_64bt!=False or smmu_32bt!=False or smmu_output!=False:
		if opts.LINUX_SMMU or opts.QNX_SMMU:
			s_output = opts.LINUX_SMMU
			#if not os.path.exists(s_output):
				#print ('/nError : '+s_output+' path is not accessible')
				#sys.exit()
			load_dump_full=dump_path
			smmu_enable=True
			# shutil.copytree(s_output, OUTDumpPath+"//temp")
			check = True
			if opts.LINUX_SMMU:
				for r,d,f in os.walk(s_output):
					for file in f:
						win_dump  = os.path.join(r,file)
						if "arm_" in win_dump or "ams_" in win_dump or "STCU_" in win_dump or "GPU_" in win_dump:
							shutil.copy2(win_dump, OUTDumpPath+"//temp//")
							check = False
					break
			if check:
				print ("\nCan't find any APPS page tables at "+s_output)
				sys.exit()
	if smmu_64bt!=False or smmu_32bt!=False or clara_output!=False:
		if opts.CLARA_SMMU:
			s_output = opts.CLARA_SMMU
			if not os.path.exists(s_output):
				print ('\nError : '+s_output+' path is not accessible')
				sys.exit()
			if os.path.exists(os.path.join(s_output, "smmu_info")):
				s_output = os.path.join(s_output, "smmu_info")
			load_dump_full=dump_path
			smmu_enable=True
			check = True
			for r,d,f in os.walk(s_output):
				for file in f:
					win_dump  = os.path.join(r,file)
					if "arm_" in win_dump or "ams_" in win_dump or "_msm" in win_dump:
						print ("Please wait... claraoutput copying in progress....")
						shutil.copy2(win_dump, OUTDumpPath+"//temp//")
						check = False
				break
			if check:
				print ("\nCan't find any APPS page tables at "+s_output)
				sys.exit()
	if smmu_enable==True and clara_output==False:
		# if not os.path.isfile(OUTDumpPath+"//temp//msm_iommu_domain_11.txt") and not os.path.isfile(OUTDumpPath+"//temp//arm_iommu_domain_11.txt") :
		# if (not (os.path.isfile(OUTDumpPath+"//temp//arm_iommu_domain_11.txt") or os.path.isfile(OUTDumpPath+"//temp//arm_iommu_domain_00.txt"))) and asha_flag != True:
		if (not (os.path.isfile(OUTDumpPath+"//temp//arm_iommu_domain_00__qcom_kgsl_iommu_gfx_d_user.txt") or os.path.isfile(OUTDumpPath+"//temp//arm_iommu_domain_00.txt") or os.path.isfile(OUTDumpPath+"//temp//GPU_CB0.txt") or os.path.isfile(OUTDumpPath+"//temp//arm_iommu_domain_11.txt"))) and asha_flag != True:
			print ("**************************************************************")
			print ("Not able to generate SMMU pagetable mappings with provided dumps and vmlinux.")
			print ("Please provide matching vmlinux and dumps")
			print ("**************************************************************")
			if os.path.isfile(OUTDumpPath+"//temp//dmesg_TZ.txt"):
				print ("\n\n#####################################################################")
				print ("Error Log from dmesg_TZ.txt file")
				print ("#####################################################################")
				f_dump = open(OUTDumpPath+"//temp//dmesg_TZ.txt",'r')
				for line in f_dump:
					print (line)
				f_dump.close()
				print ("#####################################################################")
			sys.exit(0)
	break
	
while True:  ## Fetching Starting Address
	try: # Create new Load.cmm file
		loadcmm_filename = ''
		dumppath = os.path.dirname(INDumpPath)
		if os.path.isfile(dumppath+r"/load.cmm"):
			loadcmm_filename = dumppath+r"/load.cmm"
		else:
			for filename in glob.glob(dumppath+"/load.cmm*.lst"): 
				loadcmm_filename = filename
		if loadcmm_filename!= '':
			with open(loadcmm_filename,'r') as fileptr:
				linelist = fileptr.readlines()
				linelist = [line for line in linelist if ('d.load.binary' in line or 'd.load.b' in line) and ('DDRCS' in line.upper() or 'DRAM_CS' in line.upper() )]
				for index,line in enumerate(linelist): 
					templist = line.split()
					addres = templist[2]
					templist[1] = dumppath+'/'+templist[1]
					if not os.path.isfile(templist[1]):
						for fielname in glob.glob(templist[1]+'*'):
							if addres  in fielname:
								templist[1] = fielname
					if len(templist[2])==10:
						templist[2] = 'a:0x0:'+templist[2]
					else:
						templist[2] = 'a:0x'+templist[2][2]+':0x'+templist[2][3:]
					linelist[index] = ' '.join(templist)
				with open(OUTDumpPath+'/temp/newload.cmm', 'w') as fileptr1:
					fileptr1.write('\n'.join(linelist))
		else:
			print ("Not able to detect load.cmm")
			if smmu_output or clara_output or smmu_64bt:
				print ("load.cmm needed for full dump loading, bailing out..")
				sys.exit()
	except:
		print ("Error arised while creating new load.cmm file")

	DumpSize = 0
	for file in possible_dump_name:
		dump_file_name = os.path.dirname(INDumpPath)+"//"+file
		if os.path.isfile(dump_file_name): DumpSize = DumpSize + os.path.getsize(dump_file_name)
	Enable_6GB_dumps = False
	if DumpSize > 4294967296 and smmu_enable == True: Enable_6GB_dumps = True 
	extension = os.path.splitext(str(INDumpPath))[1]
	load_elf_with_code = False
	if (extension == ".elf" or extension == ".ELF"):
		if targetid in md_rodata_txt_removed:
			load_elf_with_code = True
	print ('\nFetching Start_Address..........')
	if not start_address :
		if " " in INDumpPath : INDumpPath = "\""+INDumpPath+"\""
		extension = os.path.splitext(str(INDumpPath))[1]
		if (extension == ".elf" or extension == ".ELF"):
			command = '''python %s/readelf.py  %s %s''' % (CurrDirectory, INDumpPath, OUTDumpPath + r"/temp")
			process = subprocess.Popen(command, stdout=subprocess.PIPE,shell=True)
			process.wait()
			if os.path.isfile(OUTDumpPath + "//temp//ssr.txt"):
				file = open(OUTDumpPath + "//temp//ssr.txt", 'r')
				temp_strs = file.readlines()
				file.close()
				#print(temp_strs)
				if "1" in temp_strs[0]:
					for temp in temp_strs:
						#print(temp)
						if "ADSP_MINI" in temp or "ADSP_MD" in temp or "CDSP_MINI" in temp or "CDSP_MD" in temp:
							start_address = temp.split(";")[0]
							#print(start_address)
							break
				else:
					start_address = temp_strs[1].split(";")[0]
		# start_address = temp_str.split(",")[0]
		else :
			# if " " in load_dump_full : load_dump_full = "\""+load_dump_full+"\""
			command = '''python %s/Start_Address_Python3.py  %s %s %s %s %s'''%(CurrDirectory,INDumpPath,OUTDumpPath,targetid,subsystem,new_target_flag)
			# else:
			# command = '''python %s/Start_Address.py  %s %s %s %s %s %s %s'''%(CurrDirectory,INDumpPath,OUTDumpPath,targetid,slpi_flag,cdsp_flag,slpi_target_flag,new_target_flag)
			write_command_into_file(command)
			process = subprocess.Popen(command, stdout=subprocess.PIPE, shell=True)
			process.wait()
			#if not os.path.isfile(OUTDumpPath+"//temp//adspstartaddr.txt"):
			#	for file in possible_dump_name:
			#		if not file in INDumpPath:
			#			dump_file = os.path.dirname(INDumpPath)+"//"+file
			#			if os.path.isfile(dump_file):
			#				if start_address == False:
			#					command = '''python %s/Start_Address.py  %s %s %s %s %s %s %s'''%(CurrDirectory,dump_file,OUTDumpPath,targetid,slpi_flag,cdsp_flag,slpi_target_flag,new_target_flag)
			#					process = subprocess.Popen(command, stdout=subprocess.PIPE)
			#					process.wait()
			#					if os.path.isfile(OUTDumpPath+"//temp//adspstartaddr.txt"):
			#						INDumpPath = dump_file
			#						break

		if not start_address and not os.path.isfile(OUTDumpPath+"//temp//adspstartaddr.txt"):
			print ('Not Able to Extract Start_Address, subsystem not loaded probably. Please enter start Address manually.')
			start_address = input("Start_Addresss : ") 
	if start_address: ## If Start_Address is given
		extension = os.path.splitext(str(INDumpPath))[1]
		if extension == "":
			if binascii.hexlify(data) == "7f454c46": extension = ".ELF"
		file_dump = open(OUTDumpPath+"//temp//dumpformant.txt",'w')
		if (extension == ".elf" or extension == ".ELF"): file_dump.write('2')
		else: file_dump.write('1')
		file_dump.close()
		file = open(OUTDumpPath+"//temp//adspstartaddr.txt",'w')
		file.write(start_address)
		file.close()
	break
	
while True:  ## Opening T32 Window
	t32_file = OUTDumpPath+"/temp/config_sim_usb.t32"
	
	f_t32 = open(t32_file,'w+')
	if linux_flag:
		f_t32.write("OS=/n")
		f_t32.write("ID=SIM_${2}            ; unique ID needed for temporary file name uniqueness/n")
		f_t32.write("TMP="+OUTDumpPath+"/temp"+"           ; T32 temp file names are prepended with the unique ID above/n")
		f_t32.write("SYS="+T32_path+"                ; make system directory the same as the executable directory/n/n")
		f_t32.write("SCREEN=/n")
		f_t32.write("HEADER=${2}/n/n")
		f_t32.write("; Ethernet on Host information /n")
		f_t32.write("PBI=SIM/n")
		f_t32.write("/n")
		f_t32.write("; Printer settings/n")
		f_t32.write("PRINTER=WINDOWS/n/n")
		f_t32.write("; Screen fonts/n")
		f_t32.write("SCREEN=/n")
		f_t32.write("FONT=SMALL/n/n")
	else:
		f_t32.write("OS=\n")
		f_t32.write("ID=SIM_${2}            ; unique ID needed for temporary file name uniqueness\n")
		f_t32.write("TMP="+OUTDumpPath+"/temp"+"           ; T32 temp file names are prepended with the unique ID above\n")
		f_t32.write("SYS="+T32_path+"                ; make system directory the same as the executable directory\n\n")
		f_t32.write("SCREEN=\n")
		f_t32.write("HEADER=${2}\n\n")
		f_t32.write("; Ethernet on Host information \n")
		f_t32.write("PBI=SIM\n")
		f_t32.write("\n")
		f_t32.write("; Printer settings\n")
		f_t32.write("PRINTER=WINDOWS\n\n")
		f_t32.write("; Screen fonts\n")
		f_t32.write("SCREEN=\n")
		f_t32.write("FONT=SMALL\n\n")
	f_t32.close()
	
	while True: 
		if targetid in target_for_which_apr_logs_require: apr_logs_target_flag = True
		else: apr_logs_target_flag = False
		if targetid in unstip_fastrpc_module_target: unstrip_fastrpc_module_flag = True
		else: unstrip_fastrpc_module_flag = False
		if targetid in amss_mem_heap_target: amss_mem_heap_target_flag = True
		else: amss_mem_heap_target_flag = False
		if targetid in ClockDriver_Script_target: ClockDriver_Script_target_flag = True
		else: ClockDriver_Script_target_flag = False
		if targetid in list_of_target_for_timestamp_matching: list_of_target_for_timestamp_matching_flag = True
		else: list_of_target_for_timestamp_matching_flag = False
		if targetid in list_of_target_for_which_slpi_flag_need_to_set_true: list_of_target_for_which_slpi_flag_need_to_set_true_flag = True
		else: list_of_target_for_which_slpi_flag_need_to_set_true_flag = False
		d_load_binary_file_block_size_cdsp_flag = '0x01800000'
		if subsystem=="cdsp":
			for key,target_list in d_load_binary_file_block_size_cdsp.items():
				if targetid in target_list: d_load_binary_file_block_size_cdsp_flag = key
		elif subsystem=="slpi":
			d_load_binary_file_block_size_cdsp_flag = '0x02f00000'
		else:
			for key,target_list in d_load_binary_file_block_size_adsp.items():
				if targetid in target_list: d_load_binary_file_block_size_cdsp_flag = key
		if os.path.isfile(OUTDumpPath+"//temp//adspimagesize.txt"): #check from dump if size is different
			_f = open(OUTDumpPath+"//temp//adspimagesize.txt","r")
			temp = _f.readline()
			if temp:
				d_load_binary_file_block_size_cdsp_flag = temp
				#print("Image Size: ",d_load_binary_file_block_size_cdsp_flag)
		# print ("Checking for qurt_model_t32_path ")
		qurt_model_t32_path = 'False'
		for temp_quet_path in qurt_model_path:
			if 'Target_id_temp' in temp_quet_path: 
				temp_quet_path=temp_quet_path.replace('Target_id_temp',targetid)
			if os.access(CRM_buildpath+'/core/kernel/qurt/'+temp_quet_path+'/qurt_model.t32',os.R_OK):
				qurt_model_t32_path = CRM_buildpath+'/core/kernel/qurt/'+temp_quet_path
				break
		if qurt_model_t32_path == 'False':
			if os.access(CRM_buildpath+'//qurt_model.t32',os.R_OK):
				qurt_model_t32_path = CRM_buildpath
				print ('qurt_model    :',qurt_model_t32_path)
				
		Qube_va_guestos_initialize = ''
		for key,temp_target in qurt_model_Qube_va_guestos_dict.items():
			if targetid in temp_target: Qube_va_guestos_initialize = key
		if 'ROOT_target_id' in Qube_va_guestos_initialize: Qube_va_guestos_initialize = Qube_va_guestos_initialize.replace('target_id',targetid)
		add_mmu_create_initialize = 'null'
		for key,temp_target in qurt_model_add_variable_dict.items():
			if targetid in temp_target: add_mmu_create_initialize = key
		INDumpPath = INDumpPath.strip("\"")
		if os.path.dirname(INDumpPath)[len(os.path.dirname(INDumpPath))-1]=='//': INDumpPath_dir = os.path.dirname(INDumpPath)[:len(os.path.dirname(INDumpPath))-1]
		else: INDumpPath_dir = os.path.dirname(INDumpPath)
		pram_dump_addr = ""
		for key,target_list in pram_dump_list.items():
			if targetid in target_list: pram_dump_addr = key
		break
	
	arg_file = OUTDumpPath+"/temp/CMMArguments.txt"
	f_arg = open(arg_file,'w+')
	if " " in INDumpPath : INDumpPath = "\""+INDumpPath+"\""  
	if " " in ELF_filepath : ELF_filepath = "\""+ELF_filepath+"\"" 
	if " " in INDumpPath_dir: INDumpPath_dir = "\""+INDumpPath_dir+"\""
	cmd = '''%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n'''%(targetid,UniqueNumber,INDumpPath,OUTDumpPath,CRM_buildpath,CurrDirectory,ELF_filepath,crashman_lite,asha_flag,SOFILE,load_dump_full,quit_flag,smmu_enable,frpcshell,frpcshell_name,wp_smmu_enable,INDumpPath.strip("\"").split('\\')[-1],Enable_6GB_dumps,smmu_64bt,clara_output,title,opts.manual,opts.au,cpz_flag,slpi_target_flag,apr_logs_target_flag,amss_mem_heap_target_flag,ClockDriver_Script_target_flag,selected_cpu_version,d_load_binary_file_block_size_cdsp_flag,list_of_target_for_timestamp_matching_flag,list_of_target_for_which_slpi_flag_need_to_set_true_flag,qurt_model_t32_path,elf_symbol,sensor_elf_symbol,audio_elf_symbol,charger_elf_symbol,Qube_va_guestos_initialize,add_mmu_create_initialize,new_target_flag,unstrip_fastrpc_module_flag,ulog_flag,INDumpPath_dir,opts.ssc,use_asid_flag, smmu_output,autoscope,subsystem,addr_sepr_enable,pram_dump_addr,load_elf_with_code,opts.sdc)
	f_arg.write(cmd)
	f_arg.close()
	print ("\nStarting T32 for further processing.")
	print ("************************************")
	print ("\nProcessing Inputs Please Wait...")
	command = "do     "+CurrDirectory+"\\DSP_load_memorydump_crashman.cmm "+targetid+" "+OUTDumpPath
	write_command_into_file(command)
	if linux_flag:
		if os.path.exists(T32_path+"/bin/pc_linux64"): Path = T32_path+"/bin/pc_linux64"
		else: Path = T32_path
		# command = '''%s/t32mqdsp6 -s %s %s %s %s'''%(Path,OUTDumpPath+"/temp/config_sim_usb.t32",CurrDirectory+"/DSP_load_memorydump_crashman.cmm",targetid,OUTDumpPath)
		command = '''%s/t32mqdsp6 -s %s/DSP_load_memorydump_crashman.cmm %s %s'''%(Path,CurrDirectory,targetid,OUTDumpPath)
		bin = OUTDumpPath+"/temp/ProcessingCommands.txt"
		f_bin = open(bin,'a')
		f_bin.write(str(command)+'\n')
		f_bin.close()
		process_t32 = subprocess.Popen(command, stdout=subprocess.PIPE, shell=True)
		process.wait()
	elif quit_flag == True:
		if os.path.exists(T32_path+"//bin//windows64"): Path = T32_path+"//bin//windows64"
		else: Path = T32_path
		command = '''%s//t32mqdsp6.exe -c %s, %s %s %s'''%(Path,OUTDumpPath+"//temp//config_sim_usb.t32",CurrDirectory+"//DSP_load_memorydump_crashman.cmm",targetid,OUTDumpPath)
		process_t32 = subprocess.Popen(command, stdout=subprocess.PIPE)
	else:
		# T32_path = "C:\\T32"
		Path = T32_path+"\\bin\\windows64"
		if not os.path.exists(Path): Path = Path.split("\\bin")[0]
		OUTDumpPath = OUTDumpPath.replace('/','\\')
		command = '''%s\\t32mqdsp6.exe -c %s, %s %s %s'''%(Path,OUTDumpPath+"\\temp\\config_sim_usb.t32",CurrDirectory+"\\DSP_load_memorydump_crashman.cmm",targetid,OUTDumpPath)
		# print (command)
		process_t32 = subprocess.Popen(command, stdout=subprocess.PIPE)
	
	break
	
if asha_flag == True:
	# file_check=OUTDumpPath+"//temp//dumpsloaddone.txt"
	file_check=OUTDumpPath+"//temp//DSPAnalysis.end"
	waiting_interval_for_crashman = 20
	timeout = time.time() + 60*waiting_interval_for_crashman   # 5 minutes from now
	while True:
		test = 0
		if test == 5 or time.time() > timeout: 
			print ('Timeout.............')
			break
		if os.path.exists(file_check):
			print ("Dumps and ELF Loading Done!!!!!")
			break
		test = test - 1
	if not os.path.exists(file_check):
		process_t32.terminate()
		file = OUTDumpPath+"//DDOutput.txt"
		f_file = open(file,'a')    
		f_file.write("\nNo duplicates found.  For creating the CR, please contact assignee/triage team.\n")
		f_file.close()
		sys.exit()
	minutes=10
	dsp_check=OUTDumpPath+"//temp//DSPAnalysis.end"
	dsp_analy=OUTDumpPath+"//DSPAnalysis.txt"

	for i in range(0,minutes):
		time.sleep(60) #wait for 1min for checking
		if os.path.exists(dsp_check):
			cond = 1
			break
	if cond == 0:    
		f_dsp_check = open(dsp_check,'w+')
		f_dsp_analy = open(dsp_analy,'r+')
		for line in f_dsp_analy:
			f_dsp_check.write(line)
		f_dsp_analy.close()
		f_dsp_check.close()
	print ("Searching for JIRA tickets")
	log=OUTDumpPath+"//temp//JiraLog.txt"
	file = OUTDumpPath+"//DDOutput.txt"
	f_file = open(file,'a')    
	f_file.write("/nNo duplicates found.  For creating the CR, please contact assignee/triage team./n")
	f_file.close()
	dsp_check=OUTDumpPath+"//temp//DSPOutput.complete"
	dsp_analy=OUTDumpPath+"//temp//DSPAnalysis.end"
	f_dsp_check = open(dsp_check,'w+')
	f_dsp_analy = open(dsp_analy,'r+')
	for line in f_dsp_analy:
		f_dsp_check.write(line)
	f_dsp_analy.close()
	f_dsp_check.close()
	
if quit_flag == True:
	minutes=20
	dsp_check=OUTDumpPath+"//temp//DSPAnalysis.end"
	cond_1 = 0
	for i in range(0,minutes):
		time.sleep(60) #wait for 1min for checking
		if os.path.exists(dsp_check):
			cond_1 = 1
			break
	if cond_1 == 0:
		process_t32.terminate()
		raise ValueError('Crashman stuck or not able to load dumps properly.')
	
while True:  ## Waiting for Crashman to Run Completely
	file_check=OUTDumpPath+"//temp//DSPAnalysis.end"
	time.sleep(10) #wait for 1min for checking
	if os.path.exists(file_check):
		
		if etm_flag == True and smmu_enable == True:
			dumpfile = None
			if "tmc-etr.bin" in INDumpPath:
				dumpfile = INDumpPath
			elif "etr.bin" in INDumpPath:
				dumpfile = INDumpPath
			elif os.path.isfile(os.path.dirname(INDumpPath)+"\\tmc-etr.bin"):
				dumpfile = os.path.dirname(INDumpPath)+"\\tmc-etr.bin"
			elif os.path.isfile(os.path.dirname(INDumpPath)+"\\etr.bin"):
				dumpfile = os.path.dirname(INDumpPath)+"\\etr.bin"
			elif os.path.isfile(OUTDumpPath+"\\temp\\tmc-etr.bin"):
				dumpfile = OUTDumpPath+"\\temp\\tmc-etr.bin"
			elif os.path.isfile(OUTDumpPath+"\\temp\\etr.bin"):
				dumpfile = OUTDumpPath+"\\temp\\etr.bin"
				
			if dumpfile == None:
				print ("ETM Dump File is not accessible/available. Please Check the File Path.")
				sys.exit()
			
			f_out = open(OUTDumpPath+"\\temp\\load_adsp_etm_dump.cmm",'w')
			if selected_cpu_version == 'HexagonV68':
				f_out.write('SYStem.Down\n')
				f_out.write('SYStem.Reset\n')
				f_out.write('SYStem.CPU HexagonV68\n')
				f_out.write('SYStem.Up\n')
				f_out.write('Trace.RESET\n')
				f_out.write('\n')
				f_out.write('SYStem.CONFIG.ETB1.Base APB:0x86B09000\n')
				f_out.write('SYStem.CONFIG.ETM.Base DAP:0x86808000\n')
				f_out.write('SYStem.CONFIG.FUNNEL1.Base DAP:0x86045000\n')
				f_out.write('SYStem.CONFIG.FUNNEL2.Base DAP:0x86B08000\n')
				f_out.write('SYStem.CONFIG.FUNNEL3.Base DAP:0x86042000\n')
				f_out.write('SYStem.CONFIG.FUNNEL4.Base DAP:0x86804000\n')
				f_out.write('SYStem.CONFIG.FUNNEL5.Base DAP:0x8680C000\n')
				f_out.write('\n')
				f_out.write('SYStem.CONFIG.ETB1.ATBSource FUNNEL2\n')
				f_out.write('SYStem.CONFIG.ETB1.STACKMODE NOTSET\n')
				f_out.write('SYStem.CONFIG.ETB1.NOFLUSH OFF\n')
				f_out.write('SYStem.CONFIG.FUNNEL1.ATBSource FUNNEL3 1\n')
				f_out.write('SYStem.CONFIG.FUNNEL2.ATBSource FUNNEL1 7\n')
				f_out.write('SYStem.CONFIG.FUNNEL3.ATBSource FUNNEL4 2\n')
				f_out.write('SYStem.CONFIG.FUNNEL4.ATBSource FUNNEL5 3\n')
				f_out.write('SYStem.CONFIG.FUNNEL5.ATBSource ETM 0 ETMUPPER 1\n')
				f_out.write('SYStem.CONFIG.ETB.ATBSOURCE FUNNEL2\n')
			else:
				f_out.write('system.cpu '+selected_cpu_version+'\n')
				f_out.write('sys.config.etr.base 0x4\n')
				f_out.write('sys.config.tpiu.base 0x8\n')
				f_out.write('system.up\n')
				f_out.write('trace.method.la\n')
				f_out.write('etm.portmode wrapped\n')
				if new_target_flag:
					if subsystem=="cdsp":
						f_out.write('etm.traceid 0x26\n')
					else:        
						f_out.write('etm.traceid 0x28\n')
				else:        
					f_out.write('etm.traceid 0x28\n')
				f_out.write('etm.ca ON\n')
				f_out.write('analyzer.clock 500.mhz\n')
				f_out.write('la.mode.flowtrace.on\n')
				
			crash_log = OUTDumpPath+"\\temp\\Crashman_Log.txt"
			adsp = ""
			if os.path.isfile(crash_log):
				f_op = open(crash_log,'r')
				for line in f_op:
					if "ADSP build Provided  :   " in line:
						adsp = line.split('ADSP build Provided  :   ')[1]
					if "CDSP build Provided  :   " in line:
						adsp = line.split('CDSP build Provided  :   ')[1]
					if "Loading ELF:" in line:
						elf = line.split('Loading ELF:')[1]
						if ".\\build\\ms" in elf:
							elf = adsp.rstrip('\r\n') + "\\build\\ms\\" + elf.split('.\\build\\ms\\')[1]
						f_out.write('d.load.elf '+elf.rstrip('\r\n')+' /noclear\n')
					if "Loading "in line and "fastrpc_shell_img" in line:
						f_out.write('d.load.elf  '+line.replace('Loading ','').replace('/nocode','')+'\n')
				f_op.close()
			crash_log = OUTDumpPath+"\\temp\\loaddynmaic.cmm"
			if os.path.isfile(crash_log):
				f_op = open(crash_log,'r')
				for line in f_op:
					if "d.load.elf" in line:
						f_out.write(line.replace('/nocode',''))
				f_op.close()
			
			if selected_cpu_version == 'HexagonV68':
				f_out.write('Trace.METHOD.LA\n')
				f_out.write('ETM.CLOCK 1.MHz\n')
				f_out.write('ETM.TraceID 38.\n')
				f_out.write('ETM.STALL OFF\n')
				f_out.write('ETM.CycleAccurate ON\n')
				f_out.write('ETM.DataTrace ON\n')
				f_out.write('ETM.DataTraceSelect Cluster0+1\n') 
				f_out.write('ETM.PortMode.Wrapped\n')
				f_out.write('A.CLOCK 767.97mhz\n')
			
			f_out.write('la.import.etb '+dumpfile+'\n')
			f_out.write('\n')
			if selected_cpu_version == 'HexagonV68':
				f_out.write('t.l tp tpc tpinfo run Address CYcle data %len 60 sYmbol list.mix.off list.asm List.Address\n')
				f_out.write('t.l tpc run address cycle data symbol ti.back clocks.back clocks.z list.time list.asm list.NoDummy\n')
			else:
				f_out.write('trace.list tp tpc tpinfo def l.nd.off\n')
			f_out.write('enddo\n')    
			f_out.close()
			
			print ("\nStarting T32 for ETM Dump.")
			print ("************************************")
			t32_file = OUTDumpPath+"\\temp\\config_sim_usb1.t32"
			f_t32 = open(t32_file,'w+')
			f_t32.write("OS=\n")
			f_t32.write("ID=SIM_${4}            ; unique ID needed for temporary file name uniqueness\n")
			f_t32.write("TMP="+OUTDumpPath+"\\temp"+"           ; T32 temp file names are prepended with the unique ID above\n")
			f_t32.write("SYS="+T32_path+"                ; make system directory the same as the executable directory\n\n")
			f_t32.write("SCREEN=\n")
			f_t32.write("HEADER=${4}\n\n")
			f_t32.write("; Ethernet on Host information \n")
			f_t32.write("PBI=SIM\n")
			f_t32.write("\n")
			f_t32.write("; Printer settings\n")
			f_t32.write("PRINTER=WINDOWS\n\n")
			f_t32.write("; Screen fonts\n")
			f_t32.write("SCREEN=\n")
			f_t32.write("FONT=SMALL\n\n")
			f_t32.close()

			Path = T32_path+"\\bin\\windows64"
			if os.path.exists(Path):
				command = '''start %s\\bin\\windows64\\t32mqdsp6.exe -c %s, %s '''%(T32_path,OUTDumpPath+"\\temp\\config_sim_usb1.t32",OUTDumpPath+"\\temp\\load_adsp_etm_dump.cmm")
				print (command)
				os.system(command)
			else:    
				command = '''start %s\\t32mqdsp6.exe -c %s, %s '''%(T32_path,OUTDumpPath+"\\temp\\config_sim_usb1.t32",OUTDumpPath+"\\temp\\load_adsp_etm_dump.cmm")
				print (command)
				os.system(command)
		
		if os.path.exists(OUTDumpPath+"//AvailableLogs.txt"):
			os.rename(OUTDumpPath+"//AvailableLogs.txt", OUTDumpPath+"//temp//AvailableLogs.txt")
		if os.path.exists(OUTDumpPath+"//f3tokens_temp.txt"):
			os.rename(OUTDumpPath+"//f3tokens_temp.txt", OUTDumpPath+"//temp//f3tokens_temp.txt")
		if os.path.exists(OUTDumpPath+"//BAM.ulog"):
			os.rename(OUTDumpPath+"//BAM.ulog", OUTDumpPath+"//temp//BAM.ulog")
		if os.path.exists(OUTDumpPath+"//NPA Log.ulog"):
			os.rename(OUTDumpPath+"//NPA Log.ulog", OUTDumpPath+"//temp//NPA Log.ulog")
		if os.path.exists(OUTDumpPath+"//SLIMBUS.ulog"):
			os.rename(OUTDumpPath+"//SLIMBUS.ulog", OUTDumpPath+"//ulog//SLIMBUS.ulog")
		if os.path.exists(OUTDumpPath+"//search_op.json"):
			os.rename(OUTDumpPath+"//search_op.json", OUTDumpPath+"//temp//search_op.json")
		if os.path.exists(OUTDumpPath+"//Qurt_logs//Heap_Analysis_GuestOS.txt"):
			shutil.copy2(OUTDumpPath+"//Qurt_logs//Heap_Analysis_GuestOS.txt", OUTDumpPath+"//Def_Heap//Heap_Analysis_GuestOS.txt")
		if os.path.exists(OUTDumpPath+"//Qurt_logs//Heap_Analysis_Audio.txt"):
			shutil.copy2(OUTDumpPath+"//Qurt_logs//Heap_Analysis_Audio.txt", OUTDumpPath+"//Def_Heap_for_AUDIO_img//Heap_Analysis_Audio.txt")
		if os.path.exists(OUTDumpPath+"//Qurt_logs//Heap_Analysis_Sensors.txt"):
			shutil.copy2(OUTDumpPath+"//Qurt_logs//Heap_Analysis_Sensors.txt", OUTDumpPath+"//Def_Heap_forSensors_img//Heap_Analysis_Sensors.txt")
		command=''' python %s//all_thread_callstack.py %s'''%(CurrDirectory,OUTDumpPath)
		os.system(command)
		sysmon_parser = ""
		parser_path = ""
		if not linux_flag:
			sysmon_parser = "sysmon_parser.exe"
			parser_path = os.path.join(*[CRM_buildpath, "performance", "tools", "HTMLParser",sysmon_parser])
			if not os.path.isfile(parser_path):
				print("Couldn't find sysmon HTML parser, falling back to legacy sysmon parser")
				sysmon_parser = "SysmonParser.exe"
				parser_path = os.path.join(*[CRM_buildpath, "performance", "tools", sysmon_parser])
				if not os.path.isfile(parser_path):
					print("Couldn't find sysmon Legacy parser, ignoring sysmon parsing..!")
		else:
			sysmon_parser = "sysmon_parser_linux"
			parser_path = os.path.join(*[CRM_buildpath, "performance", "tools", "HTMLParser",sysmon_parser])
			if not os.path.isfile(parser_path):
				print("Couldn't find sysmon HTML parser for linux, ignoring sysmon parsing..!!")
		if os.path.isfile(parser_path):
			if os.path.isfile(OUTDumpPath+"//temp//sysmon_dump.bin"):
				print ("Processing sysmonparser")
			else:
				print ("Please wait...")
				time.sleep(30)
			if os.path.isfile(OUTDumpPath+"//temp//sysmon_dump.bin"):
				try:
					print ("Processing sysmonparser. Please wait...")
					sys1 = ''
					if title: sys1 = title
					else: sys1 = dateref
					command = parser_path
					if not linux_flag:
						if sysmon_parser == "SysmonParser.exe":
							command += " {out}//temp//sysmon_dump.bin {out}//sysmon_dump_{title} default  --crashman={out}//temp ".format(out=OUTDumpPath, title=sys1)
						else:
							command += " {out}//temp//sysmon_dump.bin --outdir {out}//sysmon_dump_{title} ".format(out=OUTDumpPath,title=sys1)
					else:
						os.system("chmod +x {}".format(parser_path))
					# command = '''////harv-sgande//Builds//Release//performance.adsp.7.0.crm4//adsp_proc//performance//tools//SysmonParser.exe %s//temp//sysmon_dump.bin %s//sysmon_dump_%s default  --crashman=%s//temp'''%(OUTDumpPath,OUTDumpPath,sys1,OUTDumpPath)
					bin = OUTDumpPath+"/temp/ProcessingCommands.txt"
					f_bin = open(bin,'a')
					f_bin.write('       '+str(command)+'\n')
					f_bin.close()
					os.system(command)
				except:
					print ("sysmon parser is not working")
		# for r,d,f in os.walk(OUTDumpPath+"//ulog"):
			# for file in f:
				# win_dump  = os.path.join(r,file)
				# if ".ulog" in win_dump:
					# file = open(win_dump,'r')
					# file_out = open(win_dump.replace('.ulog','_time.ulog'),'w')
					# for line in file:
						# try:
							# if "0x" in line[:2] or "0X" in line[:2]:
								# hex = line.split(':')[0]
								# ms = str(int(hex,16)/19200000.000).split('.')[1][:3]
								# sec = int(hex,16)/19200000
								# temp = str(datetime.timedelta(seconds=sec))
								# line_t = line.replace(hex,hex+" : "+temp+"."+ms+" ")
							# else:
								# line_t = line
						# except:
							# line_t = line
						# file_out.write(line_t)
					# file_out.close()
					# if os.path.isfile(win_dump.replace('.ulog','_time.ulog')):
						# shutil.copy2(win_dump.replace('.ulog','_time.ulog'), win_dump)
						# os.remove(win_dump.replace('.ulog','_time.ulog'))
					# file.close()
		break
	


while True: ## ulog time conversion
	path = OUTDumpPath+"/ulog"
	files = glob.glob(path + "/*.ulog")

	for file in files:
		convert.format(file,file)
	  
		
	
	path = OUTDumpPath+"/ulog/ULOG_Reports"
	files = glob.glob(path + "/*.ulog")
	for file in files:
		convert.format(file,file)
		
	path = OUTDumpPath+"/ulog/ULOG_Audio_Reports"
	files = glob.glob(path + "/*.ulog")
	for file in files:
		convert.format(file,file)
	
	path = OUTDumpPath+"/ulog/ULOG_charger_Reports"
	files = glob.glob(path + "/*.ulog")
	for file in files:
		convert.format(file,file)  

	path = OUTDumpPath+"/ulog/ULOG_sensor_Reports"
	files = glob.glob(path + "/*.ulog")
	for file in files:
		convert.format(file,file)
	break
	
while True:
	if not title:
		title = ""
	file = os.path.join(*[CurrDirectory,'crashman_report.py'])
	out_file = OUTDumpPath.split("Logs")[0]
	subprocess.run(["python",file,out_file,title],stdout=subprocess.DEVNULL)
	break