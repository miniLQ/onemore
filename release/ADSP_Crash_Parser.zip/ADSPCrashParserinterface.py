from PyQt6.QtCore import Qt, QThread
from PyQt6.QtWidgets import QWidget, QVBoxLayout
from qfluentwidgets import CardWidget
import sys
from pathlib import Path
import os
import subprocess

from PyQt6.QtCore import Qt, QPoint, QSize, QUrl, QRect, QPropertyAnimation, pyqtSignal, QObject
from PyQt6.QtGui import QIcon, QFont, QColor, QPainter
from PyQt6.QtWidgets import QApplication, QHBoxLayout, QVBoxLayout, QGraphicsOpacityEffect,QFileDialog

from qfluentwidgets import (CardWidget, setTheme, Theme, IconWidget, BodyLabel, CaptionLabel, PushButton,
                            TransparentToolButton, FluentIcon, RoundMenu, Action, ElevatedCardWidget,
                            ImageLabel, isDarkTheme, FlowLayout, MSFluentTitleBar, SimpleCardWidget,
                            HeaderCardWidget, InfoBarIcon, HyperlinkLabel, HorizontalFlipView, EditableComboBox,
                            PrimaryPushButton, TitleLabel, PillPushButton, setFont, ScrollArea,
                            VerticalSeparator, MSFluentWindow, NavigationItemPosition, GroupHeaderCardWidget,
                            ComboBox, SubtitleLabel, StateToolTip, Flyout)

from qfluentwidgets.components.widgets.acrylic_label import AcrylicBrush

from app.common.config import ROOTPATH
from app.common.logging import logger
from app.common.utils import linuxPath2winPath

GNU_TOOLS_PATH = os.path.join(ROOTPATH, 'tools', 'gnu-tools')
PYTHON_BIN_ROOT = linuxPath2winPath(os.path.join(ROOTPATH, 'tools', 'Python310'))
PYTHON_BIN_PATH = linuxPath2winPath(os.path.join(ROOTPATH, 'tools', 'Python310', 'python.exe'))

CURRENT_PLUGIN_DIR = os.path.dirname(__file__)

# resource文件夹的路径, 位于当前文件的上两级目录
resource_path = 'app/resource'


def isWin11():
    return sys.platform == 'win32' and sys.getwindowsversion().build >= 22000


if isWin11():
    from qframelesswindow import AcrylicWindow as Window
else:
    from qframelesswindow import FramelessWindow as Window

class StatisticsWidget(QWidget):
    """ Statistics widget """

    def __init__(self, title: str, value: str, parent=None):
        super().__init__(parent=parent)
        self.titleLabel = CaptionLabel(title, self)
        self.valueLabel = BodyLabel(value, self)
        self.vBoxLayout = QVBoxLayout(self)

        self.vBoxLayout.setContentsMargins(16, 0, 16, 0)
        self.vBoxLayout.addWidget(self.valueLabel, 0, Qt.AlignmentFlag.AlignTop)
        self.vBoxLayout.addWidget(self.titleLabel, 0, Qt.AlignmentFlag.AlignBottom)

        setFont(self.valueLabel, 18, QFont.Weight.DemiBold)
        self.titleLabel.setTextColor(QColor(96, 96, 96), QColor(206, 206, 206))


class AppInfoCard(SimpleCardWidget):
    """ App information card """

    def __init__(self, parent=None):
        super().__init__(parent)
        self.parent = parent
        self.iconLabel = ImageLabel(os.path.join(CURRENT_PLUGIN_DIR, "logo.png"), self)
        self.iconLabel.setBorderRadius(8, 8, 8, 8)
        self.iconLabel.scaledToWidth(120)

        self.nameLabel = TitleLabel('ADSP Crash Parser', self)

        #self.installButton = PrimaryPushButton('执行', self)
        #self.installButton.clicked.connect(self.installButtonClicked)
        #self.installButtonStateTooltip = None

        #self.companyLabel = HyperlinkLabel(
        #    QUrl('https://qfluentwidgets.com'), 'Shokokawaii Inc.', self)
        self.companyLabel = CaptionLabel('@Designed by iliuqi.', self)
        #self.installButton.setFixedWidth(160)

        #self.scoreWidget = StatisticsWidget('平均', '5.0', self)
        #self.separator = VerticalSeparator(self)
        #self.commentWidget = StatisticsWidget('评论数', '3K', self)

        self.descriptionLabel = BodyLabel(
            '高通平台开发提供给研发人员进行ADSP crash解析的一个工具', self)
        self.descriptionLabel.setWordWrap(True)

        self.tagButton = PillPushButton('QCOM', self)
        self.tagButton.setCheckable(False)
        setFont(self.tagButton, 12)
        self.tagButton.setFixedSize(80, 32)

        self.tagButton2 = PillPushButton('ADSP', self)
        self.tagButton2.setCheckable(False)
        setFont(self.tagButton2, 12)
        self.tagButton2.setFixedSize(80, 32)

        #self.shareButton = TransparentToolButton(FluentIcon.SHARE, self)
        #self.shareButton.setFixedSize(32, 32)
        #self.shareButton.setIconSize(QSize(14, 14))

        self.hBoxLayout = QHBoxLayout(self)
        self.vBoxLayout = QVBoxLayout()
        self.topLayout = QHBoxLayout()
        self.statisticsLayout = QHBoxLayout()
        self.buttonLayout = QHBoxLayout()

        self.initLayout()
        self.setBorderRadius(8)

    def initLayout(self):
        self.hBoxLayout.setSpacing(30)
        self.hBoxLayout.setContentsMargins(34, 24, 24, 24)
        self.hBoxLayout.addWidget(self.iconLabel)
        self.hBoxLayout.addLayout(self.vBoxLayout)

        self.vBoxLayout.setContentsMargins(0, 0, 0, 0)
        self.vBoxLayout.setSpacing(0)

        # name label and install button
        self.vBoxLayout.addLayout(self.topLayout)
        self.topLayout.setContentsMargins(0, 0, 0, 0)
        self.topLayout.addWidget(self.nameLabel)
        #self.topLayout.addWidget(self.installButton, 0, Qt.AlignmentFlag.AlignRight)

        # company label
        self.vBoxLayout.addSpacing(3)
        self.vBoxLayout.addWidget(self.companyLabel)

        # statistics widgets
        self.vBoxLayout.addSpacing(20)
        self.vBoxLayout.addLayout(self.statisticsLayout)
        self.statisticsLayout.setContentsMargins(0, 0, 0, 0)
        self.statisticsLayout.setSpacing(10)
        #self.statisticsLayout.addWidget(self.scoreWidget)
        #self.statisticsLayout.addWidget(self.separator)
        #self.statisticsLayout.addWidget(self.commentWidget)
        self.statisticsLayout.setAlignment(Qt.AlignmentFlag.AlignLeft)

        # description label
        self.vBoxLayout.addSpacing(20)
        self.vBoxLayout.addWidget(self.descriptionLabel)

        # button
        self.vBoxLayout.addSpacing(12)
        self.buttonLayout.setContentsMargins(0, 0, 0, 0)
        self.vBoxLayout.addLayout(self.buttonLayout)
        self.buttonLayout.addWidget(self.tagButton, 0, Qt.AlignmentFlag.AlignLeft)
        self.buttonLayout.addWidget(self.tagButton2, 1, Qt.AlignmentFlag.AlignLeft)
        #self.buttonLayout.addWidget(self.shareButton, 0, Qt.AlignmentFlag.AlignRight)

    # def installButtonClicked(self):
    #     if self.installButtonStateTooltip == '已执行':
    #         self.installButtonStateTooltip.setContent('已解析完成')
    #         self.installButtonStateTooltip.setState(True)
    #         self.installButton.setEnabled(True)
    #         self.installButtonStateTooltip = None
    #     else:
    #         self.installButtonStateTooltip = StateToolTip(
    #            '正在解析中', '请耐心等待哦~~', self 
    #         )
    #         # 设置点击后不允许再次点击
    #         self.installButton.setDisabled(True)
    #         # set position 在右下角
    #         self.parent.vBoxLayout.addSpacing(12)
    #         self.parent.vBoxLayout.addWidget(self.installButtonStateTooltip, 3, Qt.AlignmentFlag.AlignBottom|Qt.AlignmentFlag.AlignRight)
            
    #         self.installButtonStateTooltip.show()

class  Worker(QThread):
    signal = pyqtSignal(str)

    def __init__(self, command, shell=True, env=None):
        super().__init__()
        self.command = command
        self.shell = shell
        self.env = env

    def run(self):
        logger.info("Worker Thread ID: {}".format(QThread.currentThreadId()))
        #logger.info("Run command: {}".format(self.command))

        startupinfo = subprocess.STARTUPINFO()
        startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW

        if self.shell == True:
            command = "start cmd /K {}".format(self.command)
        else:
            command = self.command
        #logger.info("Run command: {}".format(self.command))

        process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True, env=self.env)
        
        while True:
            line = process.stdout.readline()
            if not line:
                break
            logger.info(line.decode('gbk').strip())

        self.signal.emit("SUCCESS")
        #self.signal.emit("ERROR")


class DescriptionCard(HeaderCardWidget):
    """ Description card """

    def __init__(self, parent=None):
        super().__init__(parent)
        self.descriptionLabel = BodyLabel(
            '高通平台开发提供给研发人员进行ADSP crash解析的一个工具。\n但是也支持自定义，手动下载工具覆盖本插件目录下的crashman目录\n'
            '注意：使用本工具前需要提前安装perl工具以及trace32工具！\n'
            '注意：使用本工具前需要提前安装perl工具以及trace32工具！\n'
            '注意：使用本工具前需要提前安装perl工具以及trace32工具！', self)

        self.descriptionLabel.setWordWrap(True)
        self.viewLayout.addWidget(self.descriptionLabel)
        self.setTitle('描述')
        self.setBorderRadius(8)

class SettinsCard(GroupHeaderCardWidget):

    def __init__(self, parent=None, parentvBoxLayout=None):
        super().__init__(parent)
        
        self.parentvBoxLayout = parentvBoxLayout

        self.setTitle("基本设置")
        self.setBorderRadius(8)

        # 初始化参数
        self.dumpdir = ""
        self.symbolsdir = ""
        self.srcdir = ""
        self.outputdir = ""

        # 设置状态提示
        self.stateTooltip = None
        self.bottomStateLayout = QHBoxLayout()

        # 选择按钮以及输入框部件
        self.dumpdirchooseButton = PushButton("选择")
        self.symbolsdirchooseButton = PushButton("选择")
        self.srcdirchooseButton = PushButton("选择")
        self.outputdirchooseButton = PushButton("选择")

        # 设置Button的点击事件
        self.dumpdirchooseButton.clicked.connect(self.dumpdirchooseButtonClicked)
        self.symbolsdirchooseButton.clicked.connect(self.symbolsdirchooseButtonClicked)
        self.srcdirchooseButton.clicked.connect(self.srcdirchooseButtonClicked)
        self.outputdirchooseButton.clicked.connect(self.outputdirchooseButtonClicked)

        # 显示终端部件
        self.comboBox = ComboBox()
        
        # 平台选择部件
        self.platformComboBox = EditableComboBox()

        # 设置部件的固定宽度
        self.dumpdirchooseButton.setFixedWidth(120)
        self.symbolsdirchooseButton.setFixedWidth(120)
        self.srcdirchooseButton.setFixedWidth(120)
        self.outputdirchooseButton.setFixedWidth(120)

        self.comboBox.setFixedWidth(120)
        self.comboBox.addItems(["始终显示", "始终隐藏"])
        # 设置comboBox的选择点击事件
        self.comboBox.currentIndexChanged.connect(self.comboBoxClicked)

        self.platformComboBox.setPlaceholderText("选择平台")
        # TODO: 从配置文件中读取平台信息
        items = ['strait', 'clarence', 'netrani', 'divar', 'mannar',]
        self.platformComboBox.setFixedWidth(120)
        # 设置默认值
        self.platformComboBox.setCurrentIndex(-1)
    
        self.platformComboBox.addItems(items)
        # 设置platformComboBox的编辑事件
        self.platformComboBox.currentIndexChanged.connect(self.platformComboBoxClicked)

        # 底部运行按钮以及提示
        self.hintIcon = IconWidget(InfoBarIcon.INFORMATION)
        self.hintLabel = BodyLabel("点击运行按钮开始解析")
        self.runButton = PrimaryPushButton(FluentIcon.PLAY_SOLID, "运行")
        self.bottomLayout = QHBoxLayout()

        # 设置底部工具栏布局
        self.hintIcon.setFixedSize(16, 16)
        self.bottomLayout.setSpacing(10)
        self.bottomLayout.setContentsMargins(24, 15, 24, 20)
        self.bottomLayout.addWidget(self.hintIcon, 0, Qt.AlignmentFlag.AlignLeft)
        self.bottomLayout.addWidget(self.hintLabel, 0, Qt.AlignmentFlag.AlignLeft)
        self.bottomLayout.addStretch(1)
        self.bottomLayout.addWidget(self.runButton, 0, Qt.AlignmentFlag.AlignRight)
        self.bottomLayout.setAlignment(Qt.AlignmentFlag.AlignVCenter)

        # 设置底部状态布局
        self.bottomStateLayout.setSpacing(10)
        self.bottomStateLayout.setContentsMargins(24, 15, 24, 20)
        self.bottomStateLayout.setAlignment(Qt.AlignmentFlag.AlignVCenter)
        self.bottomStateLayout.addStretch(1)


        self.ramdumpGroup = self.addGroup("{}/images/Rocket.svg".format(resource_path), "ADSP Dump目录", "[必选] 选择ADSP Dump的存放目录", self.dumpdirchooseButton)
        self.symbolsGroup = self.addGroup("{}/images/jsdesign.svg".format(resource_path), "ADSP Dump Symbols目录", "[必选] 选择ADSP Dump Symbols的存放目录", self.symbolsdirchooseButton)
        self.srcGroup = self.addGroup("{}/images/Joystick.svg".format(resource_path), "ADSP源码目录", "[必选] 选择ADSP源码的存放目录", self.srcdirchooseButton)
        self.outputGroup = self.addGroup("{}/images/Chicken.png".format(resource_path), "输出目录", "[可选] 选择解析结果的输出目录, 默认为ADSP Dump目录下的output目录", self.outputdirchooseButton)
        self.addGroup("{}/images/Joystick.svg".format(resource_path), "Platform", "选择基线平台", self.platformComboBox)
        self.addGroup("{}/images/Joystick.svg".format(resource_path), "运行终端", "设置是否显示命令行终端", self.comboBox)
        self.vBoxLayout.addLayout(self.bottomLayout)

        # 设置运行按钮的点击事件
        self.runButton.clicked.connect(self.runButtonClicked)

    def dumpdirchooseButtonClicked(self):
        logger.info("[ADSP Crash Parser] Choose Button Clicked")
        # 弹出windows文件选择框
        self.dumpdir = QFileDialog.getExistingDirectory(self, "选择文件夹")
        # 转成windows路径
        self.dumpdir = linuxPath2winPath(self.dumpdir)
        # 打印选择的文件路径
        logger.info("[ADSP Crash Parser] Choose Dump Directory: {}".format(self.dumpdir))
        
        if self.dumpdir == "":
            self.dumpdirchooseButton.setText("选择")
            self.ramdumpGroup.setContent("请选择Ramdump的存放目录")
        else:
            # 设置chooseButton的文字显示已选择
            self.dumpdirchooseButton.setText("已选择")
            logger.info("path length: {}".format(len(self.dumpdir)))
            # 判断self.dumpdir的长度是否大于120
            if len(self.dumpdir) > 120:
                # 截取前50个字符和后70个字符
                self.ramdumpGroup.setContent("{}.........{}".format(self.dumpdir[0:50], self.dumpdir[-70:]))
            else:
                self.ramdumpGroup.setContent(self.dumpdir)

    def symbolsdirchooseButtonClicked(self):
        logger.info("[ADSP Crash Parser] Symbols Choose Button Clicked")
        # 弹出windows文件选择框
        self.symbolsdir = QFileDialog.getExistingDirectory(self, "选择文件夹")
        # 转成windows路径
        self.symbolsdir = linuxPath2winPath(self.symbolsdir)
        # 打印选择的文件路径
        logger.info("[ADSP Crash Parser] Choose Symbols Directory: {}".format(self.symbolsdir))

        if self.symbolsdir == "":
            self.symbolsdirchooseButton.setText("选择")
            self.symbolsGroup.setContent("请选择Symbols的存放目录")
        else:
            # 设置chooseButton的文字显示已选择
            self.symbolsdirchooseButton.setText("已选择")
            logger.info("path length: {}".format(len(self.symbolsdir)))
            # 判断self.symbolsdir的长度是否大于120
            if len(self.symbolsdir) > 120:
                # 截取前50个字符和后70个字符
                self.symbolsGroup.setContent("{}.........{}".format(self.symbolsdir[0:50], self.symbolsdir[-70:]))
            else:
                self.symbolsGroup.setContent(self.symbolsdir)

    def srcdirchooseButtonClicked(self):
        logger.info("[ADSP Crash Parser] Src Choose Button Clicked")
        # 弹出windows文件选择框
        self.srcdir = QFileDialog.getExistingDirectory(self, "选择文件夹")
        # 转成windows路径
        self.srcdir = linuxPath2winPath(self.srcdir)
        # 打印选择的文件路径
        logger.info("[ADSP Crash Parser] Choose Src Directory: {}".format(self.srcdir))

        if self.srcdir == "":
            self.srcdirchooseButton.setText("选择")
            self.srcGroup.setContent("请选择Src的存放目录")
        else:
            # 设置chooseButton的文字显示已选择
            self.srcdirchooseButton.setText("已选择")
            logger.info("path length: {}".format(len(self.srcdir)))
            # 判断self.srcdir的长度是否大于120
            if len(self.srcdir) > 120:
                # 截取前50个字符和后70个字符
                self.srcGroup.setContent("{}.........{}".format(self.srcdir[0:50], self.srcdir[-70:]))
            else:
                self.srcGroup.setContent(self.srcdir)

    def outputdirchooseButtonClicked(self):
        logger.info("[ADSP Crash Parser] Output Choose Button Clicked")
        # 弹出windows文件选择框
        self.outputdir = QFileDialog.getExistingDirectory(self, "选择文件夹")
        # 转成windows路径
        self.outputdir = linuxPath2winPath(self.outputdir)
        # 打印选择的文件路径
        logger.info("[ADSP Crash Parser] Choose Output Directory: {}".format(self.outputdir))

        if self.outputdir == "":
            self.outputdirchooseButton.setText("选择")
            # 如果self.outputdir为空, 设置输出目录的内容为self.dumpdir下的output目录
            self.outputdir = linuxPath2winPath(os.path.join(self.dumpdir, 'output_adsp'))
        else:
            # 设置chooseButton的文字显示已选择
            self.outputdirchooseButton.setText("已选择")
            # 判断self.outputdir的长度是否大于120
            if len(self.outputdir) > 120:
                # 截取前50个字符和后70个字符
                self.outputGroup.setContent("{}.........{}".format(self.outputdir[0:50], self.outputdir[-70:]))
            else:
                self.outputGroup.setContent(self.outputdir)


    def comboBoxClicked(self, index):
        logger.info("[ADSP Crash Parser] ComboBox Clicked: {}".format(index))
        # 打印当前选择的值
        logger.info("[ADSP Crash Parser] Current Index: {}".format(self.comboBox.currentText()))

    def platformComboBoxClicked(self, index):
        logger.info("[ADSP Crash Parser] Platform ComboBox Clicked: {}".format(index))
        # 打印当前选择的值
        logger.info("[ADSP Crash Parser] Current Index: {}".format(self.platformComboBox.currentText()))

    def showNoSelectFileFlyout(self):
        Flyout.create(
            icon=InfoBarIcon.ERROR,
            title='Required is not selected',
            content="请确认必选项是否已经选择！",
            target=self.runButton,
            parent=self.window()
        )

    def customSignalHandler(self, value):
        # 接收到解析命令结束的信号
        logger.info("[ADSP Crash Parser] Custom signal handler: {}".format(value))
        if value == "SUCCESS":
            self.stateTooltip.setContent('解析完成')
            self.stateTooltip.setState(True)
            self.runButton.setEnabled(True)
            self.stateTooltip.show()

        elif value == "ERROR":
            self.stateTooltip.setContent('解析失败')
            self.stateTooltip.setState(False)
            self.runButton.setEnabled(True)
            self.stateTooltip.show()
        else:
            logger.info(value)

        # 打开输出目录
        os.system("start {}".format(self.outputdir))

    def start_task(self, command, shell):
        logger.info("[ADSP Crash Parser] Start task")
        self.worker = Worker(command, shell=shell)
        self.worker.signal.connect(self.customSignalHandler)
        self.worker.start()

    def runButtonClicked(self):
        logger.info("[ADSP Crash Parser] Run Button Clicked")
        # 获取chooseButton/ vmlinuxButton/ comboBox/ platformComboBox
        logger.info("[ADSP Crash Parser] Dump directory: {}".format(self.dumpdir))
        logger.info("[ADSP Crash Parser] symbols directory: {}".format(self.symbolsdir))
        logger.info("[ADSP Crash Parser] Src directory: {}".format(self.srcdir))

        if self.outputdir == "":
            self.outputdirchooseButton.setText("选择")
            # 如果self.outputdir为空, 设置输出目录的内容为self.dumpdir下的output目录
            self.outputdir = linuxPath2winPath(os.path.join(self.dumpdir, 'output_adsp'))

        logger.info("[ADSP Crash Parser] Output directory: {}".format(self.outputdir))

        logger.info("[ADSP Crash Parser] platform: {}".format(self.platformComboBox.currentText()))


        if self.comboBox.currentText() == "始终显示":
            shell = True
        else:
            shell = False

        logger.info("[ADSP Crash Parser] Display terminal: {}".format(shell))

        # 判断宿主机是否安装了perl工具(执行perl －ｖ)
        perl_command = 'perl -v'
        perl_process = subprocess.Popen(perl_command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
        perl_output, perl_error = perl_process.communicate()
        if perl_process.returncode != 0:
            logger.error("[ADSP Crash Parser] Perl is not installed or not found in PATH")
            Flyout.create(
                icon=InfoBarIcon.ERROR,
                title='Perl未安装',
                content="请确认系统中已经安装了Perl工具并确认已经添加到环境变量中！",
                target=self.runButton,
                parent=self.window()
            )
            return

        if self.dumpdir == "" or self.symbolsdir == "" or self.srcdir == "":
            self.showNoSelectFileFlyout()
        else:
            self.stateTooltip = StateToolTip('正在解析', '客官请耐心等待哦~~', self)
            # 状态提示放到中心位置
            self.bottomStateLayout.addWidget(self.stateTooltip, 0, Qt.AlignmentFlag.AlignRight)
            self.vBoxLayout.addLayout(self.bottomStateLayout)
            # 显示状态提示
            self.stateTooltip.show()

            # runbuton按钮设置为不可点击
            self.runButton.setDisabled(True)

            logger.info("[ADSP Crash Parser] Run parse with Python environment: {}".format(PYTHON_BIN_PATH))
            crashman_tool_path = linuxPath2winPath(os.path.join(CURRENT_PLUGIN_DIR, 'crashman'))

            logger.info("[ADSP Crash Parser] Crashman tool path: {}".format(crashman_tool_path))

            if os.path.exists(self.outputdir) == False:
                os.makedirs(self.outputdir)

            env = os.environ.copy()
            env['PATH'] = os.pathsep.join([os.environ['PATH'], PYTHON_BIN_ROOT])
            env['PATH'] = os.pathsep.join([env['PATH'], os.path.join(PYTHON_BIN_ROOT, 'Scripts')])

            command = '{} {}/adspcrashman.py -t {} -d {} -o {} -b {} -e {}'.format(
                PYTHON_BIN_PATH,
                crashman_tool_path,
                self.platformComboBox.currentText(),
                os.path.join(self.dumpdir, "DDRCS0_0.BIN"),
                self.outputdir,
                self.srcdir,
                self.symbolsdir
            )

            logger.info("[ADSP Crash Parser] Run command: {}".format(command))

            self.start_task(command, shell)
    

class LightBox(QWidget):
    """ Light box """

    def __init__(self, parent=None):
        super().__init__(parent=parent)
        if isDarkTheme():
            tintColor = QColor(32, 32, 32, 200)
        else:
            tintColor = QColor(255, 255, 255, 160)

        self.acrylicBrush = AcrylicBrush(self, 30, tintColor, QColor(0, 0, 0, 0))

        self.opacityEffect = QGraphicsOpacityEffect(self)
        self.opacityAni = QPropertyAnimation(self.opacityEffect, b"opacity", self)
        self.opacityEffect.setOpacity(1)
        self.setGraphicsEffect(self.opacityEffect)

        self.vBoxLayout = QVBoxLayout(self)
        self.closeButton = TransparentToolButton(FluentIcon.CLOSE, self)
        self.flipView = HorizontalFlipView(self)
        self.nameLabel = BodyLabel('屏幕截图 1', self)
        self.pageNumButton = PillPushButton('1 / 4', self)

        self.pageNumButton.setCheckable(False)
        self.pageNumButton.setFixedSize(80, 32)
        setFont(self.nameLabel, 16, QFont.Weight.DemiBold)

        self.closeButton.setFixedSize(32, 32)
        self.closeButton.setIconSize(QSize(14, 14))
        self.closeButton.clicked.connect(self.fadeOut)

        self.vBoxLayout.setContentsMargins(26, 28, 26, 28)
        self.vBoxLayout.addWidget(self.closeButton, 0, Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignTop)
        self.vBoxLayout.addWidget(self.flipView, 1)
        self.vBoxLayout.addWidget(self.nameLabel, 0, Qt.AlignmentFlag.AlignHCenter)
        self.vBoxLayout.addSpacing(10)
        self.vBoxLayout.addWidget(self.pageNumButton, 0, Qt.AlignmentFlag.AlignHCenter)

        self.flipView.addImages([
            '{}/images/shoko1.jpg'.format(resource_path), '{}/images/shoko2.jpg'.format(resource_path),
            '{}/images/shoko3.jpg'.format(resource_path), '{}/images/shoko4.jpg'.format(resource_path),
        ])
        self.flipView.currentIndexChanged.connect(self.setCurrentIndex)

    def setCurrentIndex(self, index: int):
        self.nameLabel.setText(f'屏幕截图 {index + 1}')
        self.pageNumButton.setText(f'{index + 1} / {self.flipView.count()}')
        self.flipView.setCurrentIndex(index)

    def paintEvent(self, e):
        if self.acrylicBrush.isAvailable():
            return self.acrylicBrush.paint()

        painter = QPainter(self)
        painter.setPen(Qt.NoPen)
        if isDarkTheme():
            painter.setBrush(QColor(32, 32, 32))
        else:
            painter.setBrush(QColor(255, 255, 255))

        painter.drawRect(self.rect())

    def resizeEvent(self, e):
        w = self.width() - 52
        self.flipView.setItemSize(QSize(w, w * 9 // 16))

    def fadeIn(self):
        rect = QRect(self.mapToGlobal(QPoint()), self.size())
        self.acrylicBrush.grabImage(rect)

        self.opacityAni.setStartValue(0)
        self.opacityAni.setEndValue(1)
        self.opacityAni.setDuration(150)
        self.opacityAni.start()
        self.show()

    def fadeOut(self):
        self.opacityAni.setStartValue(1)
        self.opacityAni.setEndValue(0)
        self.opacityAni.setDuration(150)
        self.opacityAni.finished.connect(self._onAniFinished)
        self.opacityAni.start()

    def _onAniFinished(self):
        self.opacityAni.finished.disconnect(self._onAniFinished)
        self.hide()

class ADSPCrashParserCardsInfo(ScrollArea):
    """ Linux Ramdump Parser Subinterface """

    def __init__(self, parent=None, routeKey=None):
        super().__init__(parent=parent)

        self.view = QWidget(self)

        self.routeKey = routeKey

        self.vBoxLayout = QVBoxLayout(self.view)
        self.appCard = AppInfoCard(parent=self)
        #self.galleryCard = GalleryCard(self)
        self.descriptionCard = DescriptionCard(self)
        self.settingCard = SettinsCard(self, parentvBoxLayout=self.vBoxLayout)
        #self.systemCard = SystemRequirementCard(self)

        self.lightBox = LightBox(self)
        self.lightBox.hide()
        #self.galleryCard.flipView.itemClicked.connect(self.showLightBox)

        self.setWidget(self.view)
        self.setWidgetResizable(True)
        self.setObjectName(routeKey)

        self.vBoxLayout.setSpacing(25)
        self.vBoxLayout.setContentsMargins(0, 0, 10, 30)
        self.vBoxLayout.addWidget(self.appCard, 0, Qt.AlignmentFlag.AlignTop)
        #self.vBoxLayout.addWidget(self.galleryCard, 0, Qt.AlignmentFlag.AlignTop)
        self.vBoxLayout.addWidget(self.descriptionCard, 1, Qt.AlignmentFlag.AlignTop)
        self.vBoxLayout.addWidget(self.settingCard, 2, Qt.AlignmentFlag.AlignTop)

        #self.vBoxLayout.addWidget(self.systemCard, 0, Qt.AlignmentFlag.AlignTop)

        self.enableTransparentBackground()

    def showLightBox(self):
        index = self.galleryCard.flipView.currentIndex()
        self.lightBox.setCurrentIndex(index)
        self.lightBox.fadeIn()

    def resizeEvent(self, e):
        super().resizeEvent(e)
        self.lightBox.resize(self.size())


class ADSPCrashParserInterface:
    def __init__(self, parent=None, mainWindow=None):
        self.parent = parent
        self.mainWindow = mainWindow

    def addTab(self, routeKey, text, icon):
        logger.info('[TAB ADD] {}'.format(routeKey))
        self.mainWindow.tabBar.addTab(routeKey, text, icon)

        # tab左对齐
        self.mainWindow.showInterface.addWidget(ADSPCrashParserCardsInfo(routeKey=routeKey))
        self.mainWindow.showInterface.setCurrentWidget(self.mainWindow.showInterface.findChild(ADSPCrashParserCardsInfo, routeKey))
        self.mainWindow.stackedWidget.setCurrentWidget(self.mainWindow.showInterface)
        self.mainWindow.tabBar.setCurrentIndex(self.mainWindow.tabBar.count() - 1)
