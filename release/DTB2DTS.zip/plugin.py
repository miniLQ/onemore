from loguru import logger
import os

UNIQUE_NAME = "DTB2DTS"

CURRENT_PLUGIN_DIR = os.path.dirname(os.path.abspath(__file__))

def register(main_window):

    def on_open():

        command = os.path.join(CURRENT_PLUGIN_DIR, 'dtb2dts.exe')
        os.system(command)
        logger.info("[Plugin {}] Executed command: {}".format(UNIQUE_NAME, command))

    main_window.generalInterface.addCard(os.path.join(CURRENT_PLUGIN_DIR, "logo.png"), "DTB2DTS", '@designed by iliuqi.', "DTB2DTS")

    main_window.registerPluginOpener(UNIQUE_NAME, on_open)

