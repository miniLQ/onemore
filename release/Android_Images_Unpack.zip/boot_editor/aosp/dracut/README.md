https://github.com/dracutdevs/dracut/tree/master/skipcpio
