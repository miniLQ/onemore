# dispol
decompile binary selinux policy file
Android sepolicy file is `/sys/fs/selinux/policy`
```
make all
./dispol <policy_file>
```
