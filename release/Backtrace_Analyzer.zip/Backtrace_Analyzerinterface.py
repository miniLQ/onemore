from PyQt6.QtCore import Qt, QThread, pyqtSignal
from PyQt6.QtWidgets import QWidget, QVBoxLayout
import sys
import os
import subprocess
import time
import re
from collections import defaultdict

from PyQt6.QtCore import Qt, QPoint, QSize, QRect, QPropertyAnimation, pyqtSignal
from PyQt6.QtGui import QIcon, QFont, QColor, QPainter
from PyQt6.QtWidgets import QApplication, QHBoxLayout, QVBoxLayout, QGraphicsOpacityEffect, QFileDialog

from qfluentwidgets import (IconWidget, BodyLabel, CaptionLabel, PushButton,
                            TransparentToolButton, FluentIcon, SimpleCardWidget,
                            HeaderCardWidget, InfoBarIcon, HorizontalFlipView,
                            PrimaryPushButton, TitleLabel, PillPushButton, setFont, ScrollArea,
                            GroupHeaderCardWidget, StateToolTip, Flyout, CheckBox, ImageLabel, 
                            isDarkTheme, MessageBox)

from qfluentwidgets.components.widgets.acrylic_label import AcrylicBrush

from app.common.config import ROOTPATH
from app.common.logging import logger
from app.common.utils import linuxPath2winPath

TOOLS_PATH = os.path.join(ROOTPATH, 'tools')
LLVMTOOL_PATH = os.path.join(TOOLS_PATH, "android-sdk", "bin")

CURRENT_PLUGIN_DIR = os.path.dirname(__file__)
resource_path = 'app/resource'


def isWin11():
    return sys.platform == 'win32' and sys.getwindowsversion().build >= 22000


if isWin11():
    from qframelesswindow import AcrylicWindow as Window
else:
    from qframelesswindow import FramelessWindow as Window

class StatisticsWidget(QWidget):
    """ Statistics widget """

    def __init__(self, title: str, value: str, parent=None):
        super().__init__(parent=parent)
        self.titleLabel = CaptionLabel(title, self)
        self.valueLabel = BodyLabel(value, self)
        self.vBoxLayout = QVBoxLayout(self)

        self.vBoxLayout.setContentsMargins(16, 0, 16, 0)
        self.vBoxLayout.addWidget(self.valueLabel, 0, Qt.AlignmentFlag.AlignTop)
        self.vBoxLayout.addWidget(self.titleLabel, 0, Qt.AlignmentFlag.AlignBottom)

        setFont(self.valueLabel, 18, QFont.Weight.DemiBold)
        self.titleLabel.setTextColor(QColor(96, 96, 96), QColor(206, 206, 206))

class AppInfoCard(SimpleCardWidget):
    """ Heap App information card """

    def __init__(self, parent=None):
        super().__init__(parent)
        self.parent = parent
        self.iconLabel = ImageLabel("{}".format(os.path.join(CURRENT_PLUGIN_DIR, "logo.png")), self)
        self.iconLabel.setBorderRadius(8, 8, 8, 8)
        self.iconLabel.scaledToWidth(120)

        self.nameLabel = TitleLabel('Heap_Analyzer', self)
        self.companyLabel = CaptionLabel('@Designed by charter.', self)
        self.descriptionLabel = BodyLabel(
            'Heap_Analyzer 工具用于解析Android Native堆转储文件(heap dump)，结合内存映射(maps)文件和符号表进行地址解析', self)
        self.descriptionLabel.setWordWrap(True)

        self.tagButton = PillPushButton('addr2line', self)
        self.tagButton.setCheckable(False)
        setFont(self.tagButton, 12)
        self.tagButton.setFixedSize(85, 32)

        self.tagButton2 = PillPushButton('backtrace', self)
        self.tagButton2.setCheckable(False)
        setFont(self.tagButton2, 12)
        self.tagButton2.setFixedSize(85, 32)

        self.hBoxLayout = QHBoxLayout(self)
        self.vBoxLayout = QVBoxLayout()
        self.topLayout = QHBoxLayout()
        self.statisticsLayout = QHBoxLayout()
        self.buttonLayout = QHBoxLayout()

        self.initLayout()
        self.setBorderRadius(8)

    def initLayout(self):
        self.hBoxLayout.setSpacing(30)
        self.hBoxLayout.setContentsMargins(34, 24, 24, 24)
        self.hBoxLayout.addWidget(self.iconLabel)
        self.hBoxLayout.addLayout(self.vBoxLayout)

        self.vBoxLayout.setContentsMargins(0, 0, 0, 0)
        self.vBoxLayout.setSpacing(0)

        # name label
        self.vBoxLayout.addLayout(self.topLayout)
        self.topLayout.setContentsMargins(0, 0, 0, 0)
        self.topLayout.addWidget(self.nameLabel)

        # company label
        self.vBoxLayout.addSpacing(3)
        self.vBoxLayout.addWidget(self.companyLabel)

        # statistics widgets
        self.vBoxLayout.addSpacing(20)
        self.vBoxLayout.addLayout(self.statisticsLayout)
        self.statisticsLayout.setContentsMargins(0, 0, 0, 0)
        self.statisticsLayout.setSpacing(10)
        self.statisticsLayout.setAlignment(Qt.AlignmentFlag.AlignLeft)

        # description label
        self.vBoxLayout.addSpacing(20)
        self.vBoxLayout.addWidget(self.descriptionLabel)

        # button
        self.vBoxLayout.addSpacing(12)
        self.buttonLayout.setContentsMargins(0, 0, 0, 0)
        self.vBoxLayout.addLayout(self.buttonLayout)
        self.buttonLayout.addWidget(self.tagButton, 0, Qt.AlignmentFlag.AlignLeft)
        self.buttonLayout.addWidget(self.tagButton2, 1, Qt.AlignmentFlag.AlignLeft)

class DescriptionCard(HeaderCardWidget):
    """ Heap Description card """

    def __init__(self, parent=None):
        super().__init__(parent)
        self.descriptionLabel = BodyLabel(
            'Heap_Analyzer 工具用于解析Android Native堆转储文件(backtrace)，结合内存映射(maps)文件和符号表进行调用栈地址解析。\n'
            '可用于展锐平台抓取的data/local/tmp/backtrace_heap.<pid>解析\n\n'
            '解析步骤：\n'
            '1. 选择堆转储文件(heap dump) - 该文件通常也包含内存映射信息\n'
            '2. 选择符号表目录(symbols)\n'
            '3. 执行解析\n'
            '4. 解析结果将生成在同目录下的"_heap_analysis.txt"文件中\n\n'
            '支持功能：\n'
            '- 自动在符号目录中搜索对应的ELF文件\n'
            '- 支持批量地址解析\n'
            '- 可选的调试输出\n'
            '- 支持多个符号目录搜索', self)

        self.descriptionLabel.setWordWrap(True)
        self.viewLayout.addWidget(self.descriptionLabel)
        self.setTitle('描述')
        self.setBorderRadius(8)

class Worker(QThread):
    """ Worker thread for heap parsing """
    signal = pyqtSignal(str)
    log_signal = pyqtSignal(str)

    def __init__(self, heap_file, symbols_dirs, tools_dir, debug_enabled=False):
        super().__init__()
        self.heap_file = heap_file
        self.symbols_dirs = symbols_dirs
        self.tools_dir = tools_dir
        self.debug_enabled = debug_enabled
        
    def log(self, message):
        """Log message with debug control"""
        if self.debug_enabled:
            self.log_signal.emit(message)
    
    def is_valid_elf(self, file_path):
        """Check if file is a valid ELF file"""
        if not os.path.exists(file_path):
            return False
        try:
            with open(file_path, 'rb') as f:
                magic = f.read(4)
                return magic == b'\x7fELF'
        except:
            return False
    
    def find_elf_in_symbols(self, original_path):
        """Find ELF file in symbol directories"""
        original_path = original_path.replace('/', '\\').strip()
        
        # 1. Try path mapping
        for symbol_dir in self.symbols_dirs:
            rel_path = original_path.lstrip('\\').lstrip('/')
            mapped_path = os.path.join(symbol_dir, rel_path)
            
            if os.path.exists(mapped_path) and self.is_valid_elf(mapped_path):
                self.log(f"[OK] Found mapped file in {symbol_dir}: {mapped_path}")
                return mapped_path
        
        # 2. Search by filename recursively
        filename = os.path.basename(original_path)
        for symbol_dir in self.symbols_dirs:
            for root, _, files in os.walk(symbol_dir):
                if filename in files:
                    found_path = os.path.join(root, filename)
                    if self.is_valid_elf(found_path):
                        self.log(f"[OK] Found matching file in {symbol_dir}: {found_path}")
                        return found_path
                    else:
                        self.log(f"[WARN] Invalid ELF file: {found_path}")
        
        return None
    
    def parse_maps(self, maps_file):
        """Parse memory maps file - 与堆转储文件是同一个文件"""
        maps = []
        with open(maps_file, 'r', encoding='utf-8', errors='ignore') as f:
            for line in f:
                if not line.strip():
                    continue
                try:
                    parts = re.split(r'\s+', line.strip())
                    if len(parts) < 6:
                        continue
                    
                    if '-' not in parts[0]:
                        continue
                    
                    addr_range = parts[0]
                    perms = parts[1]
                    offset = parts[2]
                    elf_path = parts[5]
                    
                    # Only process executable segments
                    if 'x' not in perms:
                        continue
                    
                    start, end = addr_range.split('-')
                    maps.append({
                        'start': int(start, 16),
                        'end': int(end, 16),
                        'offset': int(offset, 16),
                        'elf_path': elf_path
                    })
                except Exception as e:
                    continue
        self.log(f"Successfully parsed {len(maps)} executable memory segments")
        return maps
    
    def resolve_addresses(self, addresses, maps_info):
        """Resolve addresses to symbols"""
        resolved = {}
        elf_groups = defaultdict(list)
        cache = {}
        
        for addr in addresses:
            runtime_addr = int(addr, 16)
            found = False
            
            for segment in maps_info:
                if segment['start'] <= runtime_addr < segment['end']:
                    # Calculate offset in ELF file
                    elf_offset = runtime_addr - segment['start'] + segment['offset']
                    elf_addr = hex(elf_offset)[2:]
                    
                    elf_path = segment['elf_path']
                    self.log(f"Processing address 0x{addr}: mapped to {elf_path} (offset 0x{elf_addr})")
                    
                    # Check cache
                    if elf_path in cache:
                        resolved_path = cache[elf_path]
                    else:
                        # Check if original path exists
                        if os.path.exists(elf_path) and self.is_valid_elf(elf_path):
                            resolved_path = elf_path
                        else:
                            # Search in symbol directories
                            resolved_path = self.find_elf_in_symbols(elf_path)
                    
                    # Update cache
                    cache[elf_path] = resolved_path
                    
                    # Record parsing info
                    if resolved_path:
                        elf_groups[resolved_path].append({
                            'runtime_addr': addr,
                            'elf_addr': elf_addr,
                            'original_path': elf_path
                        })
                    else:
                        resolved[addr] = f"ELF missing: {elf_path}"
                    
                    found = True
                    break
            
            if not found:
                resolved[addr] = "Address not in any executable memory segment"
        
        # Batch resolve addresses
        for elf_path, addrs in elf_groups.items():
            hex_addrs = [f"0x{entry['elf_addr']}" for entry in addrs]
            self.log(f"Resolving {len(hex_addrs)} addresses @ {elf_path}")
            
            try:
                tool_path = os.path.join(self.tools_dir, "llvm-addr2line.exe")
                cmd = [tool_path, "-f", "-e", elf_path] + hex_addrs
                self.log(f"Executing command: {' '.join(cmd)}")
                
                result = subprocess.run(
                    cmd,
                    capture_output=True, 
                    text=True, 
                    timeout=30
                )
                
                if result.returncode != 0:
                    self.log(f"[ERROR] addr2line returned error: {result.stderr}")
                
                outputs = result.stdout.strip().split('\n')
                self.log(f"addr2line output: {outputs}")
                
                # Process output results
                for i, entry in enumerate(addrs):
                    if i * 2 < len(outputs):
                        func = outputs[i * 2]
                        location = outputs[i * 2 + 1] if (i * 2 + 1) < len(outputs) else "??:0"
                        
                        if func == "??" or location == "??:0":
                            resolved[entry['runtime_addr']] = (
                                f"Symbol missing: 0x{entry['elf_addr']} in {os.path.basename(elf_path)}"
                            )
                        else:
                            resolved[entry['runtime_addr']] = f"{func} at {location}"
                    else:
                        resolved[entry['runtime_addr']] = f"Parsing failed - insufficient output"
            except Exception as e:
                self.log(f"[ERROR] addr2line parsing exception: {str(e)}")
                for entry in addrs:
                    resolved[entry['runtime_addr']] = f"Parsing exception - {str(e)}"
        
        return resolved
    
    def parse_heap_dump(self):
        """Main heap dump parsing function"""
        try:
            # Read heap dump
            self.log("Reading heap dump file...")
            with open(self.heap_file, 'r', encoding='utf-8', errors='ignore') as f:
                lines = f.readlines()
            
            # Parse memory maps from the same file
            self.log("Parsing MAPS from heap dump file...")
            maps_info = self.parse_maps(self.heap_file)
            
            # Extract address information
            self.log("Extracting call stack addresses...")
            all_addresses = []
            records = []
            for line in lines:
                if not line.startswith("z 0"):
                    continue
                
                parts = line.strip().split()
                if "bt" not in parts:
                    continue
                
                bt_index = parts.index("bt") + 1
                addresses = parts[bt_index:]
                all_addresses.extend(addresses)
                
                try:
                    size_index = parts.index("sz") + 1
                    count_index = parts.index("num") + 1
                    records.append({
                        'size': parts[size_index],
                        'count': parts[count_index],
                        'addresses': addresses
                    })
                except:
                    self.log(f"Failed to parse line: {line}")
            
            # Resolve address symbols
            unique_addresses = list(set(all_addresses))
            self.log(f"Parsing {len(unique_addresses)} unique addresses...")
            resolved = self.resolve_addresses(unique_addresses, maps_info)
            
            # Generate output file
            base_name = os.path.basename(self.heap_file)
            if '.' in base_name:
                base_name = base_name[:base_name.rindex('.')]
            output_file = os.path.join(os.path.dirname(self.heap_file), 
                                      f"{base_name}_heap_analysis.txt")
            
            self.log("Writing result file...")
            with open(output_file, 'w', encoding='utf-8') as out:
                out.write("Android Native Heap Dump Analysis\n")
                out.write("=" * 80 + "\n\n")
                out.write(f"Input file: {self.heap_file}\n")
                out.write(f"Total records: {len(records)}\n")
                out.write(f"Unique call stack addresses: {len(unique_addresses)}\n\n")
                
                for i, record in enumerate(records, 1):
                    out.write(f"Record #{i}\n")
                    out.write(f"Allocation size: {record['size']} bytes | Count: {record['count']}\n")
                    out.write(f"Call stack ({len(record['addresses'])} addresses):\n")
                    
                    for addr in record['addresses']:
                        symbol = resolved.get(addr, "UNRESOLVED")
                        out.write(f"  0x{addr} => {symbol}\n")
                    
                    out.write("=" * 80 + "\n\n")
            
            return output_file
            
        except Exception as e:
            self.log(f"[ERROR] Heap parsing failed: {str(e)}")
            import traceback
            self.log(f"Traceback: {traceback.format_exc()}")
            return None

    def run(self):
        """Worker thread execution"""
        try:
            start_time = time.time()
            result_file = self.parse_heap_dump()
            end_time = time.time()
            
            if result_file and os.path.exists(result_file):
                elapsed = end_time - start_time
                self.signal.emit(f"SUCCESS||{result_file}||{elapsed:.2f}")
            else:
                self.signal.emit("ERROR||Failed to generate result file")
                
        except Exception as e:
            self.signal.emit(f"ERROR||{str(e)}")

class SettingsCard(GroupHeaderCardWidget):
    """Heap analysis settings card"""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setTitle("堆内存分析设置")
        self.setBorderRadius(8)

        # File paths
        self.heap_file = ""
        self.symbols_dirs = []
        
        # Widgets
        self.heapChooseButton = PushButton("选择")
        self.symbolsChooseButton = PushButton("选择")
        
        # Debug option
        self.debugCheckBox = CheckBox("启用调试输出")
        self.debugCheckBox.setChecked(True)
        
        # Set fixed widths
        self.heapChooseButton.setFixedWidth(120)
        self.symbolsChooseButton.setFixedWidth(120)
        
        # Bottom layout with hint and run button
        self.hintIcon = IconWidget(InfoBarIcon.INFORMATION)
        self.hintLabel = BodyLabel("点击运行按钮开始堆内存分析")
        self.runButton = PrimaryPushButton(FluentIcon.PLAY_SOLID, "运行")
        self.bottomLayout = QHBoxLayout()
        
        # Setup bottom toolbar layout
        self.hintIcon.setFixedSize(16, 16)
        self.bottomLayout.setSpacing(10)
        self.bottomLayout.setContentsMargins(24, 15, 24, 20)
        self.bottomLayout.addWidget(self.hintIcon, 0, Qt.AlignmentFlag.AlignLeft)
        self.bottomLayout.addWidget(self.hintLabel, 0, Qt.AlignmentFlag.AlignLeft)
        self.bottomLayout.addStretch(1)
        self.bottomLayout.addWidget(self.runButton, 0, Qt.AlignmentFlag.AlignRight)
        self.bottomLayout.setAlignment(Qt.AlignmentFlag.AlignVCenter)
        
        # State tooltip
        self.stateTooltip = None
        self.bottomStateLayout = QHBoxLayout()
        
        # Setup bottom state layout
        self.bottomStateLayout.setSpacing(10)
        self.bottomStateLayout.setContentsMargins(24, 15, 24, 20)
        self.bottomStateLayout.setAlignment(Qt.AlignmentFlag.AlignVCenter)
        self.bottomStateLayout.addStretch(1)
        
        self.heapGroup = self.addGroup("{}/images/Rocket.svg".format(resource_path), 
                                       "堆转储文件(backtrace)", "请选择heap dump文件", self.heapChooseButton)
        self.symbolsGroup = self.addGroup("{}/images/Basketball.png".format(resource_path), 
                                         "符号目录(symbols)", "请选择符号目录(多个目录用分号分隔)", self.symbolsChooseButton)
        self.addGroup("{}/images/Python.svg".format(resource_path), 
                     "调试选项", "启用详细调试输出", self.debugCheckBox)
        
        self.vBoxLayout.addLayout(self.bottomLayout)
        
        # Connect signals
        self.heapChooseButton.clicked.connect(self.onHeapChooseButtonClicked)
        self.symbolsChooseButton.clicked.connect(self.onSymbolsChooseButtonClicked)
        self.runButton.clicked.connect(self.onRunButtonClicked)
    
    def onHeapChooseButtonClicked(self):
        """Heap file selection"""
        logger.info("Heap file choose button clicked")
        heap_file, _ = QFileDialog.getOpenFileName(self, "选择堆转储文件", "C:/", 
                                                  "Heap Dump Files (*.txt);;All Files (*)")
        heap_file = linuxPath2winPath(heap_file)
        logger.info(f"Selected heap file: {heap_file}")
        
        if heap_file == "":
            self.heapChooseButton.setText("选择")
            self.heapGroup.setContent("请选择heap dump文件")
        else:
            self.heapChooseButton.setText("已选择")
            self.heapGroup.setContent(os.path.basename(heap_file))
            self.heap_file = heap_file
    
    def onSymbolsChooseButtonClicked(self):
        """Symbols directory selection"""
        logger.info("Symbols directory choose button clicked")
        symbols_dir = QFileDialog.getExistingDirectory(self, "选择符号目录")
        symbols_dir = linuxPath2winPath(symbols_dir)
        logger.info(f"Selected symbols directory: {symbols_dir}")
        
        if symbols_dir == "":
            self.symbolsChooseButton.setText("选择")
            self.symbolsGroup.setContent("请选择符号目录(多个目录用分号分隔)")
        else:
            # Add to symbols directories list
            if symbols_dir not in self.symbols_dirs:
                self.symbols_dirs.append(symbols_dir)
                self.symbolsChooseButton.setText(f"已选择({len(self.symbols_dirs)})")
                self.symbolsGroup.setContent("; ".join(self.symbols_dirs))
    
    def showErrorFlyout(self, title, content):
        """Show error flyout"""
        Flyout.create(
            icon=InfoBarIcon.ERROR,
            title=title,
            content=content,
            target=self.runButton,
            parent=self.window()
        )
    
    def customSignalHandler(self, value):
        """Handle worker thread completion signal"""
        logger.info(f"Custom signal handler: {value}")
        
        # 安全地处理 stateTooltip
        try:
            if self.stateTooltip and self.stateTooltip.isVisible():
                if value.startswith("SUCCESS||"):
                    try:
                        # 使用 || 作为分隔符
                        parts = value.split("||", 2)
                        if len(parts) == 3:
                            result_file = parts[1]
                            elapsed_time = parts[2]
                            
                            self.stateTooltip.setContent(f'分析完成，耗时{elapsed_time}s')
                            self.stateTooltip.setState(True)
                            
                            # 延迟关闭状态提示
                            from PyQt6.QtCore import QTimer
                            QTimer.singleShot(1500, lambda: self._cleanupStateTooltip(True, result_file, elapsed_time))
                        else:
                            logger.error(f"Invalid SUCCESS signal format: {value}")
                            self.stateTooltip.setContent('分析完成，但结果格式异常')
                            self.stateTooltip.setState(True)
                            from PyQt6.QtCore import QTimer
                            QTimer.singleShot(1500, lambda: self._cleanupStateTooltip(True, "", "0"))
                            
                    except Exception as e:
                        logger.error(f"Error parsing SUCCESS signal: {e}")
                        self.stateTooltip.setContent('分析完成，但结果解析异常')
                        self.stateTooltip.setState(True)
                        from PyQt6.QtCore import QTimer
                        QTimer.singleShot(1500, lambda: self._cleanupStateTooltip(True, "", "0"))
                        
                elif value.startswith("ERROR||"):
                    try:
                        error_msg = value.split("||", 1)[1] if "||" in value else "未知错误"
                        self.stateTooltip.setContent('分析失败')
                        self.stateTooltip.setState(False)
                        
                        # 延迟关闭状态提示
                        from PyQt6.QtCore import QTimer
                        QTimer.singleShot(1500, lambda: self._cleanupStateTooltip(False, error_msg))
                    except Exception as e:
                        logger.error(f"Error parsing ERROR signal: {e}")
                        self.stateTooltip.setContent('分析失败')
                        self.stateTooltip.setState(False)
                        from PyQt6.QtCore import QTimer
                        QTimer.singleShot(1500, lambda: self._cleanupStateTooltip(False, "信号解析异常"))
            else:
                # stateTooltip 不存在或不可见，直接处理结果
                if value.startswith("SUCCESS||"):
                    try:
                        parts = value.split("||", 2)
                        if len(parts) == 3:
                            result_file = parts[1]
                            elapsed_time = parts[2]
                            self._showResultMessage(True, result_file, elapsed_time)
                        else:
                            logger.error(f"Invalid SUCCESS signal format (no tooltip): {value}")
                            self._showResultMessage(True, "", "0")
                    except Exception as e:
                        logger.error(f"Error parsing SUCCESS signal (no tooltip): {e}")
                        self._showResultMessage(True, "", "0")
                elif value.startswith("ERROR||"):
                    try:
                        error_msg = value.split("||", 1)[1] if "||" in value else "未知错误"
                        self._showResultMessage(False, error_msg)
                    except Exception as e:
                        logger.error(f"Error parsing ERROR signal (no tooltip): {e}")
                        self._showResultMessage(False, "信号解析异常")
        except Exception as e:
            logger.error(f"Error in customSignalHandler: {e}")
            # 无论如何都重新启用运行按钮
            self.runButton.setEnabled(True)
    
    def _cleanupStateTooltip(self, success, *args):
        """清理状态提示并显示结果"""
        try:
            if self.stateTooltip:
                self.stateTooltip.close()
                self.stateTooltip = None
        except:
            pass
        
        self.runButton.setEnabled(True)
        
        # 显示结果消息
        if success and len(args) >= 2:
            result_file, elapsed_time = args[0], args[1]
            self._showResultMessage(True, result_file, elapsed_time)
        elif not success and len(args) >= 1:
            error_msg = args[0]
            self._showResultMessage(False, error_msg)
    
    def _showResultMessage(self, success, *args):
        """显示结果消息"""
        if success:
            result_file, elapsed_time = args[0], args[1]
            
            # Open result directory
            result_dir = os.path.dirname(result_file)
            if os.path.isdir(result_dir):
                try:
                    subprocess.run(["explorer", result_dir])
                except Exception as e:
                    w = MessageBox("错误", f"打开文件夹时发生错误: {e}", self.window())
                    w.exec()
            
            w = MessageBox("分析完成", 
                          f"堆内存分析完成！\n结果文件: {os.path.basename(result_file)}\n耗时: {elapsed_time}秒",
                          self.window())
            w.exec()
        else:
            error_msg = args[0]
            w = MessageBox("分析失败", f"堆内存分析失败:\n{error_msg}", self.window())
            w.exec()
    
    def logSignalHandler(self, log_message):
        """Handle log messages from worker thread"""
        logger.info(f"[Worker] {log_message}")
    
    def onRunButtonClicked(self):
        """Run heap analysis"""
        logger.info("Heap run button clicked")
        
        # Validate inputs
        if not self.heap_file:
            self.showErrorFlyout("文件选择错误", "请选择堆转储文件")
            return
        
        if not self.symbols_dirs:
            self.showErrorFlyout("目录选择错误", "请选择符号目录")
            return
        
        # 清理可能存在的旧状态提示
        if self.stateTooltip:
            try:
                self.stateTooltip.close()
            except:
                pass
            self.stateTooltip = None
        
        # Show state tooltip
        try:
            self.stateTooltip = StateToolTip('正在分析堆内存', '请耐心等待...', self)
            self.bottomStateLayout.addWidget(self.stateTooltip, 0, Qt.AlignmentFlag.AlignRight)
            self.vBoxLayout.addLayout(self.bottomStateLayout)
            self.stateTooltip.show()
        except Exception as e:
            logger.error(f"Failed to create state tooltip: {e}")
            self.stateTooltip = None
        
        # Disable run button
        self.runButton.setDisabled(True)
        
        # Create and start worker thread
        try:
            self.worker = Worker(
                self.heap_file,
                self.symbols_dirs,
                LLVMTOOL_PATH,
                self.debugCheckBox.isChecked()
            )
            
            self.worker.signal.connect(self.customSignalHandler)
            self.worker.log_signal.connect(self.logSignalHandler)
            self.worker.start()
        except Exception as e:
            logger.error(f"Failed to start worker thread: {e}")
            # 重新启用运行按钮
            self.runButton.setEnabled(True)
            # 清理状态提示
            if self.stateTooltip:
                try:
                    self.stateTooltip.close()
                except:
                    pass
                self.stateTooltip = None
            w = MessageBox("错误", f"启动分析线程失败:\n{str(e)}", self.window())
            w.exec()

class Backtrace_AnalyzerCardsInfo(ScrollArea):
    """Heap Parser Cards Info Subinterface"""

    def __init__(self, parent=None, routeKey=None):
        super().__init__(parent=parent)
        self.view = QWidget(self)
        self.routeKey = routeKey
        
        self.vBoxLayout = QVBoxLayout(self.view)
        self.appCard = AppInfoCard(parent=self)
        self.descriptionCard = DescriptionCard(self)
        self.settingCard = SettingsCard(self)
        
        self.setWidget(self.view)
        self.setWidgetResizable(True)
        self.setObjectName(routeKey)
        
        self.vBoxLayout.setSpacing(25)
        self.vBoxLayout.setContentsMargins(0, 0, 10, 30)
        self.vBoxLayout.addWidget(self.appCard, 0, Qt.AlignmentFlag.AlignTop)
        self.vBoxLayout.addWidget(self.descriptionCard, 1, Qt.AlignmentFlag.AlignTop)
        self.vBoxLayout.addWidget(self.settingCard, 2, Qt.AlignmentFlag.AlignTop)
        
        self.enableTransparentBackground()

class Backtrace_Analyzerinterface:
    def __init__(self, parent=None, mainWindow=None):
        self.parent = parent
        self.mainWindow = mainWindow

    def addTab(self, routeKey, text, icon):
        logger.info('[TAB ADD] {}'.format(routeKey))
        self.mainWindow.tabBar.addTab(routeKey, text, icon)
        
        # Add heap parser interface
        self.mainWindow.showInterface.addWidget(Backtrace_AnalyzerCardsInfo(routeKey=routeKey))
        self.mainWindow.showInterface.setCurrentWidget(self.mainWindow.showInterface.findChild(Backtrace_AnalyzerCardsInfo, routeKey))
        self.mainWindow.stackedWidget.setCurrentWidget(self.mainWindow.showInterface)
        self.mainWindow.tabBar.setCurrentIndex(self.mainWindow.tabBar.count() - 1)
