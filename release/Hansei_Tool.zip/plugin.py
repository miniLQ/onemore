from loguru import logger
from app.common.utils import generate_uuid
from app.common.config import ROOTPATH
from pathlib import Path
import os
import subprocess

UNIQUE_NAME = "RPM Parser Tool"
CURRENT_PLUGIN_DIR = os.path.dirname(os.path.realpath(__file__))
PYTHON_PATH = os.path.join(ROOTPATH, "tools", "Python310", "python.exe")

def get_route_key():
    """
    Generate a unique route key for the plugin.
    """
    return f"{UNIQUE_NAME} {generate_uuid()}"



def run_hansei_gui():
    command = "{} {}".format(PYTHON_PATH, os.path.join(CURRENT_PLUGIN_DIR, "hansei", "hansei_gui.py"))
    try:
        subprocess.Popen(command, shell=False, creationflags=subprocess.CREATE_NO_WINDOW)
    except Exception as e:
        logger.error(f"Failed to run Hansei GUI: {e}")
        raise e

def register(main_window):
    plugin_state = {}

    def on_open():
        logger.info("[PLUGIN OPENED] Open plugin {}".format(UNIQUE_NAME))

        run_hansei_gui()


    appcard = main_window.qcomInterface.addCard(os.path.join(CURRENT_PLUGIN_DIR, "logo.png"), UNIQUE_NAME, '@designed by iliuqi.', UNIQUE_NAME)

    main_window.registerPluginOpener(UNIQUE_NAME, on_open)
